--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local beep=oven.rebake(oven.modname..".beep")


gui.widgets_of_dat_id=function(id)
	local its={}
	local idx=0
	gui.master:call_descendents(function(w)
		if	( w.data and w.data.id==id ) or
			( w.datx and w.datx.id==id ) or
			( w.daty and w.daty.id==id ) then
			its[w]=w
		end
	end)
	return pairs(its)
end




function gui.hooks(act,w,dat)

--print(act)

	if act=="click" then

--print("CLICK",w.id)

		if w.id=="base_play" then
			beep.render()
			beep.play("base",1,1)
		end
	
	end


	if act=="value" then

--print("VALUE",w.id)

	end

	
end


function gui.prepare_sound()
	local ot={}
	
	ot.name="base"

	ot.fwav=gui.datas.get_string("base_wave"):lower()

	ot.frequency=gui.datas.get_string("base_note")..gui.datas.get_string("base_octave")
	ot.duty=gui.datas.get_value("base_duty")
	ot.volume=1 -- full or half for the noisy ones
	if ot.fwav=="square" or ot.fwav=="sawtooth"  or ot.fwav=="toothsaw" then ot.volume=ot.volume/2 end

	ot.adsr={
		gui.datas.get_value("base_sustain_level"),
		gui.datas.get_value("base_attack"),
		gui.datas.get_value("base_decay"),
		gui.datas.get_value("base_sustain"),
		gui.datas.get_value("base_release"),
	}
	
	if ot.adsr[2]+ot.adsr[3]+ot.adsr[4]+ot.adsr[5] <=0 then ot.adsr[5]=0.1 end
	
	local it
	if gui.datas.get_value("fm_active")==2 then
	
		local fm={}
		ot.fm=fm
		
		fm.fwav=gui.datas.get_string("fm_wave"):lower()
		
		if fm.fwav=="whitenoise" then -- adjust whitenoise
			local wsteps=gui.datas.get_value("fm_white_steps")
			local wseed=gui.datas.get_value("fm_white_seed")
			
			if wsteps~=16 or wseed~=437 then -- not base whitenoise
				fm.fwav={"fwhitenoise",wsteps,wseed}
			end

		end

		local wrez=gui.datas.get_value("fm_wave_rez")
		
		if wrez~=0 then
			fm.fwav={"frez",wrez,fm.fwav}
		end

		
		fm.duty=gui.datas.get_value("fm_duty")

		fm.frequency=gui.datas.get_value("fm_frequency_root")
		fm.frequency=fm.frequency*fm.frequency
	
		local f1=bitsynth.note2freq(gui.datas.get_string("fm_min_note")..gui.datas.get_string("fm_min_octave"))
		local f2=bitsynth.note2freq(gui.datas.get_string("base_note")..gui.datas.get_string("base_octave"))
		local f3=bitsynth.note2freq(gui.datas.get_string("fm_max_note")..gui.datas.get_string("fm_max_octave"))
		local t1=gui.datas.get_value("fm_slide")
		if t1<0 then t1=-(t1*t1) else t1=t1*t1 end

		fm.ffreq={"freq_range",f1,f2,f3,t1}

	end
	
	if gui.datas.get_value("filter_active")==2 then
		local fq={31.25,62.5,125,250,500,1000,2000,4000,8000,16000}
		local eq={}
		local eq_active=false
		for i=1,10 do
			local f=gui.datas.get_value("filter_"..i)
			eq[#eq+1]=fq[i]
			eq[#eq+1]=f
			if f~=1 then eq_active=true end
		end
		if eq_active then ot.eq=eq end
	end
	
dprint(ot)

	return bitsynth.prepare(ot)

end



	return gui
end
