--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,gui)
	local gui=gui or {}
	gui.oven=oven
	
	gui.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	gui.master=gui.master or oven.rebake("wetgenes.gamecake.widgets").setup({font="FiraSans-Regular",text_size=16})

	require("swanky.gui_code").fill(gui)
	require("swanky.gui_data").fill(gui)
	require("swanky.gui_page").fill(gui)

gui.loads=function()

end

gui.setup=function()

	gui.loads()

	gui.data_setup()

	gui.page("test")
	
	gui.data_refresh()
	gui.fixbuts()
	
	return gui
end

gui.clean=function()
end


gui.msg=function(m)
		
	gui.master:msg(m)

end


gui.update=function()

	gui.master:update({hx=oven.win.width,hy=oven.win.height})

end

gui.draw=function()
	gl.PushMatrix()
	gui.master:draw()		
	gl.PopMatrix()
end


	return gui
end
