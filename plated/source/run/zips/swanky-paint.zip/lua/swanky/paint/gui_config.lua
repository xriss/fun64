--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local _,lfs=pcall( function() return require("lfs") end )
local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)
  
	local oven=gui.oven

	local paint=oven.rebake(oven.modname..".main_paint")

  	gui.config_data_defaults={
		gui_theme=1,
		gui_scale=1,
		escher=1,
		grid=1,
		bloom=1,
		snapx=8,snapy=8,
		win=9,winx=0.7,winy=0.7,
		fatpix=3,fatpiy=3,
		frame_idx=1,layer_idx=1,
		zoom_idx=0,
		layer_x=1,layer_y=1,
		focus_x=0,focus_y=0,
		colors=256,
		attr_width=8,attr_height=8,attr_redux=256,attr_sub=256,attr_back=-1,
	}


	gui.config_filename=wwin.files_prefix.."swankypaint.config.json"

	gui.config_load=function()

		if not lfs then return end

print("Loading "..gui.config_filename)

		local s=""
		local fp=io.open(gui.config_filename,"r")
		if fp then
			s=fp:read("*all")
			fp:close()
		end
		local tab=wjson.decode(s)

		if tab and tab.data then
			for n,v in pairs(gui.config_data_defaults) do
				if gui.data[n] and tab.data[n] then
					gui.data[n]:value(tab.data[n])
				else
					print("warning unknown data value called "..n)
				end
			end
		end

		if tab and tab.file_history then
			for n,v in pairs(tab.file_history or {}) do paint.file_history[n]=v end
		end
		
		gui.master:call_descendents(function(w)
			if w.id and w.class=="window" then
				local v=tab and tab.windows and tab.windows[w.id]
				if v then
					w.px=v.px
					w.py=v.py
					w.hx=v.hx
					w.hy=v.hy
					w.hidden=v.hidden
				end
			end
		end)

		gui.master:layout()
		gui.master:call_descendents(function(w) w:set_dirty() end)

	end	

	gui.config_save=function()
	
		if not lfs then return end

print("Saving "..gui.config_filename)

		local tab={data={},file_history=paint.file_history,windows={}}
		-- read basic values
		for n,v in pairs(gui.config_data_defaults) do
			if gui.data[n] then
				tab.data[n]=gui.data[n]:value()
			else
				print("warning unknown data value called "..n)
			end
		end

		gui.master:call_descendents(function(w)
			if w.id and w.class=="window" then
				tab.windows[w.id]={
					px=w.px,py=w.py,
					hx=w.hx,hy=w.hy,
					hidden=w.hidden,
				}
			end
		end)

		local fp=io.open(gui.config_filename,"w")
		if fp then
			fp:write(wjson.encode(tab,{pretty=true}))
			fp:close()
		end
	
	end	

	gui.config_reset=function()
	
		for n,v in pairs(gui.config_data_defaults) do
			if gui.data[n] then
				gui.data[n]:value(v)
			else
				print("warning unknown data value called "..n)
			end
		end

	end

	gui.config_reset_history=function()
	
		if not lfs then return end

		for n,v in pairs(paint.file_history) do paint.file_history[n]=nil end

		local t=(lfs.currentdir()) -- add current dir to history
		if t then
			paint.file_history[t]=true
		end

	end

	gui.config_reset_windows=function()
	
		local gsiz=gui.master.grid_size or 24
		local x,y=gsiz*4,gsiz*0
		gui.master:call_descendents(function(w)
			if w.id and w.class=="window" then
				w.px=x
				w.py=y
				w.hx=w.win_fbo.hx
				w.hy=w.win_fbo.hy
				w.hidden=true
				if w.id=="window_tools" then -- special
					w.hidden=file
					w.px=0
				end
			end
		end)
	
		gui.master:layout()
		gui.master:call_descendents(function(w) w:set_dirty() end)

	end

	return gui
end
