--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
	local images=oven.rebake(oven.modname..".images")
	local textures=oven.rebake(oven.modname..".textures")
	local views=oven.rebake(oven.modname..".views")
--	local gfile=oven.rebake("swanky.gui_file")
	local grdpaint=oven.rebake(oven.modname..".grdpaint")
	local trace=oven.rebake(oven.modname..".trace")
	local uvmap=oven.rebake(oven.modname..".uvmap")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

-- load scraped data from the data dir, allow for adding new files just by putting them in the right dir
	pcall(function() gui.presets=require("swanky.paint.scrape").presets(true) end) -- try a live update
	gui.presets=gui.presets or wzips.readlson("data/presets/scrape.lua") -- or just use the cache


gui.infos={

--[[
	{
		id="page",
		user="trace",
		idx=33,
		help="Load and View a high resolution trace image",
	},

	{
		id="page",
		user="layers",
		idx=34,
		help="Manage layers",
	},

	{
		id="page",
		user="frames",
		idx=35,
		help="Manage frames",
	},

	{
		id="page",
		user="uvmap",
		idx=36,
		help="Load and View a textured uvmapped 3D object",
	},

	{
		id="page",
		user="hide",
		idx=1,
		help="Hide menu panel",
	},
	{
		id="page",
		user="menu",
		idx=1,
		help="Show the main menu panel",
	},
]]
	{
		id="snap",
		idx=2,
		help="Snap drawing tools too a grid",
		key="g",
	},
	{
		id="magnify",
		idx=3,
		help="Zoom into the image",
		key=">",
	},
	{
		id="paint",
		idx=4,
		help="Paint using a custom brush",
		key="B",
	},
--[[
	{
		id="page",
		user="paint",
		idx=29,
		help="Show the paint panel",
	},
]]
	{
		id="paint_circle",
		idx=5,
		help="Paint using a circular brush",
	},
	{
		id="clear",
		idx=6,
		help="Clear the image to the background color",
	},
	{
		id="scroll",
		idx=7,
		help="Enter scroll mode",
	},
	{
		id="pickup",
		idx=8,
		help="Pickup a brush from the image",
		key="b",
	},
	{
		id="paint_dot",
		idx=9,
		help="Paint using a single dot brush",
		key=".",
	},
	{
		id="frame_swap",
		idx=10,
		text="Swap with Spare",
		help="Swap frame with the spare page",
		key="j",
	},
	{
		id="frame_copy",
		idx=10,
		text="Copy to Spare",
		help="Copy frame to the spare page",
		key="J",
	},
	{
		id="undo",
		idx=11,
		help="Undo the last image change",
		key="u",
	},
--[[
	{
		id="page",
		user="edit_colors",
		idx=12,
		help="Show the palette editor panel",
	},
	{
		id="page",
		user="tools",
		idx=13,
		help="Show the tools panel",
	},
	{
		id="page",
		user="file",
		idx=14,
		help="Show the file panel",
	},
	{
		id="page",
		user="prefs",
		idx=15,
		help="Show the preference panel",
	},
	{
		id="page",
		user="colors",
		idx=16,
		help="Show the color panel",
	},
]]
	{
		id="about",
		idx=17,
		help="About Swanky Paint",
	},
	{
		id="paint_line",
		idx=18,
		help="Paint using a vertical line brush",
	},
	{
		id="paint_block",
		idx=20,
		help="Paint using a square brush",
	},
	{
		id="paint_dash",
		idx=21,
		help="Paint using a horizontal line brush",
	},
	{
		id="paint_shrink",
		idx=19,
		help="Shrink the brush by 1 pixel",
		key="-",
	},
	{
		id="paint_grow",
		idx=22,
		help="Grow the brush by 1 pixel",
		key="=",
	},
	{
		id="paint_brush_prev",
		idx=19,
		help="Select previous brush",
		key="_",
	},
	{
		id="paint_brush_next",
		idx=22,
		help="Select next brush",
		key="+",
	},
	{
		id="brushmode",
		user="paint",
		idx=23,
		help="Set paint mode to normal",
		key="f1",
	},
	{
		id="brushmode",
		user="replace",
		idx=24,
		help="Set paint mode to no transparent pixels",
		key="f3",
	},
	{
		id="magnify_right",
		idx=25,
		help="Zoom out of the image",
		key="<",
	},
--[[
	{
		id="page",
		user="new",
		idx=26,
		help="Create a new image",
	},
	{
		id="page",
		user="load",
		idx=27,
		help="Load a new image",
		key="l",
	},
	{
		id="page",
		user="save",
		idx=28,
		help="Save the current image",
		key="s",
	},
	{
		id="page",
		user="export",
		idx=30,
		help="Export the current image",
	},
]]
	{
		id="brushmode",
		user="color",
		idx=31,
		help="Set paint mode to single color mask",
		key="f2",
	},
	{
		id="quicksave",
		help="Quickly save over the current file",
	},
	{
		id="quit",
		text="Quit",
		help="Quit Swanky Paint, all unsaved work will be lost!",
	},

	{
		id="brush_outline",
		text="Outline",
		help="Outline the brush",
		key="o"
	},
	{
		id="brush_inline",
		text="Inline",
		help="Inline the brush",
		key="O"
	},
	{
		id="brush_flip_x",
		text="Flip X",
		help="Flip the brush horizontally",
		key="x"
	},
	{
		id="brush_flip_y",
		text="Flip Y",
		help="Flip the brush vertically",
		key="y"
	},
	{
		id="brush_half",
		text="Half",
		help="Half the brush size",
		key="h"
	},
	{
		id="brush_double",
		text="Double",
		help="Double the brush size",
		key="H"
	},
	{
		id="brush_double_x",
		text="Double X",
		help="Double the brush size horizontally",
		key="X"
	},
	{
		id="brush_double_y",
		text="Double Y",
		help="Double the brush size vertically",
		key="Y"
	},
	{
		id="brush_rotate",
		text="Rotate",
		help="Rotate the brush clockwise",
		key="z"
	},
	{
		id="brush_remap",
		text="Remap Brush",
		help="Apply the image palette to the brush",
	},
	{
		id="brush_remap_from",
		text="Remap Image",
		help="Apply the brush palette to the image",
	},
	{
		id="brush_pal_from",
		text="Palette from brush",
		help="Copy the brush palette to the image",
	},
	{
		id="bitdown_brush_to_clipboard",
		text="Brush to Clipboard",
		help="Copy the brush to the clipboard as bitdown text",
	},
	{
		id="bitdown_clipboard_to_brush",
		text="Clipboard to Brush",
		help="Copy bitdown text in the clipboard into the brush",
	},
	{
		id="fill",
		idx=32,
		text="Flood fill",
		help="Fill all connecting pixels of the same color with the foreground color",
		key="f"
	},

	{
		id="frame_add",
		text="Add Frame",
		help="Insert a new frame here copying the current frame",
		key={"@","\""}
	},
	{
		id="frame_del",
		text="Delete Frame",
		help="Delete this frame",
		key="!"
	},

	{
		id="layer_add",
		text="Add Layer",
		help="Add a new layer here copying the current layer",
		key="$"
	},

	{
		id="layer_chop",
		text="Chop Layers",
		help="Convert a single image into multiple layers",
--		key=""
	},

	{
		id="layer_rechop",
		text="ReChop Layers",
		help="ReConvert a single image into more or less layers",
--		key=""
	},

	{
		id="layer_join",
		text="Join Layers",
		help="Convert multiple layers into a single image",
--		key=""
	},

	{
		id="layer_flatten",
		text="Flatten Layers",
		help="Merge multiple layers into a single flat image",
--		key=""
	},
	
	{
		id="window",
		user="window_colors",
		idx=12,
		help="Show the palette editor panel",
	},
	{
		id="window",
		user="window_new",
		idx=26,
		help="Create a new image",
	},
	{
		id="window",
		user="window_load",
		idx=27,
		help="Load a new image",
		key="l",
	},
	{
		id="window",
		user="window_save",
		idx=27,
		help="Save the current image",
		key="s",
	},

}

gui.lookup={
}

for i,v in ipairs(gui.infos) do
	if v.user then
		gui.lookup[v.id]=gui.lookup[v.id] or {}
		gui.lookup[v.id][v.user]=v
	else
		gui.lookup[v.id]=v
	end
end

gui.lookup_keys={
}
for i,v in ipairs(gui.infos) do
	if v.key then
		local t=(type(v.key)=="table") and v.key or {v.key}
		for _,key in ipairs(t) do
			gui.lookup_keys[key]=v
		end
	end
end

gui.get_list=function(name)		
	local ret=gui.data and gui.data[name] and gui.data[name]:value() 
	if ret then ret=gui.data[name].list[ret] end
	if ret then ret=ret.str end
	return ret
end
				
gui.data_refresh=function()
	if not gui.data then return end
	local dnum=function(d,num,min,max)
		d.min=min
		d.max=max
		d.num=num
		d.str=d:tostring(d.num) -- cache on change
	end
	local image=images.get()
	dnum(gui.data.frame_idx,image.frame+1,1,image.grd.depth)
	dnum(gui.data.layer_idx,image.layers.idx,1,image.layers.count)
	for n,v in gui.widgets_of_dat_id("frame_idx") do
		if v.snap then v:snap() end
	end
end

gui.numlist=function(s)
	local nums={}
	for word in s:gmatch("[^0-9]*([0-9]+)[^0-9]*") do nums[#nums+1]=tonumber(word) end
	return nums
end

gui.data_setup=function()
	if not gui.data then
		gui.data={}
		
		if oven.console then
			oven.console.data.data=gui.data -- put here for easy console access to data
		end
		
		gui.data.set=function(data,n,v)
			if type(n)=="table" then data[n.id]=n else data[n]=v end
		end
		gui.data.get=function(data,n)
			return data[n]
		end
		gui.data.new=function(data,v)
			data:set(wdata.new_data(v))
		end
-- refresh all data values and ranges, this will not trigger value changed messages
		
		local fatdef=3
		gui.thumb_hidden=true				
		if wwin.flavour=="android" then -- android has high dpi and fat fingers, so use this default?
			gui.thumb_hidden=false
--			fatdef=8
		end
		
		gui.file_name_fix=function(s,mode,form)

			local img=images.get()		
			if not form then
				if img.grd.depth>1 then
					form="anim"
				else
					form="image"
				end
			end

--			local s=gui.data.file_name:value()
			local s2=s
			s2=s2:gsub("%.png$",""):gsub("%.gif$",""):gsub("%.jpg$",""):gsub("%.jpeg$","")
			s2=s2:gsub("%.fatpixel$",""):gsub("%.palette$","")
			if mode=="export" then
				if s2~=s then
					s2=s2..".fatpixel"
					if form=="anim" then -- suggest gif as default animation export, but png is better
						s2=s2..".gif"
					elseif form=="cmap" then
						s2=s2..".palette.png"
					else
						s2=s2..".png"
					end
				end
--				gui.data.file_name:value(s2)
				return s2
			else
				if s2~=s then
					if form=="anim" then -- png now handles anims :)
						s2=s2..".png"
					elseif form=="cmap" then
						s2=s2..".palette.png"
					else
						s2=s2..".png"
					end
				end
--				gui.data.file_name:value(s2)
				return s2
			end
		end

		gui.data.escher_list={
			{str="pixel"},
			{str="scan"},
			{str="bleed"},
			{str="escher"},
			{str="trixel"},
		}
		gui.data:new({id="escher",class="list",hooks=gui.hooks,num=1,list=gui.data.escher_list})
		gui.data:new({id="grid",class="number",hooks=gui.hooks,num=1,min=0,max=8,step=1})
		gui.data:new({id="bloom",class="number",hooks=gui.hooks,num=1.0,min=0,max=4,step=1/16})
		
		gui.data.hack_list={
			{str="none"},
			{str="qube"},
		}
		gui.data:new({id="hack",class="list",hooks=gui.hooks,num=1,list=gui.data.hack_list})

--[[
		gui.data.preset_list={
			{str="none"},
			{str="swanky16"},
			{str="swanky32"},
			{str="spectrum"},
			{str="c64"},
			{str="msx"},
			{str="ega"},
			{str="apple2"},
		}
		gui.data:new({id="preset",class="list",hooks=gui.hooks,num=1,list=gui.data.preset_list})
]]

		gui.data.palettes_list={}
		for f,p in pairs( gui.presets.names ) do
			if f:sub(-8)==".pal.png" then
				local n=f:sub(1,-9)
--				print(n)
				gui.data.palettes_list[ #gui.data.palettes_list + 1 ]={str=n}
			end
		end
		table.sort(gui.data.palettes_list,function(a,b) return a.str<b.str end)
		gui.data:new({id="palettes",class="list",hooks=gui.hooks,num=1,list=gui.data.palettes_list})

		gui.data.presets_list={}
		for f,p in pairs( gui.presets.names ) do
			if f:sub(-8)==".set.png" then
				local n=f:sub(1,-9)
--				print(n)
				gui.data.presets_list[ #gui.data.presets_list + 1 ]={str=n}
			end
		end
		table.sort(gui.data.presets_list,function(a,b) return a.str<b.str end)
		local num=1 for i,v in ipairs(gui.data.presets_list) do if v.str=="Swanky32" then num=i end end -- pick swanky as default 
		gui.data:new({id="presets",class="list",hooks=gui.hooks,num=num,list=gui.data.presets_list})

		gui.data:new({id="snapx",class="number",hooks=gui.hooks,num=8,min=2,max=64,step=1})
		gui.data:new({id="snapy",class="number",hooks=gui.hooks,num=8,min=2,max=64,step=1})

		gui.data.win_list={
			{str="none"},
			{str="top_left"},
			{str="top"},
			{str="top_right"},
			{str="left"},
			{str="right"},
			{str="bottom_left"},
			{str="bottom"},
			{str="bottom_right"},
		}
		gui.data:new({id="win" ,class="list",  hooks=gui.hooks,num=9,list=gui.data.win_list})
		gui.data:new({id="winx",class="number",hooks=gui.hooks,num=0.70,min=0,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		gui.data:new({id="winy",class="number",hooks=gui.hooks,num=0.70,min=0,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})

		gui.data:new({id="gui_scale",class="number",hooks=gui.hooks,num=1,min=0.2,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})

		gui.data.gui_theme_list={
			{str="dark"},
			{str="bright"},
		}
		gui.data:new({id="gui_theme",class="list",hooks=gui.hooks,num=1,list=gui.data.gui_theme_list})

		gui.data:new({id="fatpix",class="number",hooks=gui.hooks,num=fatdef,min=1,max=32,step=1})
		gui.data:new({id="fatpiy",class="number",hooks=gui.hooks,num=fatdef,min=1,max=32,step=1})
		gui.data:new({id="width",class="number",num=64,min=1,max=4096,step=1})
		gui.data:new({id="height",class="number",num=64,min=1,max=4096,step=1})
		gui.data:new({id="depth",class="number",num=1,min=1,max=4096,step=1})

		gui.data:new({id="frame_idx",class="number",hooks=gui.hooks,num=1,min=1,max=16,step=1})
		gui.data:new({id="layer_idx",class="number",hooks=gui.hooks,num=1,min=1,max=16,step=1})
		gui.data:new({id="image_idx",class="number",hooks=gui.hooks,num=1,min=1,max=1,step=1})
		gui.data:new({id="zoom_idx",class="number",hooks=gui.hooks,num=0,min=-8,max=8,tostring=function(dat,num) return tostring(math.floor(num*10)/10) end})

		gui.data:new({id="layer_x",class="number",num=1,min=1,max=256,step=1})
		gui.data:new({id="layer_y",class="number",num=1,min=1,max=256,step=1})
		gui.data:new({id="layer_n",class="number",num=1,min=1,max=65536,step=1})

-- frame order using keys for next/prev
		gui.data:new({id="frame_key_list",class="string",str=""})
		gui.data:new({id="layer_key_list",class="string",str=""})
		gui.data:new({id="frame_key_list_idx",class="number",num=1,min=1,max=256,step=1})
		gui.data:new({id="layer_key_list_idx",class="number",num=1,min=1,max=256,step=1})

		
		gui.data:new({id="focus_x",class="number",num=0,min=-0xffff,max=0xffff,step=1})
		gui.data:new({id="focus_y",class="number",num=0,min=-0xffff,max=0xffff,step=1})

		gui.data:new({id="colors",class="number",num=256,min=2,max=256,step=1})
		gui.data:new({id="attr_width",class="number",num=8,min=2,max=256,step=1})
		gui.data:new({id="attr_height",class="number",num=8,min=2,max=256,step=1})
		gui.data:new({id="attr_redux",class="number",num=256,min=2,max=256,step=1})
		gui.data:new({id="attr_sub",class="number",num=256,min=1,max=256,step=1})
		gui.data:new({id="attr_back",class="number",num=-1,min=-1,max=255,step=1})
		gui.data:new({id="attr_active",class="number",hooks=gui.hooks,num=1,min=0,max=1,step=1})

		local hex_tostring=function(dat,num) return string.format("%08x",num) end
		local hex_tonumber=function(dat,str) return tonumber(str,16) end
		
		gui.data:new({id="color",class="number",hooks=gui.hooks,num=0,
			tonumber=hex_tonumber,tostring=hex_tostring})

		local hex_tostring=function(dat,num) return string.format("%02x",num) end
		local hex_tonumber=function(dat,str) return tonumber(str,16) end

		gui.data:new({id="cr",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		gui.data:new({id="cg",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		gui.data:new({id="cb",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		gui.data:new({id="ca",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		gui.data:new({id="trace_alpha",class="number",hooks=gui.hooks,num=0,min=0,max=2,step=1/16})

		gui.data:new({id="uvmap_active",class="number",hooks=gui.hooks,num=0,min=0,max=1,step=1})
		gui.data:new({id="uvmap_light",class="number",hooks=gui.hooks,num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		gui.data:new({id="uvmap_dark",class="number",hooks=gui.hooks,num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		gui.data:new({id="uvmap_bump",class="number",hooks=gui.hooks,num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})


	end
end

gui.set_infostring=function(s,t)
	gui.infostring=s
	gui.infotime=os.time()+(t or 5)
end

gui.setup=function()

	gui.loads()

	gui.infomode="hello"
	gui.set_infostring("Welcome to swanky paint ( "..gui.swversion.." )")

	gui.showkeys=false

	gui.base_idx=0

	gui.mx=0
	gui.my=0

	gui.scale=1
	gui.size_x=128
	gui.size_y=128
	
	gui.slide=0
--	gui.active=false

	gui.color_bg={i=0,a=1,r=0,g=0,b=0,argb=0xff000000}
	gui.color_fg={i=1,a=1,r=1,g=1,b=1,argb=0xffffffff}
	
	gui.data_setup()

	gui.setup_pages(gui.master)

	images.get().pick_fgbg()
	
	gui.side_page("tools")

	gui.fixbuts()
	gui.data_refresh()
	
	return gui
end

gui.clean=function()

end

gui.widgets_of_dat_id=function(id)
	local its={}
	local idx=0
	gui.master:call_descendents(function(w)
		if	( w.data and w.data.id==id ) or
			( w.datx and w.datx.id==id ) or
			( w.daty and w.daty.id==id ) then
			its[w]=w
		end
	end)
	return pairs(its)
end

function gui.hooks(act,w,dat)


	if w.id=="winx" or w.id=="winy" then

		if gui.size_knob then
			gui.size_knob:set_fxy(gui.data.winx:get_pos(1,0),gui.data.winy:get_pos(1,0))
			gui.master:layout()
--			print(act)
		end

	elseif w.id=="file_load" or w.id=="file_load_button" then

		if act=="file_name_click" or act=="click" then

			gui.load_grd( gui.master.ids.file_load:path() )
			
			if act=="click" then
				gui.master.ids.window_load.window_hooks("win_hide")
			end

		end

	elseif w.id=="file_trace" or w.id=="file_trace_button" then

		if act=="file_name_click" or act=="click" then

			xpcall(
				function()
					trace.change( gui.master.ids.file_trace:path() )
					if gui.data.trace_alpha:value()==0 then -- make visible
						gui.data.trace_alpha:value(0.5)
					end
				end,
				function(...) print(...,debug.traceback()) end
			)
			
			if act=="click" then
				gui.master.ids.window_trace.window_hooks("win_hide")
			end

		end

	elseif w.id=="file_uvmap" or w.id=="file_uvmap_button" then

		if act=="file_name_click" or act=="click" then

			xpcall(
				function()
					uvmap.change( gui.master.ids.file_uvmap:path() )
					if gui.data.uvmap_active:value()==0 then -- make visible
						gui.data.uvmap_active:value(1)
					end
				end,
				function(...) print(...,debug.traceback()) end
			)
			
			if act=="click" then
				gui.master.ids.window_uvmap.window_hooks("win_hide")
			end

		end

	elseif w.id=="file_save" or w.id=="file_save_button" then

		if act=="click" then

			gui.save_grd( gui.master.ids.file_save:path() )

			gui.master.ids.window_save.window_hooks("win_hide")

		end

	elseif w.id=="file_export" or w.id=="file_export_button" then

		if act=="click" then

			gui.export_grd( gui.master.ids.file_export:path() )

			gui.master.ids.window_export.window_hooks("win_hide")
			
		end

	elseif w.id=="palettes_remapto" then

		if act=="menudrop" then

			local str=w.data.list[ dat.value ].str
			local ps=gui.presets.palettes[str..".pal.png"]
			
			if ps then

				print("remapto","palettes",str,#ps)

				local p=wgrd.create(wgrd.U8_INDEXED,0,0,0)
				p:palette(0,#ps/4,ps)

				local img=images.get()
				img.grd=grdpaint.map8( img.grd:convert(wgrd.U8_RGBA) ,p)
				img.grd.image=img

				gui.fixbuts()				
			end
		end
		
	elseif w.id=="palettes_replace" then

		if act=="menudrop" then

			local str=w.data.list[ dat.value ].str
			local ps=gui.presets.palettes[str..".pal.png"]
			
			if ps then

				local p256={}
				for i=0,255 do -- fill in missing colors
				
					p256[i*4+1]=ps[i*4+1] or 0
					p256[i*4+2]=ps[i*4+2] or 0
					p256[i*4+3]=ps[i*4+3] or 0
					p256[i*4+4]=ps[i*4+4] or 0
				
				end

				print("replace","palettes",str,#ps)

				local img=images.get()
				img.grd:palette(0,256,p256)

				gui.fixbuts()				
			end





		end
		
	end
	
	if act=="value" then


		if     w.id=="fatpix" or w.id=="fatpiy" then
			gui.fixbuts()				
		elseif w.id=="gui_theme" then

			local theme_name=gui.get_list("gui_theme")

			if     theme_name=="bright" then	gui.master.color_theme=gui.master.color_theme_bright
			elseif theme_name=="dark"   then	gui.master.color_theme=gui.master.color_theme_dark
			end
			
			gui.master:call_descendents(function(w) w:set_dirty() end)

		elseif w.id=="gui_scale" then
			gui.gui_top_wrap.split_scale=gui.data.gui_scale:value()
			gui.gui_side_wrap.split_scale=gui.data.gui_scale:value()
			gui.fixbuts()
		elseif w.id=="frame_idx" then
			images.select_frame(w:value())
		elseif w.id=="layer_idx" then
			images.select_layer(w:value())
		elseif w.id=="image_idx" then
			images.select(w:value())
		elseif w.id=="zoom_idx" then
			local v=views[1]
			v.scale=2^w:value()
		elseif     w.id=="presets" then

--			local preset=w.list[ w:value() ].str
			local preset_name=gui.get_list("presets")

			local preset=gui.presets.presets[preset_name..".set.png"]

			if preset then
				if preset.attr_width  then gui.data.attr_width:value(  preset.attr_width  ) end
				if preset.attr_height then gui.data.attr_height:value( preset.attr_height ) end
				if preset.attr_redux  then gui.data.attr_redux:value(  preset.attr_redux  ) end
				if preset.attr_sub    then gui.data.attr_sub:value(    preset.attr_sub    ) end
				if preset.attr_back   then gui.data.attr_back:value(   preset.attr_back   ) end
				if preset.colors      then gui.data.colors:value(      preset.colors      ) end
				if preset.width       then gui.data.width:value(       preset.width       ) end
				if preset.height      then gui.data.height:value(      preset.height      ) end
				if preset.depth       then gui.data.depth:value(       preset.depth       ) end
			end
			
			gui.fixbuts()				
		else
			if w.id=="cr" or w.id=="cg" or w.id=="cb" or w.id=="ca" or w.id=="color" then    
				local g=gui.color_fg
				if     w.id=="cr" then
					g.r=w:value()
				elseif w.id=="cg" then
					g.g=w:value()
				elseif w.id=="cb" then
					g.b=w:value()
				elseif w.id=="ca" then
					g.a=w:value()
				elseif w.id=="color" then
					local c=w:value()
					g.a=math.floor((c/0x1000000)%256)
					g.r=math.floor((c/  0x10000)%256)
					g.g=math.floor((c/    0x100)%256)
					g.b=math.floor((c          )%256)
				end
				gui.set_rgba(g.i,g.r,g.g,g.b,g.a)
				gui.color_set(g,g.i)
				textures.get().upload(images.get().grd,images.get().frame)
			end
		end
	end
--print(act)
	if act=="active" or ( act=="over" and w.master.press ) then
		if w.id=="popmenu" or w.id=="topmenu" then
			local px,py=w:get_master_xy(0,w.hy)
			gui.popmenu(w,{
				px=px,
				py=py,
			})
		end
	end
	
	if act=="over" then
		gui.over=w
		gui.infomode="over"
		
		if w.id=="infobar" then
--			local t=w.master.ids.menubar
--			if t and t.hidden then
--				t.hidden=false
--				gui.master:layout()
--				t.hide_when_not="over"
--				t.master.menu=t
--print("menu")
--			end
		end

	end

--print(w.id,act)
	if act=="update" then
		if     w.id=="color_hex" then
--			local s=gui.data.color.str
--			local n=tonumber(s,16)
--			gui.data.color.num=n
--			gui.data.color:value(n)
		end
	end

	if act=="click" then

--print(w.id)

		if w.id then
		
			if      w.id=="window" then
			
				local window=gui.master.ids[w.user]
				if window then				
					window.window_hooks("win_toggle")
				end

			elseif  w.id=="thumb" then
				gui.thumb_hidden=not gui.thumb_hidden
				gui.gui_thumb.parent.hidden=not gui.thumb_hidden
			elseif w.id=="popmenu" or w.id=="topmenu" then
				local px,py=w:get_master_xy(0,w.hy)
				gui.popmenu(w,{
					px=px,
					py=py,
				})
			elseif w.id=="quit" then
				gui.show_quit_request()
--				oven.next=true
			elseif w.id=="about" then
				oven.next=oven.rebake(gui.about or "wetgenes.gamecake.spew.about.sinescroll")
			elseif w.id=="new_ok" then
				images.new_grd( gui.data.width:value()*gui.data.layer_x:value() , gui.data.height:value()*gui.data.layer_y:value() , gui.data.depth:value() )
				gui.fixbuts()
				gui.side_page_next="menu"
			elseif w.id=="resize" then
				images.resize( gui.data.width:value()*gui.data.layer_x:value() , gui.data.height:value()*gui.data.layer_y:value() , gui.data.depth:value() )
				gui.fixbuts()
			elseif w.id=="layer_rechop" then
				local image=images.get()
				if image.layers.x*image.layers.y > 1 then -- only if there is something to join
					gui.data.layer_x:value(image.layers.x)		--save old values
					gui.data.layer_y:value(image.layers.y)
					gui.data.width:value(image.layers.width)
					gui.data.height:value(image.layers.height)
					images.relayer( 1,1,1 )
				end
				
				if w.user=="brush" then -- use brush size
					local img=images.get()
					local brush=paint.brush
					local lx,ly=1,1
					if brush and brush.width>0 and brush.height>0 then
						lx=math.floor(img.grd.width/brush.width)
						ly=math.floor(img.grd.height/brush.height)
					end
print("rechop",lx,ly)
					gui.data.layer_x:value( lx )
					gui.data.layer_y:value( ly )

				elseif w.user=="+1x" then
					gui.data.layer_x:value( gui.data.layer_x:value()+1 )
				elseif w.user=="-1x" then
					gui.data.layer_x:value( gui.data.layer_x:value()-1 )
				elseif w.user=="+2x" then
					gui.data.layer_x:value( gui.data.layer_x:value()+2 )
				elseif w.user=="+3x" then
					gui.data.layer_x:value( gui.data.layer_x:value()+3 )
				elseif w.user=="+4x" then
					gui.data.layer_x:value( gui.data.layer_x:value()+4 )
				elseif w.user=="+1y" then
					gui.data.layer_y:value( gui.data.layer_y:value()+1 )
				elseif w.user=="+2y" then
					gui.data.layer_y:value( gui.data.layer_y:value()+2 )
				elseif w.user=="+3y" then
					gui.data.layer_y:value( gui.data.layer_y:value()+3 )
				elseif w.user=="+4y" then
					gui.data.layer_y:value( gui.data.layer_y:value()+4 )
				elseif w.user=="-1y" then
					gui.data.layer_y:value( gui.data.layer_y:value()-1 )
				end
				images.relayer( gui.data.layer_x:value() , gui.data.layer_y:value() )
				gui.data.width:value(image.layers.width)
				gui.data.height:value(image.layers.height)
				gui.fixbuts()
			elseif w.id=="layer_chop" then
				local image=images.get()
				images.relayer( gui.data.layer_x:value() , gui.data.layer_y:value() )
				gui.data.width:value(image.layers.width)
				gui.data.height:value(image.layers.height)
				gui.fixbuts()
			elseif w.id=="layer_flatten" then
				local image=images.get()
				image.force_grd(image.layers_flat())
				gui.data.layer_x:value(1)
				gui.data.layer_y:value(1)
				images.relayer( 1,1,1 )
				gui.fixbuts()
			elseif w.id=="layer_join" then
				local image=images.get()
				if image.layers.x*image.layers.y > 1 then -- only if there is something to join
					gui.data.layer_x:value(image.layers.x)		--save old values
					gui.data.layer_y:value(image.layers.y)
					gui.data.width:value(image.layers.width)
					gui.data.height:value(image.layers.height)
					images.relayer( 1,1,1 )
					gui.fixbuts()
				end
			elseif w.id=="cancel" then
				gui.side_page_next="menu"
--			elseif w.id=="overwrite_no" then
--				gui.side_page_next="menu"
--			elseif w.id=="overwrite_yes" then
--				gui.save_grd( gui.data.file_path() , true )
--			elseif w.id=="overwrite_export_yes" then
--				gui.export_grd( gui.data.file_path() , true )
			elseif w.id=="load" then
				gui.side_page_next="load"
			elseif w.id=="save" then
				gui.side_page_next="save"
			elseif w.id=="quicksave" then
				paint.quicksave()
			elseif w.id=="info" then
				gui.side_page_next="about"
			elseif w.id=="new" then
				gui.side_page_next="new"
			elseif w.id=="colors" then
				gui.side_page_next="colors"
			elseif w.id=="snap" then
				paint.snap=not paint.snap
				gui.fixbuts()
			elseif w.id=="brushmode" then
				if w.user=="paint" then
					paint.brushmode="paint"
				elseif w.user=="color" then
					paint.brushmode="color"
				elseif w.user=="replace" then
					paint.brushmode="replace"
				end
				gui.fixbuts()
			elseif w.id=="pickup" then
				paint.mode="pickup"
				gui.fixbuts()
			elseif w.id=="paint" then
				paint.mode="brush"
				gui.fixbuts()
			elseif w.id=="paint_dot" then
				paint.set_pbrush("dot")
				gui.fixbuts()
			elseif w.id=="paint_circle" then
				paint.set_pbrush("circle")
				gui.fixbuts()
			elseif w.id=="paint_block" then
				paint.set_pbrush("block")
				gui.fixbuts()
			elseif w.id=="paint_dash" then
				paint.set_pbrush("dash")
				gui.fixbuts()
			elseif w.id=="paint_line" then
				paint.set_pbrush("line")
				gui.fixbuts()
			elseif w.id=="paint_grow" then
				paint.set_pbrush("grow")
				gui.fixbuts()
			elseif w.id=="paint_shrink" then
				paint.set_pbrush("shrink")
				gui.fixbuts()
			elseif w.id=="paint_brush_next" then
				paint.set_pbrush("next")
				gui.fixbuts()
			elseif w.id=="paint_brush_prev" then
				paint.set_pbrush("prev")
				gui.fixbuts()
			elseif w.id=="scroll" then
				paint.mode="scroll"
				gui.fixbuts()
			elseif w.id=="undo" then
				paint.act_add({cmd="undo"})
			elseif w.id=="frame_swap" then
				paint.act_add({cmd="frame_swap"})
			elseif w.id=="frame_copy" then
				paint.act_add({cmd="frame_copy"})
			elseif w.id=="frame_add" then
				paint.act_add({cmd="frame_add"})
			elseif w.id=="frame_del" then
				paint.act_add({cmd="frame_del"})
			elseif w.id=="clear" then 
				paint.act_add({cmd="begin"})
				paint.act_add({cmd="clear"})
				paint.act_add({cmd="end"})
			elseif w.id=="color_copy" then
				gui.color_mode="copy"
				gui.fixbuts()
			elseif w.id=="color_swap" then
				gui.color_mode="swap"
				gui.fixbuts()
			elseif w.id=="color_blend" then
				gui.color_mode="blend"
				gui.fixbuts()
			elseif w.id=="color_select" then
				gui.color_mode="select"
				gui.fixbuts()
			elseif w.id=="color_pick" then

				local g=gui.color_fg

				if gui.color_mode=="blend" then
					gui.color_mode="select"
					local frm=g.i
					local too=w.user
					if frm>too then frm,too=too,frm end
					
					local p=images.get().grd:palette(frm,1)
					local q=images.get().grd:palette(too,1)
					q[1]=q[1]-p[1]
					q[2]=q[2]-p[2]
					q[3]=q[3]-p[3]
					q[4]=q[4]-p[4]
					local d=too-frm if d<=0 then d=1 end
					for i=frm,too do
						local t={	math.floor(p[1] + (q[1]*(i-frm)/d) ) ,
									math.floor(p[2] + (q[2]*(i-frm)/d) ) ,
									math.floor(p[3] + (q[3]*(i-frm)/d) ) ,
									math.floor(p[4] + (q[4]*(i-frm)/d) ) }
						gui.set_rgba(i,t[1],t[2],t[3],t[4])
					end
				elseif gui.color_mode=="copy" then
					gui.color_mode="select"
					local p=images.get().grd:palette(g.i,1)
					gui.set_rgba(w.user,p[1],p[2],p[3],p[4])
				elseif gui.color_mode=="swap" then
					gui.color_mode="select"
					local p=images.get().grd:palette(g.i,1)
					local q=images.get().grd:palette(w.user,1)

					images.get().grd:palette(g.i,1,{q[1],q[2],q[3],q[4]})
					images.get().grd:palette(w.user,1,{p[1],p[2],p[3],p[4]})
				end
				
				gui.color_set(g,w.user)
--print(g.r,g.g,g.b,g.a)
				gui.data.cr:value(g.r)
				gui.data.cg:value(g.g)
				gui.data.cb:value(g.b)
				gui.data.ca:value(g.a)
				
				gui.fixbuts()				

			elseif w.id=="color" then
				local g=gui.color_fg
				if dat and dat.keyname then
					if dat.keyname=="mouse_right" then
						g=gui.color_bg
					end
--					print(dat.key)
				end
				gui.color_set(g,w.user+gui.base_idx)
				gui.fixbuts()
			elseif w.id=="idx_sub" then
				gui.base_idx=gui.base_idx-8
				if gui.base_idx<0 then gui.base_idx=0 end
				gui.fixbuts()
			elseif w.id=="idx_add" then
				gui.base_idx=gui.base_idx+8
				if gui.base_idx>256-32 then gui.base_idx=256-32 end
				gui.fixbuts()
			elseif w.id=="magnify" or w.id=="magnify_right" then
				local v=views[1]

				if v.scale>=1 then
					v.scale=math.floor(v.scale+0.5)
					if (dat and dat.keyname=="mouse_right" ) or w.id=="magnify_right" then
						v.scale=v.scale-1
					else
						v.scale=v.scale+1
					end
					if v.scale<1 then v.scale=1 end
				else
					if (dat and dat.keyname=="mouse_right" ) or w.id=="magnify_right" then
						v.scale=v.scale/2
					else
						v.scale=v.scale*2
					end
				end

				main.remouse_fix=true
				gui.data.zoom_idx:value(math.log(v.scale)/math.log(2))
				
			elseif w.id=="bg_color" or w.id=="fg_color" then -- swap

				local fg_idx=gui.color_fg.i
				local bg_idx=gui.color_bg.i
				gui.color_set(gui.color_fg,bg_idx)
				gui.color_set(gui.color_bg,fg_idx)

			elseif w.id=="page" then
				gui.side_page_next=w.user
--				gui.side_page(w.user)
			elseif w.id=="keys" then
				gui.showkeys=not gui.showkeys
				gui.side_page_next=w.user

			elseif w.id=="brush_handle" then
				local yy=w.user:sub(1,1)
				local xx=w.user:sub(2,2)

				if xx=="l" then
					paint.hx=0
				elseif xx=="c" then
					paint.hx=0.5
				elseif xx=="r" then
					paint.hx=1
				end

				if yy=="t" then
					paint.hy=0
				elseif yy=="c" then
					paint.hy=0.5
				elseif yy=="b" then
					paint.hy=1
				end

			elseif w.id=="brush_outline" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						paint.brush=grdpaint.outline(paint.brush,gui.color_bg,gui.color_fg)
					end
				end
			elseif w.id=="brush_inline" then
				local pb=paint.brush
				if pb then
					paint.brush=grdpaint.inline(paint.brush,gui.color_bg,gui.color_fg)
				end
			elseif w.id=="brush_half" then
				local pb=paint.brush
				if pb then
					if pb.width>1 and pb.height>1 then
						pb:scale(math.ceil(pb.width/2),math.ceil(pb.height/2),1)
					end
				end
			elseif w.id=="brush_double" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						pb:scale(pb.width*2,pb.height*2,1)
					end
				end
			elseif w.id=="brush_double_x" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 then
						pb:scale(pb.width*2,pb.height,1)
					end
				end
			elseif w.id=="brush_double_y" then
				local pb=paint.brush
				if pb then
					if pb.height<1024 then
						pb:scale(pb.width,pb.height*2,1)
					end
				end
			elseif w.id=="brush_flip_x" then
				local pb=paint.brush
				if pb then
					paint.brush:flipx()
				end
			elseif w.id=="brush_flip_y" then
				local pb=paint.brush
				if pb then
					paint.brush:flipy()
				end
			elseif w.id=="brush_rotate" then
				local pb=paint.brush
				if pb then
					paint.brush=grdpaint.rotate(paint.brush,90)
				end
			elseif w.id=="brush_remap" then
				local pbrush=paint.brush
				local img=images.get()
				if pbrush then
					paint.brush=grdpaint.map8( pbrush:convert(wgrd.U8_RGBA) ,img.grd)
				end
			elseif w.id=="brush_remap_from" then
				local pbrush=paint.brush
				local img=images.get()
				if pbrush then
					img.grd=grdpaint.map8( img.grd:convert(wgrd.U8_RGBA) ,pbrush)
					img.grd.image=img
				end
			elseif w.id=="brush_pal_from" then
				local pbrush=paint.brush
				local img=images.get()
				img.grd:palette(0,256,paint.brush:palette(0,256)) -- copy pal
				gui.fixbuts()
			elseif w.id=="bitdown_brush_to_clipboard" then
				oven.win:set_clipboard( bitdown.grd_pix_idx(paint.brush) )
			elseif w.id=="bitdown_clipboard_to_brush" then
				if oven.win.has_clipboard() then
					local img=images.get()
					local s=oven.win:get_clipboard()
					if s then
--						print(s)
						local hx,hy=bitdown.pix_size(s)
						if hx and hy and hx>1 and hy>1 then
							paint.brush=assert(wgrd.create(wgrd.U8_INDEXED,hx,hy,1))
							paint.brush:palette(0,256,img.grd:palette(0,256)) -- copy pal from image
							bitdown.pix_grd_idx(s,bitdown.cmap,paint.brush,0,0,hx,hy)
							paint.mode="brush"
						end
					end
				end
			elseif w.id=="fill" then
				paint.mode="fill"
				gui.fixbuts()
			elseif w.id=="image_select" then
				images.select(w.user)
				gui.fixbuts()
			elseif w.id=="image_delete" then
				images.delete()
				gui.fixbuts()
			elseif w.id=="image_delete_other" then
				local idx=images.idx
				for i=#images,1,-1 do
					if i~=idx then
						images.delete(i)
					end
				end
				gui.fixbuts()
			elseif w.id=="image_delete_all" then
				for i=#images,1,-1 do
					images.delete(i)
				end
				gui.fixbuts()
			elseif w.id=="swap_frames_layers" then
				local image=images.get()
				local ga=image.grd
				local gb=wgrd.duplicate(ga)
				local lay=ga.image.layers
				gb:resize(lay.width*ga.depth,lay.height,lay.count) -- just make a wide strip
				
				for l=0,lay.count-1 do
					for f=0,ga.depth-1 do
						local gt=ga.image.layers_grd(l+1,nil,f)
						local gts=gt:pixels(0,0,0,lay.width,lay.height,1,"") -- all data
						gb:pixels(lay.width*f,0,l,lay.width,lay.height,1,gts)
					end
				end
				image.force_grd(gb)
				image.layers_config({x=ga.depth,y=1})
				gui.data_refresh()
				gui.fixbuts()

			elseif w.id=="anim_from_brushchop" then
				local image=images.get()
				local ga=image.grd
				local brush=paint.brush
				if brush and brush.width>0 and brush.height>0 then
					local dest=images.select(images.create())
					local gb=wgrd.duplicate(ga)
					gb:resize(brush.width,brush.height,1)
					local f=0
					for y=brush.y,ga.height,gb.height do
						for x=brush.x,ga.width,gb.width do
							if x+gb.width<=ga.width and y+gb.height<=ga.height then -- valid
								gb:resize(gb.width,gb.height,f+1) -- add a frame?
--print(x,y,gb.depth)
								gb:pixels(0,0,f,gb.width,gb.height,1,
									ga:pixels(x,y,0,gb.width,gb.height,1,""))
								f=f+1
							end
						end
					end
					dest.force_grd(gb)
					gui.data_refresh()
					gui.fixbuts()
				end
			elseif w.id=="image_from_anim" then
				local image=images.get()
				local ga=image.grd
				if ga.depth>1 then
					local dest=images.select(images.create())
					local gb=wgrd.duplicate(ga)
					gb:resize(ga.width*ga.depth,ga.height,1)
					for i=0,ga.depth-1 do
						gb:pixels(ga.width*i,0,ga.width,ga.height,
							ga:pixels(0,0,i,ga.width,ga.height,1,""))
					end
					dest.force_grd(gb)
					gui.fixbuts()
				end
			elseif w.id=="image_from_brush" then
				if paint.brush and paint.brush.width>0 and paint.brush.height>0 then
					images.select(images.create())
					local image=images.get()
					image.force_grd(wgrd.duplicate(paint.brush))
					gui.fixbuts()
				end
			elseif w.id=="image_to_brush" then
				local img=images.get()
				paint.mode="brush"
				paint.hx=0.5
				paint.hy=0.5
				paint.act_add({
					cmd="pickup",
					args={0,0,img.layers.width,img.layers.height,false},
					})
			elseif w.id=="layer_show" then
				-- toggle
				if w.state=="selected" then w.state="none" else w.state="selected" end
			elseif w.id=="frame_show" then
				-- toggle
				if w.state=="selected" then w.state="none" else w.state="selected" end
			elseif w.id=="process_show" then
				-- toggle
				if w.state=="selected" then w.state="none" else w.state="selected" end
				gui.fixbuts()
			elseif w.id=="config" then
				if     w.user=="load" then
					gui.config_load()
				elseif w.user=="save" then
					gui.config_save()
				elseif w.user=="reset" then
					gui.config_reset()
				elseif w.user=="reset_history" then
					gui.config_reset_history()
				elseif w.user=="reset_windows" then
					gui.config_reset_windows()
				end
				gui.fixbuts()
			end
			


		end
	end
end

function gui.fixbuts()
	if not gui.master then return end

-- make sure we have the right colors from the image
	gui.color_refresh(gui.color_bg)
	gui.color_refresh(gui.color_fg)

	local p=images.get().grd:palette(0,256)
	local idx_to_argb=function(idx)
		local id=(idx)*4
		local argb
		if p and p[id+1] then
			local r,g,b,a=p[1+id],p[2+id],p[3+id],p[4+id]
			argb=a*0x1000000 + r*0x10000 + g*0x100 + b 
		else
			argb=0xff000000
		end
		return argb
	end
	
	gui.master:call_descendents(function(w)
	
--		w.skin=w.skin or "swanky" -- force swanky skin
	
		local it=gui.lookup[w.id]
		if it and w.user and it[w.user] then it=it[w.user] end
		if it then
			w.info=it
			if it.idx and w.hx==w.hy then --must be square
				w.sheet_id=it.idx
				w.text=nil
				w.sheet_over="imgs/icons"
				w.sheet_px=w.hx/2
				w.sheet_py=w.hy/2
				w.sheet_hx=w.hx*1.0
				w.sheet_hy=w.hy*1.0
			end
		end
	
	
		if w.id=="color" or w.id=="color_pick" then
			local idx=w.user
			if w.id=="color" then idx=idx+gui.base_idx end
			w.color=idx_to_argb(idx)
			w.state="none"
			if idx==gui.color_fg.i then w.state="selected" end
		elseif w.id=="fg_color" then
			w.color=idx_to_argb(gui.color_fg.i)
		elseif w.id=="bg_color" then
			w.color=idx_to_argb(gui.color_bg.i)
		elseif w.id=="snap" then
			if paint.snap then w.state="selected" else w.state="none" end

		elseif w.id=="fatslidex" then			
			w.text=tostring(gui.data.fatpix:value()).."x"
		elseif w.id=="fatslidey" then			
			w.text=tostring(gui.data.fatpiy:value()).."y"
		elseif w.id=="keys" then
			if gui.showkeys then w.state="selected" else w.state="none" end
		elseif w.id=="fill" then
			if paint.mode=="fill" then w.state="selected" else w.state="none" end
		elseif w.id=="pickup" then
			if paint.mode=="pickup" then w.state="selected" else w.state="none" end
		elseif w.id=="scroll" then
			if paint.mode=="scroll" then w.state="selected" else w.state="none" end
		elseif w.id=="paint" then
			if paint.mode=="brush" then w.state="selected" else w.state="none" end
		elseif w.id=="paint_dot" then
			local pba=paint.pbrush_area
			if paint.mode=="pbrush" and pba[1]==0 and pba[2]==0 then 
				w.state="selected" else w.state="none" end
		elseif w.id=="paint_circle" then
			local pba=paint.pbrush_area
			if paint.mode=="pbrush" and pba[1]==56 and pba[2]==8 then 
				w.state="selected" else w.state="none" end
		elseif w.id=="paint_block" then
			local pba=paint.pbrush_area
			if paint.mode=="pbrush" and pba[1]==56 and pba[2]==0 then 
				w.state="selected" else w.state="none" end
		elseif w.id=="paint_dash" then
			local pba=paint.pbrush_area
			if paint.mode=="pbrush" and pba[1]==56 and pba[2]==16 then 
				w.state="selected" else w.state="none" end
		elseif w.id=="paint_line" then
			local pba=paint.pbrush_area
			if paint.mode=="pbrush" and pba[1]==56 and pba[2]==24 then 
				w.state="selected" else w.state="none" end				
		elseif w.id=="brushmode" then
			if paint.brushmode==w.user then w.state="selected" else w.state="none" end
		elseif w.id=="color_copy" then
			if gui.color_mode=="copy" then w.state="selected" else w.state="none" end
		elseif w.id=="color_swap" then
			if gui.color_mode=="swap" then w.state="selected" else w.state="none" end
		elseif w.id=="color_blend" then
			if gui.color_mode=="blend" then w.state="selected" else w.state="none" end
		elseif w.id=="color_select" then
			if gui.color_mode=="select" then w.state="selected" else w.state="none" end
		end
		w.dirty=true
	end)
	
	local g=gui.color_fg
	if gui.data then
		gui.data.cr:value(g.r)
		gui.data.cg:value(g.g)
		gui.data.cb:value(g.b)
		gui.data.ca:value(g.a)
		gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b )
	end

	paint.act_add({
		cmd="redraw",
		})
end

gui.msg=function(m)


	
	if not gui.master.focus then -- ignore keys when typing into an input box

	if m.class=="key" then
		if m.action==1 then
			if m.keyname=="space" then
				paint.autohand=true
			end
		end
		if m.action==-1 then
			if m.keyname=="space" then
				paint.autohand=false
			elseif m.keyname=="tab" then
				local g1=gui.gui_side
				local g2=gui.gui_top
				if g1 and g2 then
					g1=g1.parent
					g2=g2.parent
					if g1.hidden and g2.hidden then
						g1.hidden=false
						g2.hidden=false
					elseif g1.hidden then
						g1.hidden=false
						g2.hidden=true
					elseif g2.hidden then
						g1.hidden=true
						g2.hidden=true
					else
						g1.hidden=true
						g2.hidden=false
					end
				end
				gui.master:layout()
--				gui.active=not gui.active
				return
			end
		end
	end
	
	if m.class=="key" and m.action==1 then
	
		local it=gui.lookup_keys[m.keyname]
		if it then
			gui.hooks("click",it)
			return -- handled
		end

		-- rejigle view center
		if m.keyname=="n" then

			gui.data.focus_x:value( paint.x-math.floor(images.get().layers.width/2)  )
			gui.data.focus_y:value( paint.y-math.floor(images.get().layers.height/2) )

--			views[1].focus[1]=paint.x-math.floor(images.get().layers.width/2)
--			views[1].focus[2]=paint.y-math.floor(images.get().layers.height/2)
--			views[2].focus[1]=paint.x-math.floor(images.get().layers.width/2)
--			views[2].focus[2]=paint.y-math.floor(images.get().layers.height/2)
			main.remouse_fix=true
		end
		
		local function jiggle(x,y)
		
			gui.data.focus_x:value( gui.data.focus_x:value()+x  )
			gui.data.focus_y:value( gui.data.focus_y:value()+y  )

--			views[1].focus[1]=views[1].focus[1]+x
--			views[1].focus[2]=views[1].focus[2]+y
--			views[2].focus[1]=views[2].focus[1]+x
--			views[2].focus[2]=views[2].focus[2]+y
						
			main.remouse_fix=true
		end
		
		if     m.keyname=="up"    then jiggle( 0,-gui.data.snapy:value())
		elseif m.keyname=="down"  then jiggle( 0, gui.data.snapy:value())
		elseif m.keyname=="left"  then jiggle(-gui.data.snapx:value(), 0)
		elseif m.keyname=="right" then jiggle( gui.data.snapx:value(), 0)
		end

		if m.keyname=="[" then
			gui.color_dec()
		elseif m.keyname=="]" then
			gui.color_inc()
		end

		if m.keyname=="{" then
			gui.color_dec(gui.color_bg)
		elseif m.keyname=="}" then
			gui.color_inc(gui.color_bg)
		end

		if m.keyname=="," then -- grab the color under the cursor
			paint.mode="pipette"
			gui.fixbuts()
		end

-- image select 5/6
		if m.keyname=="5" then
			images.select_prev()
		end
		if m.keyname=="6" then
			images.select_next()
		end

-- layer select 3/4/5 (4 toggles visibility all/this layer)
		if ({["3"]=true,["4"]=true,["e"]=true})[m.keyname] then -- layer select
			if m.keyname=="e" then -- toggle viz
				local w=gui.master.ids.layer_show
				if w.state=="selected" then w.state="none" else w.state="selected" end
			else
				local n,x=images.select_layer()
				local t=gui.numlist(gui.data.layer_key_list:value())
				if #t>1 then -- special order
					local a=gui.data.layer_key_list_idx:value()
					if t[a] ~= n then
						for i,v in ipairs(t) do if n==v then a=i break end end
					end
					if m.keyname=="3" then -- back
						a=a-1
					end
					if m.keyname=="4" then -- forward
						a=a+1
					end
					if a<1 then a=#t end
					if a>#t then a=1 end
					n=t[a]
					gui.data.layer_key_list_idx:value(a)
				else
					if m.keyname=="3" then -- back
						n=n-1
					end
					if m.keyname=="4" then -- forward
						n=n+1
					end
				end
				if n<1 then n=x end
				if n>x then n=1 end
				gui.data.layer_idx:value(n)
			end
		end

-- frame select 1/2		
		if ({["1"]=true,["2"]=true,["q"]=true})[m.keyname] then -- frame select
			if m.keyname=="q" then -- toggle viz
				local w=gui.master.ids.frame_show
				if w.state=="selected" then w.state="none" else w.state="selected" end
			else
				local n,x=images.select_frame()
				local t=gui.numlist(gui.data.frame_key_list:value())
				if #t>1 then -- special order
					local a=gui.data.frame_key_list_idx:value()
					if t[a] ~= n then
						for i,v in ipairs(t) do if n==v then a=i break end end
					end
					if m.keyname=="1" then -- back
						a=a-1
					end
					if m.keyname=="2" then -- forward
						a=a+1
					end
					if a<1 then a=#t end
					if a>#t then a=1 end
					n=t[a]
					gui.data.frame_key_list_idx:value(a)
				else
					if m.keyname=="1" then -- back
						n=n-1
					end
					if m.keyname=="2" then -- forward
						n=n+1
					end
				end
				if n<1 then n=x end
				if n>x then n=1 end
				gui.data.frame_idx:value(n)
			end
		end

		if m.keyname=="p" then -- toggle processing
			local w=gui.master.ids.process_show
			if w.state=="selected" then w.state="none" else w.state="selected" end
			gui.fixbuts()
		end

		if m.keyname=="f1" then -- pixel brush
			paint.brushmode="paint"
			gui.fixbuts()
		end
		if m.keyname=="f2" then -- pixel brush
			paint.brushmode="color"
			gui.fixbuts()
		end
		if m.keyname=="f3" then -- pixel brush
			paint.brushmode="replace"
			gui.fixbuts()
		end
		
--		print(wstr.dump(m))
		
		-- maginfy toggle
		if m.keyname=="m" then
			if views[1].scale==1 then
				views[1].scale=8
			else
				views[1].scale=1
			end
			gui.data.zoom_idx:value(math.log(views[1].scale)/math.log(2))

--			views[1].focus[1]=paint.x-math.floor(images.get().layers.width/2)
--			views[1].focus[2]=paint.y-math.floor(images.get().layers.height/2)
--			views[2].focus[1]=paint.x-math.floor(images.get().layers.width/2)
--			views[2].focus[2]=paint.y-math.floor(images.get().layers.height/2)
			main.remouse_fix=true
		end
	end
	end
	
	gui.master:msg(m)
	if m.class=="mouse" then
		if gui.master.over~=gui.master then return true end
		if gui.master.focus then return true end -- a text input has focus
	end
	
	return false

end


function gui.color_inc(g,n)
	g=g or gui.color_fg
	gui.color_set(g,g.i+(n or 1))
--	gui.fixbuts()
end
function gui.color_dec(g,n)
	g=g or gui.color_fg
	gui.color_set(g,g.i-(n or 1))
--	gui.fixbuts()
end
-- apply the image color to the gui 
function gui.color_refresh(g)
	if not g then return end
	local p=images.get().grd:palette(0,256)
	local i=g.i
	if p and p[i*4+1] then
		g.r=p[i*4+1]
		g.g=p[i*4+2]
		g.b=p[i*4+3]
		g.a=p[i*4+4]
		g.argb=g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b
	end
end
function gui.color_set(g,i)
	if i>255 then i=255 end
	if i<0 then i=0 end
	g.i=i
	gui.color_refresh(g)
	gui.fixbuts()
end
function gui.set_rgba(i,r,g,b,a)
--print("set color",i,r,g,b,a)
	local p={r,g,b,a}
	images.get().grd:palette(i,1,p)
--		images.get().grdb:palette(i,1,p)
	gui.master:call_descendents(function(w)
		if w.id=="color" then
			if w.user==i then
				w.color=p[4]*0x1000000 + math.floor(p[1]*p[4]/255)*0x10000 + math.floor(p[2]*p[4]/255)*0x100 + math.floor(p[3]*p[4]/255) 
			end
		end
	end)
	if i==gui.color_fg.i then
		gui.data.color:value( a*0x1000000 + r*0x10000 + g*0x100 + b )
	end
end

function gui.load_grd(fname)
	local suc,err=xpcall(
		function() images.load_grd( fname ) end,
		function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
	)
	if suc then
		gui.fixbuts()
	else
		print(err)
		local opts={}
		opts.lines={"Error!",""}
		for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
			opts.lines[#opts.lines+1]=line
		end
		opts.lines[#opts.lines+1]=""
		opts.sorry=function() end
		gui.show_request(opts)
	end
	
	return suc
end

function gui.save_grd(fname,overwrite)

	fname=fname or images.get_filename() -- use current filename if none given

	local do_save=function()

		local suc,err=xpcall(
			function() images.save_grd( fname ) end,
			function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
		)
		if suc then
			gui.set_infostring("File saved OK")
		else
			print(err)
			local opts={}
			opts.lines={"Error!",""}
			for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
				opts.lines[#opts.lines+1]=line
			end
			opts.lines[#opts.lines+1]=""
			opts.sorry=function() end
			gui.show_request(opts)
		end

	end

	if not force_replace then -- need to test if file exists first
		local fp=io.open(fname,"r")
		if fp then
			fp:close()
			local fnameonly=fname:match( "([^\\/]+)$" )
			local opts={}
			opts.lines={"",fnameonly,"","File exists, replace?",""}
			opts.yes=function() do_save() end
			opts.no=function() gui.master.ids.window_save.window_hooks("win_show") end
			gui.show_request(opts)
		else
			do_save()
		end
	else
		do_save()
	end

end

function gui.export_grd(fname,force_replace)

	local do_export=function()
	
		local suc,err=xpcall(
			function() images.export_grd( fname ) end,
			function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
		)
		if suc then
			gui.set_infostring("File exported OK")
		else
			print(err)
			local opts={}
			opts.lines={"Error!",""}
			for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
				opts.lines[#opts.lines+1]=line
			end
			opts.lines[#opts.lines+1]=""
			opts.sorry=function() end
			gui.show_request(opts)
		end

	end
	
	if not force_replace then -- need to test if file exists first
		local fp=io.open(fname,"r")
		if fp then
			fp:close()
			local fnameonly=fname:match( "([^\\/]+)$" )
			local opts={}
			opts.lines={"",fnameonly,"","File exists, replace?",""}
			opts.yes=function() do_export() end
			opts.no=function() gui.master.ids.window_save.window_hooks("win_show") end
			gui.show_request(opts)
		else
			do_export()
		end
	else
		do_export()
	end

end

	return gui
end
