--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wgrdsvg=require("wetgenes.grdsvg")

local zips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,image)
	local image=image or {}
	image.oven=oven
	
	image.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	local framebuffers=cake.framebuffers
	local layouts=cake.layouts
	
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local textures=oven.rebake(oven.modname..".textures")
--	local gfile=oven.rebake("swanky.gui_file")
	local paint=oven.rebake(oven.modname..".main_paint")
	local grdpaint=oven.rebake(oven.modname..".grdpaint")


	image.modified=false

image.save_grd=function(name)

	image.filename=name

	image.modified=false

	local dest
	if type(name)=="table" then
		dest=name
		name=dest.name
	else
		dest={}
		dest.name=name
	end

	dest.g=image.grd

	if name and image.grd  then
		assert(dest.g:save({filename=name,json=image.json}))
print("save",name)
	end
	
	return dest
end

image.export_grd=function(name)

	local dest
	if type(name)=="table" then
		dest=name
		name=dest.name
	else
		dest={}
		dest.name=name
	end

	if ( dest.name and dest.name:sub(-4)==".svg" ) or ( name and name==".SVG" ) then
	
print("SVG export",dest.name)

		local d=wgrdsvg.string(image.grd,{
			skip_transparent_pixels=true,
			scalex=gui.data.fatpix:value(),
			scaley=gui.data.fatpiy:value(),
		})

		local fp=io.open(dest.name,"wb")
		fp:write(d)
		fp:close()
	
		return dest
	end


	if image.grd  and image.grd.depth>1 or name==".GIF" then -- animations can only fatpixel
		local ga=image.grd
		local gb=image.layers_flat() -- assert(wgrd.create(ga))
		gb:scale(gb.width*gui.data.fatpix:value(),gb.height*gui.data.fatpiy:value(),gb.depth)
		gb:palette(0,256,ga:palette(0,256)) -- copy cmap which got lost in the scale (BUG)
		
		dest.g=gb
		
	elseif image.grd  then
	
		local g=image.grd
		local v={
			scalex=gui.data.fatpix:value(),
			scaley=gui.data.fatpiy:value(),
			offset={0,0},
			siz={image.layers.width,image.layers.height},
			pos={0,0},
			grid=0,
			lines={-1,-1,-1,-1},
		}
		v.siz[1]=v.siz[1]*v.scalex
		v.siz[2]=v.siz[2]*v.scaley
		v.export=true
		
		local fbo=framebuffers.create(v.siz[1],v.siz[2],0)

			fbo:bind_frame()
			local new_layout=layouts.create{parent={x=0,y=0,w=fbo.w,h=fbo.h}}

			gl.MatrixMode(gl.PROJECTION)
			gl.PushMatrix()
			gl.MatrixMode(gl.MODELVIEW)
			gl.PushMatrix()

			local old_layout=new_layout.apply()

			gl.ClearColor(0,0,0,0)
			gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

-- draw...
	textures.get().draw(v)
	if gui.data.bloom:value() > 0 then -- add bloom effect
		textures.get().draw_bloom(v)
	end


			gl.BindFramebuffer(gl.FRAMEBUFFER, 0)

			old_layout.restore() --restore old viewport
			gl.MatrixMode(gl.PROJECTION)
			gl.PopMatrix()			
			gl.MatrixMode(gl.MODELVIEW)
			gl.PopMatrix()
			
		dest.g=fbo:download()
	end

	if dest.g then
		if dest.name and dest.name~=".GIF" then -- fileout
			assert(dest.g:save({filename=dest.name}))
print("export",dest.name)
		end
	end
	
	return dest
end

image.new_grd=function(gwidth,gheight,gdepth)

print("new",gwidth,gheight,gdepth)

	if not gdepth or gdepth<1 then gdepth=1 end
	
	if gwidth and gwidth>1 and gheight and gheight>1 then
--print(gwidth,gheight)
		image.load_grd(nil,gwidth,gheight,gdepth)
	end
end

-- make sure grd is valid
image.fix_bad_grd=function()
	if not image.grd then
		image.json=g.json
		image.grd=g
		image.grd.image=image
		image.filename=nameend
	end
	if gui.data then
		image.layers_config({x=gui.data.layer_x:value(),y=gui.data.layer_y:value()})
	end
end

image.load_grd=function(name,gwidth,gheight,gdepth)

--backup on load?
	if paint.grd_undo and image.grd then
		paint.grd_undo:copy_data_layer(image.grd,0,image.frame)
	end
	image.modified=false

	local source
	if type(name)=="table" then
		source=name
		name=source.name
	else
		source={}
		source.name=name
	end

	local loaded={} -- where to load
		
	if name then
		local g=assert(wgrd.create())
		local d=assert(zips.readfile(name),"Failed to load "..name)
		if assert(g:load_data(d)) then
			loaded.json=g.json
			loaded.grd=g
			loaded.grd.image=image
			loaded.filename=name
		end
	elseif source.data then -- load data
		local g=assert(wgrd.create())
		if assert(g:load_data(source.data)) then
			loaded.json=g.json
			loaded.grd=g
			loaded.grd.image=image
			loaded.filename=source.name or string.format("px%08x.png",os.time())
		end
	end
	
	if not loaded.grd then -- create default
		loaded.filename=string.format("px%08x.png",os.time())
		loaded.grd=assert(wgrd.create(wgrd.U8_INDEXED,gwidth,gheight,gdepth or 1))
		loaded.grd.image=image
		loaded.grd:clear(0)
		for i=0,255 do
			loaded.grd:palette(i,1,{0x00,0x00,0x00,0x00})
		end
		
		local preset_name=gui.get_list("presets") or ""

		local preset=gui.presets and gui.presets.presets  and gui.presets.presets[preset_name..".set.png"]
		local colors=gui.presets and gui.presets.palettes and gui.presets.palettes[preset_name..".set.png"]

		if preset then
			gui.data.fatpix:value(      preset.fatpix      or 3)
			gui.data.fatpiy:value(      preset.fatpiy      or 3)
		end
		
		if colors then
			loaded.grd:palette(0,#colors/4,colors)
		else -- swanky32 default

			loaded.grd:palette(0,32,{
-- swanky32
				0x00,0x00,0x00,0x00,
				0x33,0x66,0x22,0xff,
				0x44,0x88,0x22,0xff,
				0x66,0xaa,0x33,0xff,
				0x66,0xbb,0x77,0xff,
				0x66,0xcc,0xcc,0xff,
				0x55,0x99,0xcc,0xff,
				0x55,0x77,0xcc,0xff,
				0x44,0x55,0x99,0xff,
				0x33,0x33,0x66,0xff,
				0x33,0x22,0x44,0xff,
				0x44,0x22,0x33,0xff,
				0x66,0x33,0x33,0xff,
				0x88,0x44,0x33,0xff,
				0xbb,0x77,0x66,0xff,
				0xee,0xaa,0x99,0xff,
				0xee,0x88,0xbb,0xff,
				0xdd,0x66,0x66,0xff,
				0xcc,0x33,0x33,0xff,
				0xdd,0x55,0x33,0xff,
				0xdd,0x77,0x33,0xff,
				0xdd,0xaa,0x33,0xff,
				0xdd,0xdd,0x44,0xff,
				0x88,0x88,0x33,0xff,
				0x00,0x00,0x00,0xff,
				0x22,0x22,0x22,0xff,
				0x44,0x44,0x44,0xff,
				0x66,0x66,0x66,0xff,
				0x88,0x88,0x88,0xff,
				0xaa,0xaa,0xaa,0xff,
				0xcc,0xcc,0xcc,0xff,
				0xff,0xff,0xff,0xff,
			})
		end

		loaded.layer_xy={x=gui.data and gui.data.layer_x:value(),y=gui.data and gui.data.layer_y:value()}
			
	end
	
	if not loaded.grd.cmap then -- remap
		if paint.grd_undo then

			loaded.grd:convert(wgrd.U8_RGBA) -- make sure its true color

--			while loaded.grd.width>512 or loaded.grd.height>512 do -- shrink true color
--				loaded.grd:scale(loaded.grd.width/2,loaded.grd.height/2,loaded.grd.depth)
--			end

			loaded.grd=grdpaint.map8(loaded.grd,paint.grd_undo)
			loaded.grd.image=image

			loaded.layer_xy={x=gui.data and gui.data.layer_x:value(),y=gui.data and gui.data.layer_y:value()}
		else
			assert(nil,"no palette to remap with")
		end
	end

-- copy from loaded into image (the above code may have asserted so this keeps things clean)

	image.filename=loaded.filename
	image.frame=loaded.frame or 0
	image.json=loaded.json
	image.grd=loaded.grd
	if gui.data then image.layers_config(loaded.layer_xy) end

-- and finish setup

	textures.get().upload(image.grd,image.frame)
	
	image.layers_config()
	
	image.pick_fgbg()

end

image.force_grd=function(g)
	image.grd=g
	image.grd.image=image
	textures.get().upload(image.grd,image.frame)
	image.layers_config()
end

-- apply configuraton to current layer settings
image.layers_config=function(opts)
	opts=opts or {}
	image.layers=image.layers or {}
	image.layers.x=opts.x or 1
	image.layers.y=opts.y or 1
	image.layers.count=opts.count or image.layers.x*image.layers.y
	image.layers.idx=1
	image.layers_update()
end
image.layers_update=function(opts)
--print( "layer" ,image.layers.count )
	image.layers.width =math.floor(image.grd.width/image.layers.x)
	image.layers.height=math.floor(image.grd.height/image.layers.y)
end
-- get a temporary grd clipped to this layer (TODO: to fix args)
image.layers_grd=function(idx,grd,frame)
	grd=grd or image.grd
	idx=idx or image.layers.idx
	local lw=image.layers.width
	local lh=image.layers.height
	local lx=lw*math.floor((idx-1)%image.layers.x)
	local ly=lh*math.floor((idx-1)/image.layers.x)
	
--print(lx,ly,frame or 0,lw,lh,1,image.layers.x,idx)

	return grd:clip(lx,ly,frame or 0,lw,lh,1)
end
-- get a grd of all layers merged
image.layers_flat=function()
	local w,h=image.grd.width,image.grd.height
	local iw,ih=image.layers.width,image.layers.height
	local g=wgrd.create(wgrd.U8_INDEXED,iw,ih,image.grd.depth)
	g:palette(0,256,image.grd:palette(0,256))
	for z=0,image.grd.depth-1 do
		for i=image.layers and image.layers.count or 0,0,-1 do
			local x=math.floor(i%image.layers.x)
			local y=math.floor(i/image.layers.x)
			g:clip(0,0,z,iw,ih,1):paint(image.grd:clip(0,0,z,w,h,1),0,0,x*iw,y*ih,iw,ih,wgrd.PAINT_MODE_ALPHA,-1,-1)
		end
	end
	return g
--	return assert(wgrd.create(image.grd))
end

image.pick_fgbg=function(bg,fg)

	local ps=image.grd:palette(0,256)
	local function best(p)
		local b=0
		local d=256*256*4*4
		for i=0,255 do
			local d1=ps[1+i*4]-p[1]
			local d2=ps[2+i*4]-p[2]
			local d3=ps[3+i*4]-p[3]
			local d4=ps[4+i*4]-p[4]
			local dd=d1*d1+d2*d2+d3*d3+d4*d4*2
			if dd<d then
				d=dd
				b=i
			end
		end
		return b
	end
				
	bg=bg or {0,0,0,0}
	fg=fg or {255,255,255,255}

	if gui.color_bg and gui.color_fg then
		gui.color_set(gui.color_bg,best(bg))
		gui.color_set(gui.color_fg,best(fg))
	end
end

image.loads=function()


end

image.setup=function()

	image.new_grd(64,64,1) -- 64,64 default image
	image.frame=0
	
end

image.resize=function(w,h,d)
	image.grd:resize(w,h,d)
	image.layers_config()
end

image.relayer=function(x,y,count)

	image.layers_config({x=x,y=y,count=count})

end


image.clean=function()

end

image.msg=function(m)

--	if m.class=="mouse" then
--		image.mx=m.x
--		image.my=m.y
--	end

end



image.update=function()
end

image.draw=function(view)
end


local image_simple_data_copy_names={
		"escher",
		"grid",
		"bloom",
		"snapx","snapy",
--		"win","winx","winy",
		"fatpix","fatpiy",
		"frame_idx","layer_idx",
		"zoom_idx",
		"layer_x","layer_y",
		"focus_x","focus_y",
		"colors",
		"attr_width","attr_height","attr_redux","attr_sub","attr_back",
	}

-- these settings should be saved alongside the image data as they are
-- related I'm going to squirt them into a PNG text chunk tagged as JSON
-- which I think covers us,
-- after all with APNG support then PNG is the only format we really need...

-- get a json structure of the current image GUI values
-- pass in a table to update/merge it
image.get_json_data=function(json)
	json=json or image.json or {}
	if type(json)~="table" then print("badjson : "..tostring(json)) json={} end
	image.json=json
	json.swanky=json.swanky or {} --  use a swanky subtable incase anyone else wants to use the JSON tag...
	local it=json.swanky -- fill this in
	
	-- merge file history
--	it.file_history=it.file_history or {}
--	for n,v in pairs(gui.data.file_history) do
--		it.file_history[n]=v
--	end

	-- read basic values
	for i,v in ipairs(image_simple_data_copy_names) do
		if gui.data[v] then
			it[v]=gui.data[v]:value()
		else
			print("warning unknown data value called "..v)
		end
	end
	
	
	return json
end

-- set GUI values from a previously saved json structure
image.set_json_data=function(json)
	json=json or image.json
	local it=json and json.swanky or {}

--print(wstr.dump(it))
	-- merge file history
--	for n,v in pairs(it.file_history or {}) do
--		gui.data.file_history[n]=v
--	end

	-- read basic values
	for i,v in ipairs(image_simple_data_copy_names) do
		if (type(it[v])~="nil") and gui.data[v] then
			gui.data[v]:value(it[v])
		end
	end
	
-- might need to remove these values?
	image.frame=math.floor(it.frame_idx and it.frame_idx-1 or image.frame)
	image.layers.idx=math.floor(it.layer_idx or image.layers.idx)
	if image.layers.idx>image.layers.count then image.layers.idx=image.layers.count end
	if image.layers.idx<1 then image.layers.idx=1 end
end



	return image
end
