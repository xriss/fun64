--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl


	local datas=gui.master.datas

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

datas.set_infos({

	{
		id="test",
		help="This is a test.",
	},
	
})


-- create data
gui.data_setup=function()
	if not gui.datas then -- only setup once
	
		gui.datas=datas


		local hex_tostring=function(dat,num) return string.format("%02x",num) end
		local hex_tonumber=function(dat,str) return tonumber(str,16) end

		datas.new({id="dr",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="dg",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="db",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="da",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		datas.new({id="ss",class="number",hooks=gui.hooks,num=1,min=1,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		datas.new({id="sr",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="sg",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="sb",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas.new({id="sa",class="number",hooks=gui.hooks,num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		datas.new({id="rotate",class="number",hooks=gui.hooks,num=180,min=0,max=360,step=1})
		datas.new({id="zoom",class="number",hooks=gui.hooks,num=100,min=25,max=400,step=1})

		datas.new({id="tweak_scale_x",class="number",hooks=gui.hooks,num=100,min=50,max=200,step=1})
		datas.new({id="tweak_scale_y",class="number",hooks=gui.hooks,num=100,min=50,max=200,step=1})
		datas.new({id="tweak_scale_z",class="number",hooks=gui.hooks,num=100,min=50,max=200,step=1})
		datas.new({id="tweak_rotate_x",class="number",hooks=gui.hooks,num=0,min=-90,max=90,step=1})
		datas.new({id="tweak_rotate_y",class="number",hooks=gui.hooks,num=0,min=-90,max=90,step=1})
		datas.new({id="tweak_rotate_z",class="number",hooks=gui.hooks,num=0,min=-90,max=90,step=1})
		datas.new({id="tweak_translate_x",class="number",hooks=gui.hooks,num=0,min=-400,max=400,step=1})
		datas.new({id="tweak_translate_y",class="number",hooks=gui.hooks,num=0,min=-400,max=400,step=1})
		datas.new({id="tweak_translate_z",class="number",hooks=gui.hooks,num=0,min=-400,max=400,step=1})

		datas.new({id="file_dir",class="string",hooks=gui.hooks,str="art/souls"})
		datas.new({id="file_name",class="string",hooks=gui.hooks,str=string.format("test.soul",os.time())})

		datas.new({id="material"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="skin"},
			{str="lips"},
			{str="hair"},
			{str="eye"},
			{str="iris"},
			{str="black"},
			{str="color1"},
			{str="color2"},
			{str="color3"},
		}})

		datas.new({id="pose"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="breath"},
			{str="relax"},
			{str="reset"},
		}})

		datas.new({id="tweak"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="head"},
			{str="hair"},
			{str="body"},
			{str="hand"},
			{str="foot"},
			{str="tail"},
			{str="nose"},
			{str="mouth"},
			{str="eye"},
			{str="ear"},
			{str="belly"},
			{str="boob"},
			{str="tail"},
		}})


		datas.new({id="part_head"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-head"},
			{str="head"},
			{str="head_chub"},
		}})
		
		local hair_list={
			{str="no-hair1"},
			{str="hair"},
			{str="hair_flattop"},
			{str="hair_fringe"},
			{str="hair_back"},
			{str="hair_shoulder"},
		}

		datas.new({id="part_hair1"  ,class="list",  hooks=gui.hooks,num=2,list=hair_list})
		datas.new({id="part_hair2"  ,class="list",  hooks=gui.hooks,num=1,list=hair_list})
		datas.new({id="part_hair3"  ,class="list",  hooks=gui.hooks,num=1,list=hair_list})

		datas.new({id="part_ear"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-ear"},
			{str="ear"},
		}})

		datas.new({id="part_nose"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-nose"},
			{str="nose"},
		}})

		datas.new({id="part_eyewear"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="no-eyewear"},
			{str="eyewear_glasses"},
		}})

		datas.new({id="part_mouth"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-mouth"},
			{str="mouth"},
		}})

		datas.new({id="part_beard"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="no-beard"},
			{str="beard_goatee"},
			{str="beard_goatbraid"},
		}})

		datas.new({id="part_eyebot"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-eyebot"},
			{str="eyebot"},
			{str="eyebot_lash"},
			{str="eyebot_flutter"},
		}})

		datas.new({id="part_eyelid"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-eyelid"},
			{str="eyelid"},
			{str="eyelid_lash"},
			{str="eyelid_flutter"},
		}})

		datas.new({id="part_eyebrow"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-eyebrow"},
			{str="eyebrow"},
			{str="eyebrow_block"},
		}})

		datas.new({id="part_eyeball"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-eyeball"},
			{str="eyeball"},
		}})

		datas.new({id="part_body"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-body"},
			{str="body_belly"},
			{str="body_belly_boob"},
			{str="body_chest"},
			{str="body_boob"},
			{str="body_tshirt"},
			{str="body_tshirt_boob"},
		}})

		datas.new({id="part_tail"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="no-tail"},
		}})

		datas.new({id="part_hand"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-hand"},
			{str="hand"},
		}})

		datas.new({id="part_foot"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="no-foot"},
			{str="foot_bare"},
			{str="foot_slipper"},
		}})
		
	end
end



	return gui
end
