
-- the displayed name
title="Thin Swanky Paint"


-- the internal name, used for the base game module
name="swpaint"


android_permissions=[[
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
]]
