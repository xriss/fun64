--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

gui.infos={

	{
		id="test",
		help="This is a test.",
	},
	
}

-- build lookup
gui.lookup={}
for i,v in ipairs(gui.infos) do
	if v.user then
		gui.lookup[v.id]=gui.lookup[v.id] or {}
		gui.lookup[v.id][v.user]=v
	else
		gui.lookup[v.id]=v
	end
end

-- build lookup by keys
gui.lookup_keys={}
for i,v in ipairs(gui.infos) do
	if v.key then
		local t=(type(v.key)=="table") and v.key or {v.key}
		for _,key in ipairs(t) do
			gui.lookup_keys[key]=v
		end
	end
end

-- create data
gui.data_setup=function()
	if not gui.data then
	
		gui.data={}

		gui.data.set=function(data,n,v)
			if type(n)=="table" then data[n.id]=n else data[n]=v end
		end

		gui.data.get=function(data,n)
			return data[n]
		end

		gui.data.new=function(data,v)
			data:set(wdata.new_data(v))
		end

		gui.data:new({id="width",class="number",num=64,min=1,max=4096,step=1})
		gui.data:new({id="height",class="number",num=64,min=1,max=4096,step=1})
		gui.data:new({id="depth",class="number",num=1,min=1,max=4096,step=1})

	end
end

-- refresh data				
gui.data_refresh=function()
	if not gui.data then return end
end


	return gui
end
