#!/usr/local/bin/gamecake

-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

-- setup some default search paths,
local apps=require("apps")
apps.default_paths()

local wjson=require("wetgenes.json")

local kissfft=require("kissfft.core")

local wpack=require("wetgenes.pack")
local wgrd=require("wetgenes.grd")
local wwin=require("wetgenes.win")
local wxox=require("wetgenes.xox")
local wstr=require("wetgenes.string")
local wzips=require("wetgenes.zips")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local bitsynth=require("wetgenes.gamecake.fun.bitsynth")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,beep)
	beep=beep or {}
	beep.modname=M.modname
	
	local gl=oven.gl
	local cake=oven.cake
	local sounds=cake.sounds -- the gamecake sound interface


	local gui=oven.rebake(oven.modname..".gui")

	beep.loads=function()
	
		local filename="lua/"..(M.modname):gsub("%.","/")..".glsl"
		gl.shader_sources( assert(wzips.readfile(filename),"file not found: "..filename) , filename )

	end
			
	beep.setup=function()

	end


	beep.clean=function()

	end

	beep.msg=function(m)

	end

	beep.set_dirty=function()
		local w=gui.master.ids.display_wave
		if w then w:set_dirty() end
		local w=gui.master.ids.display_buckets
		if w then w:set_dirty() end
	end
	
	beep.update=function()
		
		beep.time=beep.time+(1/60)

		if beep.time <= ((#beep.u8t)/48000) then
			gui.datas.get("display_offset"):value(beep.time*48000)
			beep.set_dirty()
		end

	end

	beep.draw=function()
	
	end
	
	beep.time=0
	
	beep.s16t={}
	beep.s16=""
	beep.s16_len=0
	
	beep.u8t={}
	
	beep.buckets={}

	beep.draw_wave=function(widget)

		local draw_quad=function(x1,y1,x2,y2,x3,y3,x4,y4)
			local r,g,b,a=gl.color_get_rgba()
			local v1=gl.apply_modelview( {x1,y1,0,1} )
			local v2=gl.apply_modelview( {x2,y2,0,1} )
			local v3=gl.apply_modelview( {x4,y4,0,1} )
			local v4=gl.apply_modelview( {x3,y3,0,1} )
			local t={
				v1[1],v1[2],v1[3],		0,		1,	 	r,g,b,a,
				v2[1],v2[2],v2[3],		800,	1,		r,g,b,a,
				v3[1],v3[2],v3[3],		0,		-1,		r,g,b,a,
				v4[1],v4[2],v4[3],		800,	-1,		r,g,b,a,
			}
			return function()
				oven.cake.canvas.flat.tristrip("rawuvrgba",t,"beep_wave",function(p)

					local img=cake.images.get("beep/samples")
					if img then
						cake.images.bind(img)
						gl.Uniform4f( p:uniform("sound_time"), gui.datas.get("display_offset"):value(),#beep.u8t,img.gl_width,img.gl_height )
--						print(beep.time*48000,#beep.u8t,img.gl_width,img.gl_height)
					end
				end)
			end
		end
		
--		print(widget.px,widget.py,widget.hx,widget.hy)

		return draw_quad(	0,				0,
							widget.hx,		0,
							widget.hx,		widget.hy,
							0,				widget.hy)
	end

	beep.draw_buckets=function(widget)

		local draw_quad=function(x1,y1,x2,y2,x3,y3,x4,y4)
			local r,g,b,a=gl.color_get_rgba()
			local v1=gl.apply_modelview( {x1,y1,0,1} )
			local v2=gl.apply_modelview( {x2,y2,0,1} )
			local v3=gl.apply_modelview( {x4,y4,0,1} )
			local v4=gl.apply_modelview( {x3,y3,0,1} )
			local t={
				v1[1],v1[2],v1[3],		0,		1,	 	r,g,b,a,
				v2[1],v2[2],v2[3],		1025,	1,		r,g,b,a,
				v3[1],v3[2],v3[3],		0,		0,		r,g,b,a,
				v4[1],v4[2],v4[3],		1025,	0,		r,g,b,a,
			}
			return function()
				oven.cake.canvas.flat.tristrip("rawuvrgba",t,"beep_buckets",function(p)

					local img=cake.images.get("beep/buckets")
					if img then
						cake.images.bind(img)
						gl.Uniform4f( p:uniform("sound_time"), gui.datas.get("display_offset"):value(),#beep.u8t,img.gl_width,img.gl_height )
--						print(beep.time*48000,#beep.u8t,img.gl_width,img.gl_height)
					end
				end)
			end
		end
		
--		print(widget.px,widget.py,widget.hx,widget.hy)

		return draw_quad(	0,				0,
							widget.hx,		0,
							widget.hx,		widget.hy,
							0,				widget.hy)
	end

	beep.render=function(it) -- render a bitsynth sound

		if not it then it=gui.prepare_sound() end -- read from gui settings
		local t1=bitsynth.render(it)
		local t2={}
		for i=1,#t1 do t2[i]=t1[i] end

		beep.s16t=bitsynth.float_to_16bit(t1) -- cache s16 data

		beep.u8t=bitsynth.float_to_8bit(t2) -- cache u8 data
		local ru=math.ceil(#beep.u8t/1024)*1024
		for i=#beep.u8t+1,ru do beep.u8t[i]=0x80 end -- pad to 1k chunks for texture upload
		
		
		local omin,omax=cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER
		cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER=gl.NEAREST,gl.NEAREST
		cake.images.unload("beep/samples")
		beep.u8_image=cake.images.load("beep/samples","beep/samples",function()
			local hy=math.ceil(#beep.u8t/1024)
			local g=wgrd.create(wgrd.FMT_U8_LUMINANCE,1024,hy,1) -- 1024 wide and as high as we need
			g:pixels(0,0,1024,hy,beep.u8t) -- fill up with data
			g:convert(wgrd.FMT_U8_RGBA_PREMULT)
			return g
		end)
		cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER=omin,omax
		
		beep.buckets={}
		local k=kissfft.start(2048)
		for i=0,math.floor((#beep.s16t-1)/1024) do
			local oversample=2
			local oversample2=1
			local t={} ; for j=1,1024*oversample do t[j]=beep.s16t[(i-oversample2)*1024+j] or 0 end
			local d,l=wpack.save_array(t,"s16")
			kissfft.push(k,d,1024*oversample)
			local f,l=kissfft.pull(k)
			beep.buckets[#beep.buckets+1]=wpack.load_array(f,"f32",0,1025*4)
			kissfft.reset(k)
		end
		kissfft.clean(k)
		
		local omin,omax=cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER
		cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER=gl.NEAREST,gl.NEAREST
		cake.images.unload("beep/buckets")
		beep.u8_image=cake.images.load("beep/buckets","beep/buckets",function()
			local hx=1025
			local hy=#beep.buckets
			local g=wgrd.create(wgrd.FMT_U8_RGBA_PREMULT,hx,hy,1)
			for y=0,hy-1 do
				local t={}
				for i=0,1024 do
					local f=math.sqrt(beep.buckets[y+1][i+1])/128 -- 128 gives a good visual range
					f=f/(f+1)
					t[i*4+1]=math.floor(f*255)
					t[i*4+2]=0
					t[i*4+3]=0
					t[i*4+4]=0
				end
				g:pixels(0,y,hx,1,t)
			end
			return g
		end)
		cake.images.TEXTURE_MIN_FILTER,cake.images.TEXTURE_MAX_FILTER=omin,omax


		local d=gui.datas.get("display_offset")
		d.max=#beep.u8t
		d:value(0)

		beep.set_dirty()

		return sounds.load_wavtab( beep.s16t, it.name , bitsynth.frequency )
	end

	beep.get=function(name)
		return assert(sounds.get(name))
	end

	beep.play=function(name,pitch,gain) -- play a previously rendered sound, pitch and gain are scalars so default to 1

		local d=beep.get(name)
		d.idx=1 -- only use one source
		local op,og=d.pitch,d.gain
		d.pitch,d.gain=pitch or 1,gain or 1
		sounds.beep( d )
		d.pitch,d.gain=op,og

		beep.time=0
	end




	return beep
end

