#!/usr/local/bin/gamecake

-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

-- setup some default search paths,
local apps=require("apps")
apps.default_paths()

local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wxox=require("wetgenes.xox")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local bitsynth=require("wetgenes.gamecake.fun.bitsynth")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,beep)
	beep=beep or {}
	beep.modname=M.modname
	
	local cake=oven.cake
	local sounds=cake.sounds -- the gamecake sound interface


	local gui=oven.rebake(oven.modname..".gui")

	beep.loads=function()
	
	end
			
	beep.setup=function()

	end


	beep.clean=function()

	end

	beep.msg=function(m)

	end

	
	beep.update=function()
			
	end

	beep.draw=function()
			
	end

	beep.render=function(it) -- render a bitsynth sound

		if not it then it=gui.prepare_sound() end -- read from gui settings
		local t=bitsynth.render(it)
		t=bitsynth.float_to_16bit(t)
		return sounds.load_wavtab( t, it.name , bitsynth.frequency )
	end

	beep.get=function(name)
		return assert(sounds.get(name))
	end

	beep.play=function(name,pitch,gain) -- play a previously rendered sound, pitch and gain are scalars so default to 1
		local d=beep.get(name)
		local op,og=d.pitch,d.gain
		d.pitch,d.gain=pitch or 1,gain or 1
		sounds.beep( d )
		d.pitch,d.gain=op,og
	end




	return beep
end

