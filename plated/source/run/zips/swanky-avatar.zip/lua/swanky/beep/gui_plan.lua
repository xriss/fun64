--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local lfs ; pcall( function() lfs=require("lfs") end ) -- may not have a filesystem
local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local wmenuitem=oven.rebake("wetgenes.gamecake.widgets.menuitem")

--	gui.pages=gui.pages or {}

	gui.plan_windows=function(master)	
		master=master or gui.master

		local gsiz=master.grid_size or 24

		local def_window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
			} do it[n]=it[n] or v end
			
			return parent.windows:add(it)
		end

		local def_title=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_menudrop=function(parent,it)
			for n,v in pairs{
				class="menudrop",
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_xslide=function(parent,it)
			for n,v in pairs{
				class="slide",
				hooks=gui.hooks,
				datx=it.data,
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end
		

		local screen=gui.master:add({size="full",class="screen",id="screen",solid=true})

		local split=screen:add({class="split",size="full",split_axis="y",split_max=gsiz})

		local bar=split:add({class="fit",size="fullx fity",fbo=true,style="flat",highlight="none",color=0})
		
		local menu=bar:add({size="fullx",hy=gsiz,class="menubar",color=0,style="flat",highlight="none",id="menubar",always_draw=true,fbo=true})

		wmenuitem.menu_add(menu,{top=menu,menu_data={
			menu_px=0,menu_py=1,
	--		func_text=func_text,
			hooks=gui.hooks,
			{id="topmenu",text="File",menu_data={
				{id="quit",user="quit",text="Quit"},
			}},
			{id="topmenu",text="Windows",menu_data={
				{id="window",user="wave",text="Wave"},
			}},
		}})

		split:insert(screen.windows)

		local canvas=def_window(screen,{px=gsiz*1,py=gsiz*1,hx=gsiz*16,size="fit",id="window_wave",title="Wave"}).win_canvas

		def_button(canvas,{hx=gsiz*16,id="base_play",text="Play"})

--		def_menudrop(canvas,{hx=gsiz*5,data=gui.datas.get("base_type")})
		def_menudrop(canvas,{hx=gsiz*6,data=gui.datas.get("base_wave")})
		def_menudrop(canvas,{hx=gsiz*5,data=gui.datas.get("base_note")})
		def_menudrop(canvas,{hx=gsiz*5,data=gui.datas.get("base_octave")})

		
		def_title(canvas,{hx=gsiz*4,text="Duty"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("base_duty")})

		def_title(canvas,{hx=gsiz*8,text="Sustain Level"})
		def_xslide(canvas,{hx=gsiz*8,data=gui.datas.get("base_sustain_level")})

		def_title(canvas,{hx=gsiz*4,text="Attack"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("base_attack")})

		def_title(canvas,{hx=gsiz*4,text="Decay"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("base_decay")})

		def_title(canvas,{hx=gsiz*4,text="Sustain"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("base_sustain")})

		def_title(canvas,{hx=gsiz*4,text="Release"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("base_release")})


		def_title(canvas,{hx=gsiz*16,text=""})

		def_title(canvas,{hx=gsiz*12,text="Frequency Modulation"})
		def_menudrop(canvas,{hx=gsiz*4,data=gui.datas.get("fm_active")})

		def_menudrop(canvas,{hx=gsiz*6,data=gui.datas.get("fm_wave")})
		def_xslide(canvas,{hx=gsiz*10,data=gui.datas.get("fm_frequency_root")})

		def_title(canvas,{hx=gsiz*4,text="FM Duty"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("fm_duty")})

		def_title(canvas,{hx=gsiz*4,text="FM Slide"})
		def_xslide(canvas,{hx=gsiz*12,data=gui.datas.get("fm_slide")})

		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("fm_min_note")})
		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("fm_min_octave")})
		def_title(canvas,{hx=gsiz*2,text="<-"})
		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("base_note")})
		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("base_octave")})
		def_title(canvas,{hx=gsiz*2,text="->"})
		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("fm_max_note")})
		def_menudrop(canvas,{hx=gsiz*2,data=gui.datas.get("fm_max_octave")})

		master:layout() -- need to layout at least once to get everything in the right place

		gui.master:call_descendents(function(w) w:set_dirty() end)


--screen:add_split({window=master.ids.window_color,split_axis="x",split_order=1})
--screen:add_split({window=master.ids.window_files,split_axis="x",split_order=1})

	end

	return gui
end
