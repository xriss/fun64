--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local avatar=oven.rebake(oven.modname..".avatar")


gui.widgets_of_dat_id=function(id)
	local its={}
	local idx=0
	gui.master:call_descendents(function(w)
		if	( w.data and w.data.id==id ) or
			( w.datx and w.datx.id==id ) or
			( w.daty and w.daty.id==id ) then
			its[w]=w
		end
	end)
	return pairs(its)
end




function gui.hooks(act,w,dat)

--print(act)

	if act=="click" then

--print(w.id)

		if w.id=="quit"  then

			oven.next=true
			
		elseif w.id=="file_save" then
		
			local filename=gui.datas.get_value("file_dir") .."/".. gui.datas.get_value("file_name")
			avatar.save(filename)

		elseif w.id=="file_load" then

			local filename=gui.datas.get_value("file_dir") .."/".. gui.datas.get_value("file_name")
			avatar.load(filename)
		

		elseif w.id=="layout" then

			if     w.user=="load" then gui.plan_windows_load()
			elseif w.user=="save" then gui.plan_windows_save()
			elseif w.user=="reset" then gui.plan_windows_reset()
			end
		
		elseif w.id=="theme" then
		
			if     w.user=="bright" then	gui.master.color_theme=gui.master.color_theme_bright
			elseif w.user=="dark"   then	gui.master.color_theme=gui.master.color_theme_dark
			end
			
			gui.master:call_descendents(function(w) w:set_dirty() end)


		elseif w.id=="window" then

			local name="window_"..(w.user or "")
			w.master:call_descendents(function(w)
				if w.id==name then
					w.hidden=not w.hidden
				end
			end)
		
		elseif w.id=="tweak_reset" then
		
			gui.datas.set_value("tweak_scale_x",    100)
			gui.datas.set_value("tweak_scale_y",    100)
			gui.datas.set_value("tweak_scale_z",    100)
			gui.datas.set_value("tweak_rotate_x",   0)
			gui.datas.set_value("tweak_rotate_y",   0)
			gui.datas.set_value("tweak_rotate_z",   0)
			gui.datas.set_value("tweak_translate_x",0)
			gui.datas.set_value("tweak_translate_y",0)
			gui.datas.set_value("tweak_translate_z",0)

			gui.data_save("tweaks")
			
		end
	
	end


	if act=="value" then

--print(w.id)

		if w.id=="tweak" or w.id=="material" or w.id=="colortype" then
		
			gui.data_load("all")
			
		elseif w.id:sub(1,5)=="part_" then   

			gui.data_save("parts")
			gui.data_load("all")

		elseif w.id:sub(1,6)=="tweak_" then   
		
			gui.data_save("tweaks")

		elseif w.id=="dr" or w.id=="dg" or w.id=="db" or w.id=="da" or 
		       w.id=="sr" or w.id=="sg" or w.id=="sb" or w.id=="sa" or
		       w.id=="ss" then    

			gui.data_save("materials")

		end

	end

end


-- save the gui data from gui values

function gui.data_save(...)

	if not gui.master then return end
	if not gui.datas then return end

	for _,name in ipairs{...} do
	 
		if name=="all" or name=="materials" then

			local material_name=gui.datas.get_string("material")
			local material=avatar.soul.materials[material_name]

			if material then
			
				material.diffuse[  1]=gui.datas.get_value("dr")/255
				material.diffuse[  2]=gui.datas.get_value("dg")/255
				material.diffuse[  3]=gui.datas.get_value("db")/255
				material.diffuse[  4]=gui.datas.get_value("da")/255
				material.specular[ 1]=gui.datas.get_value("sr")/255
				material.specular[ 2]=gui.datas.get_value("sg")/255
				material.specular[ 3]=gui.datas.get_value("sb")/255
				material.specular[ 4]=gui.datas.get_value("sa")/255
				material.shininess[1]=gui.datas.get_value("ss")

			end
			
			avatar.gs.grd_texmat=nil
			
		end
	
		if name=="all" or name=="tweaks" then

			local tweak_name=gui.datas.get_string("tweak")
			local tweak=avatar.soul.tweaks[tweak_name]
			
			if tweak then

				tweak.scale[1]    =gui.datas.get_value("tweak_scale_x"    )/100
				tweak.scale[2]    =gui.datas.get_value("tweak_scale_y"    )/100
				tweak.scale[3]    =gui.datas.get_value("tweak_scale_z"    )/100
				tweak.rotate[1]   =gui.datas.get_value("tweak_rotate_x"   )
				tweak.rotate[2]   =gui.datas.get_value("tweak_rotate_y"   )
				tweak.rotate[3]   =gui.datas.get_value("tweak_rotate_z"   )
				tweak.translate[1]=gui.datas.get_value("tweak_translate_x")/1000
				tweak.translate[2]=gui.datas.get_value("tweak_translate_y")/1000
				tweak.translate[3]=gui.datas.get_value("tweak_translate_z")/1000
				
			end

			local tweaks={}
			avatar.filter.tweaks=tweaks
			for n,v in pairs(avatar.soul.tweaks) do
				for bone,bonev in pairs(avatar.tweak_map[n].bones) do
					if bone:sub(-2)==".R" then
						tweaks[bone]=tardis.m4.new():identity()
						:translate(-v.translate[1],v.translate[2],v.translate[3])
						:rotate(v.rotate[1],"x"):rotate(-v.rotate[2],"y"):rotate(-v.rotate[3],"z")
						:scale_v3(v.scale[1],v.scale[2],v.scale[3])
					else
						tweaks[bone]=tardis.m4.new():identity()
						:translate(v.translate[1],v.translate[2],v.translate[3])
						:rotate(v.rotate[1],"x"):rotate(v.rotate[2],"y"):rotate(v.rotate[3],"z")
						:scale_v3(v.scale[1],v.scale[2],v.scale[3])
					end				
				end
			end


		end

		if name=="all" or name=="parts" then

			avatar.soul.parts={}
			for i,v in ipairs(avatar.node_names) do
			
				local name=gui.datas.get_string("part_"..v) 
				if name and name:sub(1,3)~="no-" then
					avatar.soul.parts[v]=name
				else
					avatar.soul.parts[v]=nil
				end
			end

			avatar.rebuild()
			
		end

	end

end

-- load the gui data into gui values

function gui.data_load(...)

	if not gui.master then return end
	if not gui.datas then return end

	for _,name in ipairs{...} do
	
		if name=="all" or name=="materials" then

			local material_name=gui.datas.get_string("material")
			local material=avatar.soul.materials[material_name]

			if material then
			
				gui.datas.set_value("dr",material.diffuse[  1]*255)
				gui.datas.set_value("dg",material.diffuse[  2]*255)
				gui.datas.set_value("db",material.diffuse[  3]*255)
				gui.datas.set_value("da",material.diffuse[  4]*255)
				gui.datas.set_value("sr",material.specular[ 1]*255)
				gui.datas.set_value("sg",material.specular[ 2]*255)
				gui.datas.set_value("sb",material.specular[ 3]*255)
				gui.datas.set_value("sa",material.specular[ 4]*255)
				gui.datas.set_value("ss",material.shininess[1]    )

			end

			local v=avatar.gs.anim_merged
			for mi=1,#v.mats do local m=v.mats[mi]
				local mat=avatar.soul.materials[m.name]
				if m then
					for a,b in pairs(mat) do m[a]=b end  -- copy mat
				end
			end

		end
	
		if name=="all" or name=="tweaks" then

			local tweak_name=gui.datas.get_string("tweak")
			local tweak=avatar.soul.tweaks[tweak_name]
			
			if tweak then

				gui.datas.set_value("tweak_scale_x",    tweak.scale[1]*100     )
				gui.datas.set_value("tweak_scale_y",    tweak.scale[2]*100     )
				gui.datas.set_value("tweak_scale_z",    tweak.scale[3]*100     )
				gui.datas.set_value("tweak_rotate_x",   tweak.rotate[1]        )
				gui.datas.set_value("tweak_rotate_y",   tweak.rotate[2]        )
				gui.datas.set_value("tweak_rotate_z",   tweak.rotate[3]        )
				gui.datas.set_value("tweak_translate_x",tweak.translate[1]*1000)
				gui.datas.set_value("tweak_translate_y",tweak.translate[2]*1000)
				gui.datas.set_value("tweak_translate_z",tweak.translate[3]*1000)
				
			end

		end

		if name=="all" or name=="parts" then

			for i,v in ipairs(avatar.node_names) do
			
				if avatar.soul.parts[v] then
					gui.datas.set_string("part_"..v,avatar.soul.parts[v])
				else
					gui.datas.set_string("part_"..v,1) -- first is an empty no-name value
				end
			end

		end

	end
	
--[[
		gui.cache.material.load()

		local c=gui.cache.material["diffuse"]

		gui.datas.set_value("dr",c[1])
		gui.datas.set_value("dg",c[2])
		gui.datas.set_value("db",c[3])
		gui.datas.set_value("da",c[4])

		local c=gui.cache.material["specular"]

		gui.datas.set_value("sr",c[1])
		gui.datas.set_value("sg",c[2])
		gui.datas.set_value("sb",c[3])
		gui.datas.set_value("sa",c[4])

		local c=gui.cache.material["shininess"]
		gui.datas.set_value("ss",c[1])


		gui.cache.tweak.load()

		gui.datas.set_value("tweak_scale_x",gui.cache.tweak.scale[1])
		gui.datas.set_value("tweak_scale_y",gui.cache.tweak.scale[2])
		gui.datas.set_value("tweak_scale_z",gui.cache.tweak.scale[3])
		gui.datas.set_value("tweak_rotate_x",gui.cache.tweak.rotate[1])
		gui.datas.set_value("tweak_rotate_y",gui.cache.tweak.rotate[2])
		gui.datas.set_value("tweak_rotate_z",gui.cache.tweak.rotate[3])
		gui.datas.set_value("tweak_translate_x",gui.cache.tweak.translate[1])
		gui.datas.set_value("tweak_translate_y",gui.cache.tweak.translate[2])
		gui.datas.set_value("tweak_translate_z",gui.cache.tweak.translate[3])

]]

	gui.master:call_descendents(function(w)
		w.dirty=true
	end)
	
end



	return gui
end
