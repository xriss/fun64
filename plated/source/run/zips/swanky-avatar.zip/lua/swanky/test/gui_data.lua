--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl


	local datas=gui.master.datas

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

datas.set_infos({

	{
		id="test",
		help="This is a test.",
	},
	
})


-- create data
gui.data_setup=function()
	if not gui.datas then -- only setup once
	
		gui.datas=datas

		datas.new({id="list_wave"  ,class="list",  hooks=gui.hooks,num=5,list={
			{str="Sine"},
			{str="Triangle"},
			{str="Sawtooth"},
			{str="Toothsaw"},
			{str="Square"},
			{str="Whitenoise"},
		}})
		

		datas.new({id="number_1",class="number",hooks=gui.hooks,num=0.5,min=0,max=1,
			tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})

		datas.new({id="number_1step",class="number",hooks=gui.hooks,num=0.5,min=0,max=1,step=0.01})

		datas.new({id="number_100",class="number",hooks=gui.hooks,num=50,min=0,max=100,step=1})

		datas.new({id="number_pow",class="number",hooks=gui.hooks,num=5,min=0,max=10,
			tostring=function(dat,num) return tostring(math.floor(math.pow(2,num)*10)/10) end})


	end
end



	return gui
end
