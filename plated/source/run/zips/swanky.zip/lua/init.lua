#!/usr/local/bin/gamecake

local codepath=require("apps").default_paths() -- default search paths so things can easily be found
if codepath then print("Using code found at : "..codepath.."lua") end

local global=require("global") -- prevent accidental global use

-- try and update cached info in data/*/scrape.lua if possible
--pcall(function() require("swanky.paint.scrape").presets(true) end)

local opts={
--disable_sounds=true,
	times=true, -- request simple time keeping samples
	width=800,	-- display basics
	height=600,
--	overscale=7/8,
--	show="full",
	name="swanky",
	version="Alpha+10b",
	splash="data/imgs/swankypaint_splash_10b.png",
	fps=60,
	... -- include commandline opts
}

math.randomseed( os.time() ) -- try and randomise a little bit better

-- hide some swanky modes inside swanky paint
local swanky_default="--swanky"
for i=0,#opts do local v if i==0 then v=swanky_default else v=opts[i] end -- default swanky paint
	if type(v)=="string" then
		if v=="--swanky-paint" then
			opts.title="Swanky Paint"
			opts.start="swanky.paint.main"
			opts.disable_sounds=true -- we have no sounds
		elseif v=="--swanky" then
			opts.title="Swanky"
			opts.start="swanky.main"
			opts.disable_sounds=false -- need sounds
		elseif v=="--swanky-text" then
			opts.title="Swanky Text"
			opts.name="swanky.text"
			opts.start="swanky.text.main"
			opts.disable_sounds=true -- we have no sounds
		elseif v=="--swanky-beep" then
			opts.title="Swanky Beep"
			opts.start="swanky.beep.main"
			opts.disable_sounds=false -- need sounds
		elseif v=="--swanky-fun" then
			opts.title="Swanky Fun"
			opts.start="swanky.fun.main"
			opts.disable_sounds=false -- need sounds
		elseif v=="--swanky-avatar" then
			opts.title="Swanky Avatar"
			opts.start="swanky.avatar.main"
			opts.disable_sounds=true -- we have no sounds
		elseif v=="--swanky-test" then
			opts.title="Swanky Test"
			opts.start="swanky.test.main"
			opts.disable_sounds=false -- need sounds
		end
	end
end


-- setup oven with vanilla cake setup and save as a global value
global.oven=require("wetgenes.gamecake.oven").bake(opts).preheat()

-- this will busy loop or hand back control depending on the system we are running on, eitherway opts.start will run next 
return oven:serv()
