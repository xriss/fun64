--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local safewrap,safecall,export,lookup,set_env=require("wetgenes"):export("safewrap","safecall","export","lookup","set_env")




local pack=require("wetgenes.pack")
local wgrd=require("wetgenes.grd")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local zips=require("wetgenes.zips")

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,main)
	main=main or {}
	main.modname=M.modname
	
	oven.modname="swanky"
	
	local gl=oven.gl
	local cake=oven.cake
	local sheets=cake.sheets
	local opts=oven.opts
	local canvas=cake.canvas
	local views=cake.views
	local font=canvas.font
	local flat=canvas.flat

	local view=views.create({
		parent=views.get(),
		mode="full",
		vx=oven.win.width,
		vy=oven.win.height,
		vz=oven.win.height*4,
		fov=0,
	})

	local skeys=oven.rebake("wetgenes.gamecake.spew.keys")
	local srecaps=oven.rebake("wetgenes.gamecake.spew.recaps")
	skeys.setup({max_up=1}) -- also calls srecaps.setup
	skeys.set_opts("yestyping",true) -- disable widget moves with keys/joystick

	local gui=oven.rebake("swanky.gui")
	
	
main.start=function()
	main.loads()
end

main.loads=function()

	oven.cake.fonts.loads({1,"Vera","FiraSans-Regular"}) -- load fonts

--[[
	sheets.loads_and_chops({
		{"imgs/icons",1/8,1/8,1/16,1/16},
	})
	
	oven.rebake(oven.modname..".main_paint").loads()
	local fname="data/imgs/swankyicon.16x16.png"
	local g=assert(wgrd.create())
	local d=assert(zips.readfile(fname),"Failed to load "..fname)
	assert(g:load_data(d,"png")) -- last 3 letters pleaze
	assert(g:convert(wgrd.U8_RGBA)) -- make sure its true color
	assert(g:scale(64,64,1)) -- scale it up so it stays pixely
	main.grd_icon=g
]]

end
		
main.setup=function()

	for i,v in ipairs(oven.opts.args) do
	end
--	oven.enable_close_window=false -- we want to handle close messages ourselves

	main.loads()
	
	gui.setup()

--[[
	if wwin.hardcore.icon and main.grd_icon then
		wwin.hardcore.icon(oven.win[0],main.grd_icon)
	end
]]
	
end

main.clean=function()

	gui.clean()

end

-- a place to remember the last mouse position
local oldmouse={x=0,y=0}

-- push the last known mouse position back through the msg loop again
main.remouse=function()

	main.msg{
		xraw=oldmouse.x,
		yraw=oldmouse.y,
		class="mouse",
		keycode=0,
		action=0,
		time=os.time(),
		}
end


main.msg=safewrap(function(m)
--	print(wstr.dump(m))

	view.msg(m) -- fix mouse coords

	if skeys.msg(m) then m.skeys=true end -- flag this msg as handled by skeys

	gui.msg(m)
	
end)



main.update=safewrap(function()

	srecaps.step()

	gui.update()

--	main.remouse()

end)

main.draw=safewrap(function()

--  we want the main view to track the window size
	oven.win:info()
	view.vx=oven.win.width
	view.vy=oven.win.height
	view.vz=oven.win.height*4
	
	views.push_and_apply(view)
	canvas.gl_default() -- reset gl state
		
	gl.ClearColor(pack.argb4_pmf4(0xf000))
	gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

	gl.PushMatrix()
	
	font.set(cake.fonts.get("Vera")) -- default font
	font.set_size(16,0)
	
	gui.draw()
	
	
	gl.PopMatrix()

	views.pop_and_apply()
	
end)
		
	return main
end

