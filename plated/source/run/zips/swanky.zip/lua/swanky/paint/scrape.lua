
local wbake=require("wetgenes.bake")
local wstr=require("wetgenes.string")
local wzips=require("wetgenes.zips")
local wgrd=require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wwin=require("wetgenes.win")

local lfs=require("lfs")
local zip=require("zip")

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.presets=function(dohome)

	local homedir
	if wwin.flavour=="android" then homedir="/sdcard" end -- android locations are a bit poopy, so aim for the sdcard
	if not homedir then homedir=os.getenv("HOME") end  -- good for almost everyone
	if not homedir then homedir=os.getenv("USERPROFILE") end -- except windows
	homedir=(homedir or "." ).."/"

if dohome then
print("scraping "..homedir.."Pictures/swankypaint/presets for .pal.png and .set.png files")
end

	local dd=dohome and wzips.readlson("data/presets/scrape.lua") or {names={}}

	for _,ffiles in ipairs{
		(wbake.findfiles{basedir="data",dir="presets",filter="."}),
		dohome and (wbake.findfiles{basedir=homedir.."Pictures/swankypaint",dir="presets",filter="."}),
		} do
		local files=ffiles and ffiles.ret or {}
		local basedir=ffiles and ffiles.basedir or ""
		for i,v in ipairs(files) do
			local p,f,e=string.match(v, "(.-)([^\\/]-%.?([^%.\\/]*))$")
			if e~="lua" then

-- only interested in .pal.png
				if f:sub(-8):lower()==".pal.png" or f:sub(-8):lower()==".set.png" then -- load and include palette
--					print("pal",basedir.."/"..v)
					local g=assert(wgrd.create(basedir.."/"..v))
					dd.palettes=dd.palettes or {}
					local p=g:palette(0,256)
					while p[#p]==0 and p[#p-1]==0 and p[#p-2]==0 and p[#p-3]==0 do p[#p]=nil p[#p]=nil p[#p]=nil p[#p]=nil end -- trim blanks
					dd.palettes[f]=p

					dd.names[f]=basedir.."/"..v
				end

-- only interested in .set.png
				if f:sub(-8):lower()==".set.png" then -- load and include json dump
--					print("set",basedir.."/"..v)
					local g=assert(wgrd.create(basedir.."/"..v))
					dd.presets=dd.presets or {}
					dd.presets[f]=g.json and g.json.swanky or {}
					
					dd.presets[f].width=g.width
					dd.presets[f].height=g.height
					dd.presets[f].depth=g.depth

					dd.names[f]=basedir.."/"..v
				end

			end
		end
	end



	if not dohome then
		wbake.writefile("data/presets/scrape.lua",wstr.serialize(dd))
		local count=0 for f,p in pairs(dd.names) do count=count+1 end
		print("data/presets/scrape.lua updated "..(count).." files ")
	end
	
	return dd -- for live update

end
