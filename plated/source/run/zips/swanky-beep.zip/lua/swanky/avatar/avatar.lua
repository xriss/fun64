#!/usr/local/bin/gamecake

-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

-- setup some default search paths,
local apps=require("apps")
apps.default_paths()

local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wxox=require("wetgenes.xox")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,avatar)
	avatar=avatar or {}
	avatar.modname=M.modname
	
	local gl=oven.gl
	local cake=oven.cake
	local sheets=cake.sheets
	local opts=oven.opts
	local canvas=cake.canvas
	local views=cake.views
	local font=canvas.font
	local flat=canvas.flat


	local geom=oven.rebake("wetgenes.gamecake.spew.geom")
	local geom_dae=oven.rebake("wetgenes.gamecake.spew.geom_dae")

	local gui=oven.rebake(oven.modname..".gui")

	avatar.filename="/sync/kriss/blender/avatar/avatar.dae" -- try and use latest version



-- the objects we need for an avatar
	avatar.node_names={
		"body",
		"hand",
		"foot",
		"tail",
		"head",
		"hair1",
		"hair2",
		"hair3",
		"mouth",
		"beard",
		"nose",
		"eyewear",
		"eyelid",
		"eyeball",
		"eyebot",
		"eyebrow",
		"ear",
	}

-- the adjustable parts and bone names that these map to and how they map

	avatar.tweak_map={
		["head"]=	{
						bones={
							["head"]={"head","chin","hair"},
						},
					},
		["hair"]=	{
						bones={
							["hair"]={"hair"},
						},
					},
		["body"]=	{
						bones={
							["body"]={"body","belly","boob.L","boob.R"},
						},
					},
		["boob"]=	{
						bones={
							["boob.L"]={"boob.L"},
							["boob.R"]={"boob.R"},
						},
					},
		["belly"]=	{
						bones={
							["belly"]={"belly"},
						},
					},
		["tail"]=	{
						bones={
							["tail"]={"tail"},
						},
					},
		["hand"]=	{
						bones={
							["hand.L"]={"hand.L",
										"finger01.L","finger02.L","finger03.L",
										"finger11.L","finger12.L","finger13.L",
										"finger21.L","finger22.L","finger23.L",
										"finger31.L","finger32.L","finger33.L",},
							["hand.R"]={"hand.R",
										"finger01.R","finger02.R","finger03.R",
										"finger11.R","finger12.R","finger13.R",
										"finger21.R","finger22.R","finger23.R",
										"finger31.R","finger32.R","finger33.R",},
						},
					},
		["foot"]=	{
						bones={
							["foot.L"]={"foot.L","toes.L"},
							["foot.R"]={"foot.R","toes.R"},
						},
					},
		["tail"]=	{
						bones={
							["tail"]={"tail"},
						},
					},
		["mouth"]=	{
						bones={
							["mouth"]={"liptop1.L","liptop2.L","lipbot1.L","lipbot2.L","liptop1.R","liptop2.R","lipbot1.R","lipbot2.R"},
						},
					},
		["nose"]=	{
						bones={
							["nose"]={"nose"},
						},
					},
		["eye"]=	{
						bones={
							["eye.L"]={"eyeball.L","eyelid.L","eyebot.L"},
							["eye.R"]={"eyeball.R","eyelid.R","eyebot.R"},
						},
					},
		["eyebrow"]=	{
						bones={
							["eyebrow.L"]={"eyebrow.L"},
							["eyebrow.R"]={"eyebrow.R"},
						},
					},
		["ear"]=	{
						bones={
							["ear.L"]={"ear.L"},
							["ear.R"]={"ear.R"},
						},
					},
	}

	avatar.soul={
		tweaks={
			["head"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["hair"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["body"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["belly"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["boob"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["hand"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["foot"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["tail"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["mouth"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["nose"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["eye"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["eyebrow"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
			["ear"]=	{
							scale={1,1,1},
							rotate={0,0,0},
							translate={0,0,0},
							only=false,
						},
		},
		parts={
			["head"]=		"head",
			["hair1"]=		"hair",
			["hair2"]=		nil,
			["hair3"]=		nil,
			["body"]=		"body_belly",
			["hand"]=		"hand",
			["foot"]=		"foot",
			["tail"]=		nil,
			["mouth"]=		"mouth",
			["beard"]=		nil,
			["nose"]=		"nose",
			["eyewear"]=	nil,
			["ear"]=		"ear",
			["eyelid"]=		"eyelid",
			["eyeball"]=	"eyeball",
			["eyebot"]=		"eyebot",
			["eyebrow"]=	"eyebrow",
		},
		materials={
			["skin"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["lips"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["hair"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["eye"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["iris"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["black"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["color1"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["color2"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
			["color3"]=	{
							diffuse={1,1,1,1},
							specular={0,0,0,0},
							shininess={32},
						},
		},
	}

	avatar.filter={}

-- hide these bones. They are for hierarchy only and do not need to be used in the draw commands
	avatar.filter.hide_bones={
		["ear"]=true,
		["mouth"]=true,
		["nose"]=true,
		["arms"]=true,
		["legs"]=true,
		["handle"]=true,
	}

-- only show these object
	avatar.filter.show_objects={
		["body_belly"]=true,
		["hand"]=true,
		["foot_bare"]=true,
		["head"]=true,
		["hair"]=true,
		["mouth"]=true,
		["nose"]=true,
		["eyelid"]=true,
		["eyeball"]=true,
		["eyebot"]=true,
		["eyebrow"]=true,
		["ear"]=true,
	}

	avatar.filter.tweaks={}
	
	avatar.filter.materials={}

	avatar.loads=function()
	
		if not io.open(avatar.filename,"r") then avatar.filename="data/dae/avatar.dae" end -- the gc will close the file...

		avatar.gs=geom_dae.load({filename=avatar.filename,mirror=1,filter=avatar.filter})

--dprint(avatar.gs)

	end
			
	avatar.setup=function()

	end


	avatar.clean=function()

	end

	avatar.msg=function(m)

	end

	
	avatar.frame=0
	avatar.pose="breath"
	avatar.update=function()
	
		avatar.pose=gui.datas.get_string("pose") 
		avatar.anim=avatar.gs.anims[avatar.pose]
		avatar.frame=avatar.frame+0.2
		
		if avatar.anim then
			if avatar.frame>=avatar.anim.time_end then avatar.frame=avatar.frame%avatar.anim.time_end end
		end

oven.console.display("...")
local windump=function(window)
if window then
	oven.console.display(window.id or "?",window.px,window.py,window.hx,window.hy)
end
end
windump(gui.master.ids.screen)
windump(gui.master.ids.screen.splits)
windump(gui.master.ids.screen.splits and gui.master.ids.screen.splits[1])
windump(gui.master.ids.screen.splits and gui.master.ids.screen.splits[2])
windump(gui.master.ids.window_color)
	end

	avatar.draw=function()
--print(frame)

		avatar.gs.anim_update(avatar.pose,avatar.frame)

		gl.Enable(gl.DEPTH_TEST)
		gl.Enable(gl.CULL_FACE)
		
		avatar.gs.anim_draw()

		gl.Disable(gl.DEPTH_TEST)
		gl.Disable(gl.CULL_FACE)

		
	end


	avatar.get_mat=function(name,mat)
--		for i=1,#avatar.gs do local v=avatar.gs[i]
		local v=avatar.gs.anim_merged
			for mi=1,#v.mats do local m=v.mats[mi]
				if m.name==name then return m end -- return mat
			end
--		end
	end
	avatar.set_mat=function(name,mat)
--		for i=1,#avatar.gs do local v=avatar.gs[i]
		local v=avatar.gs.anim_merged
			for mi=1,#v.mats do local m=v.mats[mi]
				if m.name==name then
					for a,b in pairs(mat) do m[a]=b end  -- copy mat
				end
			end
--		end
		avatar.gs.grd_texmat=nil
	end
	avatar.rebuild=function()
		avatar.filter.show_objects={}
		for n,v in pairs(avatar.soul.parts) do
			avatar.filter.show_objects[v]=true
		end
		avatar.gs.anim_merge()
	end

	avatar.load=function(filename)

		local fp=io.open(filename,"r")

		if not fp then
			gui.show_request({
				lines={
					"Could not open file",
					filename,
				},
				ok=function()end,
			})
		else
		
			local s=fp:read("*all")
			fp:close()
			
			local tab=wjson.decode(s)

			for n1,v1 in pairs(tab) do
				for n2,v2 in pairs(v1) do
					avatar.soul[n1]=avatar.soul[n1] or {}
					avatar.soul[n1][n2]=v2
				end
			end
--			avatar.soul=tab
			
			gui.data_load("all")

		end
	end

	avatar.save=function(filename,overwrite)
	
		if not overwrite then
		
			local fp=io.open(filename,"r")
			if fp then
				fp:close()

				gui.show_request({
					lines={
						"File already exists",
						filename,
						"Overwrite?",
					},
					yes=function() avatar.save(filename,true) end,
					no=function()end,
				})
				
			else
				overwrite=true
			end

				
		
		end

		if overwrite then -- do save

			local fp=io.open(filename,"w")
			if not fp then
				gui.show_request({
					lines={
						"Could not open file",
						filename,
					},
					ok=function()end,
				})
			else
				if not fp:write(wjson.encode(avatar.soul,{pretty=true})) then
					gui.show_request({
						lines={
							"Could not write to file",
							filename,
						},
						ok=function()end,
					})
				end
				fp:close()
			end
		
		end

	end


	return avatar
end

