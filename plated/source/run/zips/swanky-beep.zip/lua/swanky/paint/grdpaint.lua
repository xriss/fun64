--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local bit=require("bit")
local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local wgrd=require("wetgenes.grd")
local zips=require("wetgenes.zips")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wsbox=require("wetgenes.sandbox")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,grdpaint)
	local grdpaint=grdpaint or {}
	grdpaint.oven=oven
	
	grdpaint.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")
	local gui=oven.rebake(oven.modname..".gui")
	local paint=oven.rebake(oven.modname..".main_paint")

-- slow but simple
local function countin3x3(g,cx,cy,t)
	cx=cx-1
	cy=cy-1
	local cw,ch=3,3
--clip
	if cx<0 then cw=cw+cx cx=0 end
	if cy<0 then ch=ch+cy cy=0 end
	if (cx+cw)>g.width  then cw=g.width -cx end
	if (cy+ch)>g.height then ch=g.height-cy end
	if cw<=0 or ch<=0 then return 0,0 end -- nothing

	local tab=g:pixels(cx,cy,cw,ch)
	local count=0
	for i,v in ipairs(tab) do
		if v==t then count=count+1 end
	end
	return count,#tab
end
-- slow but simple
local function countin3cross3(g,cx,cy,t)
	cx=cx-1
	cy=cy-1
	local cw,ch=3,3
--clip
	local x=cx+1
	local y=cy+1
	
	if cx<0 then cw=cw+cx cx=0 end
	if cy<0 then ch=ch+cy cy=0 end
	if (cx+cw)>g.width  then cw=g.width -cx end
	if (cy+ch)>g.height then ch=g.height-cy end
	if cw<=0 or ch<=0 then return 0,0 end -- nothing

	local tab={}
	if x>=0 and x<g.width then
		for i,v in ipairs(g:pixels(x,cy,1,ch)) do tab[#tab+1]=v end
	end
	if y>=0 and y<g.height then
		for i,v in ipairs(g:pixels(cx,y,cw,1)) do tab[#tab+1]=v end
	end
	local count=0
	for i,v in ipairs(tab) do
		if v==t then count=count+1 end
	end
	return count,#tab
end

	grdpaint.outline=function(gr,bg,fg)

-- we need a new grd 2 pixels bigger

		local g=wgrd.create(wgrd.U8_INDEXED,gr.width+2,gr.height+2,1)

		g:clear(bg.i)
		g:palette(0,256,gr:palette(0,256)) -- copy pal and pixels
		g:pixels(1,1,gr.width,gr.height,gr:pixels(0,0,gr.width,gr.height,""))

		local tab=g:pixels(0,0,g.width,g.height)

			for x=0,g.width-1 do
				for y=0,g.height-1 do
					local t=tab[1+x+y*g.width]
					if t==bg.i then
						local found,count=countin3cross3(gr,x-1,y-1,bg.i)
						if found~=count and count>0 then -- any non background pixels
							tab[1+x+y*g.width]=fg.i
						end
					end
				end
			end

		g:pixels(0,0,g.width,g.height,tab)

		return g
	end
	
	grdpaint.inline=function(gr,bg,fg)

-- we need a new grd 2 pixels smaller

		local g=wgrd.create(wgrd.U8_INDEXED,gr.width-2,gr.height-2,1)

		g:clear(bg.i)
		g:palette(0,256,gr:palette(0,256)) -- copy pal and pixels
		
		if gr.width<=2 or gr.height<=2 then return g end -- empty result
		
		g:pixels(0,0,gr.width-2,gr.height-2,gr:pixels(1,1,gr.width-2,gr.height-2,""))

		local tab=g:pixels(0,0,g.width,g.height)

			for x=0,g.width-1 do
				for y=0,g.height-1 do
					local t=tab[1+x+y*g.width]
					if t~=bg.i then
						local found,count=countin3cross3(gr,x+1,y+1,bg.i)
						if found>0 then -- any background pixels
							tab[1+x+y*g.width]=bg.i
						end
					end
				end
			end

		g:pixels(0,0,g.width,g.height,tab)

		return g
	end

	grdpaint.rotate=function(gr,d)
-- we need a new grd 2 pixels bigger

		local g=wgrd.create(wgrd.U8_INDEXED,gr.height,gr.width,1)

		g:palette(0,256,gr:palette(0,256)) -- copy pal

		local tab=gr:pixels(0,0,gr.width,gr.height)
		local rot={}

		if d and d<0 then
			for x=0,g.width-1 do
				for y=0,g.height-1 do
					rot[1+x+y*g.width]=tab[1+(gr.width-y-1)+x*gr.width]
				end
			end
		else
			for x=0,g.width-1 do
				for y=0,g.height-1 do
					rot[1+x+y*g.width]=tab[1+y+(gr.height-x-1)*gr.width]
				end
			end
		end

		g:pixels(0,0,g.width,g.height,rot)

		return g
	end

-- map a 32bit image down to 8bit
	grdpaint.map8=function(g,p)

		local ps=p:palette(0,256)

		local r=wgrd.create(wgrd.U8_INDEXED,g.width,g.height,g.depth)
		r:palette(0,256,ps) -- copy pal
		
		local function best(p)
			local b=0
			local d=256*256*4*4
			for i=0,255 do
				local d1=ps[1+i*4]-p[1]
				local d2=ps[2+i*4]-p[2]
				local d3=ps[3+i*4]-p[3]
				local d4=ps[4+i*4]-p[4]
				local dd=d1*d1+d2*d2+d3*d3+d4*d4*2
				if dd<=d then
					d=dd
					b=i
				end
			end
			return b
		end

		for z=0,g.depth-1 do
			for y=0,g.height-1 do
				for x=0,g.width-1 do
					local p=g:pixels(x,y,z,1,1,1)
					r:pixels(x,y,z,1,1,1,{best(p)})
				end
			end
		end
		
		return r
	end

-- find all pixels connected to the color at x,y and return a grd mask
	grdpaint.fill_mask=function(g,x,y)
		if x<0 or y<0 or x>=g.width or y>=g.height then return end -- out of range
		local r=wgrd.create(wgrd.U8_INDEXED,g.width,g.height,1)
		local idx=g:pixels(x,y,1,1)
		idx=idx[1]
		
		r:pixels(x,y,1,1,{1}) -- first fill
		local ps={[y*0x10000+x]=true} -- array of active pixels we are filling

		local leaks={{-1,0},{1,0},{0,-1},{0,1}} -- how fill spreads

		local done=false
		while not done do done=true
			for p,_ in pairs(ps) do local x,y=p%0x10000,math.floor(p/0x10000)
				for _,v in ipairs(leaks) do
					local px,py=x+v[1],y+v[2]
					if px>=0 and py>=0 and px<g.width and py<g.height then
						local pyx=py*0x10000+px
						local t=g:pixels(px,py,1,1)
						if #t and t[1]==idx then -- a pixel to fill
							local t=r:pixels(px,py,1,1)
							if t[1]==0 then -- need to fill
								r:pixels(px,py,1,1,{1}) -- fill
								ps[pyx]=true -- mark as active
								done=false
							end
						end
					end
				end
				
				ps[p]=nil -- filled
			end
		end
		
		return r
	end

	grdpaint.fill=function(g,x,y,color)
		local b=grdpaint.fill_mask(g,x,y)
		paint.brush=b
	end

	return grdpaint
end
