--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,images)
	local images=images or {}
	images.oven=oven
	
	images.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local textures=oven.rebake(oven.modname..".textures")
	local gui=oven.rebake(oven.modname..".gui")
--	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
--	local gfile=oven.rebake("swanky.gui_file")

images.load_grd=function(filename)
	images[images.idx].get_json_data() -- make sure the current image has a recent json dump
print("load",filename)
	for i,v in ipairs(images) do
		if v.filename==filename then --already loaded just select
			images.select(i)
			return
		end
	end
	images.new_grd()
	images[images.idx].load_grd(filename) -- and load into it
	images.select() -- fixpath

--	images[images.idx].set_json_data() -- make sure the gui reflects the images settings

end

images.get_filename=function()
	return images[images.idx].filename
end

images.save_grd=function(...)
	images[images.idx].get_json_data() -- make sure the image has a recent json dump
	return images[images.idx].save_grd(...)
end

images.export_grd=function(...)
	return images[images.idx].export_grd(...)
end

images.resize=function(w,h,d)
	local image=images.get()
	image.resize(w,h,d)
	images.select()
end

images.relayer=function(x,y,count)
	local image=images.get()
	image.layers_config({x=x,y=y,count=count})
	images.select()
end


images.new_grd=function(...)
	local repme
	for i,v in ipairs(images) do
		if type(v.modified)=="string" and v.modified=="repme" then repme=repme or i end -- can replace this one
	end
	if repme then
		images.select(repme) -- replace the splashscreen
	else
		images.select(images.create()) -- make a new image
	end
	images[images.idx].new_grd(...)
	images.select() -- update settings
end

images.is_modified=function()
	if type(images[images.idx].modified)=="boolean" and images[images.idx].modified==true then
		return true
	else
		return false
	end
end

images.set_modified=function(b)
	images[images.idx].modified=b
end

images.loads=function()

end

images.get=function(n)
	return images[n or images.idx]
end

images.select_next=function()
	local idx=images.idx+1
	if idx>#images then idx=1 end
	images.select(idx)
end
images.select_prev=function()
	local idx=images.idx-1
	if idx<1 then idx=#images end
	images.select(idx)
end

images.select=function(n)
	local oldidx=images.idx
	if n then images.idx=n end
	if not images[images.idx] then images.idx=1 end

-- keep gui synced
	if gui.data then
		gui.data.image_idx.max=#images -- keep max in sync
		local idx=gui.data.image_idx:value()
		if idx~=n then
				gui.data.image_idx:value(n) -- prevent race conditions
		end
	end

	if images.idx~=oldidx then -- save old and load new
	
		if images[oldidx] then
			images[oldidx].get_json_data()
		end
		
		gui.data_refresh() -- fix data bounds for newly selected image
	
		if images[images.idx] then
			images[images.idx].set_json_data()
		end

	end


	if gui.master and gui.master.ids and gui.master.ids.file_save and images[images.idx].filename then
		gui.master.ids.file_save:path( images[images.idx].filename )
		if gui.master.ids.file_export then
			gui.master.ids.file_export:path( gui.file_name_fix(images[images.idx].filename,"export"))
		end
	end
		
	gui.fixbuts()

	textures.get().upload(images[images.idx].grd,images[images.idx].frame)

	gui.data_refresh()

	return images.get()
end

images.select_layer=function(idx)
	local img=images.get()
	local g=img.grd
	if not idx then return img.layers.idx,img.layers.count end
	img.layers.idx=idx
	if img.layers.idx<1       			then img.layers.idx=1 end
	if img.layers.idx>img.layers.count	then img.layers.idx=img.layers.count end
end

images.select_frame=function(idx)
	local img=images.get()
	local g=img.grd
	if not idx then return img.frame+1,g.depth end
	img.frame=idx-1
	if img.frame<0        then img.frame=0 end
	if img.frame>=g.depth then img.frame=g.depth-1 end
	textures.get().upload(g,img.frame)
end

images.create=function()
	local idx=#images+1
	images[idx]={}
	require(oven.modname..".image").bake(oven,images[idx])
	images[idx].setup()
	return idx
end

images.delete=function(n)
print("delete image")
	if n then images.idx=n end
	if not images[images.idx] then images.idx=1 end

	if images[images.idx] then
		images[images.idx].clean()
		table.remove(images,images.idx)
	end
	
	if #images==0 then
		images.create()
	end
	
	images.select(images.idx)
end

images.setup=function()

	images.loads()
	
	if not images[1] then -- add an images
		images.select(images.create())
	end
	
	return images
end


images.clean=function()
--[[
	for i,v in ipairs(images) do
		v.clean()
		images[i]=nil
	end
]]
end

images.msg=function(m)

end

images.update=function()

	for i,v in ipairs(images) do
		v.update()
	end

end

images.draw=function(t)

	
end

	return images
end
