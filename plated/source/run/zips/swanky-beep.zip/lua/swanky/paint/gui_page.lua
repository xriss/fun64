--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
	local images=oven.rebake(oven.modname..".images")
	local textures=oven.rebake(oven.modname..".textures")
	local views=oven.rebake(oven.modname..".views")
--	local gfile=oven.rebake("swanky.gui_file")
	local grdpaint=oven.rebake(oven.modname..".grdpaint")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")
	
	local widgets_menuitem=oven.rebake("wetgenes.gamecake.widgets.menuitem")

--	local swversion=oven.opts.version.." "..(oven.opts.bake.smell or ""):upper()



gui.setup_pages=function(master)

	if gui.draw_area then -- already done
		return gui.master:resize_and_layout() -- just refresh
	end

	gui.plan_windows(master)

	local lay1=master:add({size="full"})
	gui.gui_thumb=lay1
	gui.gui_side_wrap=lay1
	gui.gui_side=lay1
	gui.gui_top_wrap=lay1
	gui.gui_top=lay1
	gui.draw_area=gui.windows

-- auto add the draging button as a child
	do
local widget_data=oven.rebake("wetgenes.gamecake.widgets.data")

		local p=gui.draw_area
		local k=p:add({style="button",class="drag",hx=12,hy=12,color=0xff000000,solid=true,cursor="hand"})
		gui.size_knob=k

		k.get_fxy=function(k)
			return	(k.px+k.hx/2)/(k.parent.hx),(k.py+k.hy/2)/(k.parent.hy)
		end

		k.set_fxy=function(k,fx,fy)
			k.px=-k.hy/2+(k.parent.hx)*fx
			k.py=-k.hy/2+(k.parent.hy)*fy
		end

		k.layout=function(widget)
			if ( k.parent.hx ~= k.parent_hx ) or ( k.parent.hy ~= k.parent_hy ) then
				k.parent_hx=k.parent.hx
				k.parent_hy=k.parent.hy
				gui.size_knob:set_fxy(gui.data.winx:get_pos(1,0),gui.data.winy:get_pos(1,0))
			end
			widget.meta.layout(widget)		
		end

		k.class_hooks=function(h,w)
			if h=="slide" then
				local fx,fy=k:get_fxy()
--print("class hooks",h,w,fx,fy)
				gui.data.winx:value(fx)
				gui.data.winy:value(fy)
--				w.meta.layout(w)
--				return true
			end
		end


	end

	gui.master:resize_and_layout() -- need to layout at least once to get everything in the right place

	gui.config_load() -- possibly reposition windows?

end


	
-- ignore
function gui.side_page(pname)
end
-- ignore
function gui.top_page(pname)
end

-- ignore
function gui.page(pname)	
	return ret
end

	gui.draw_icon=function(id,x,y,w,h)
		sheets.get("imgs/icons"):draw(id,x,y,nil,w,h)
	end

local function func_text(v)
	local text=v.text
	if not text then
		local it=gui.lookup[v.id]
		if it and it.text then
			if type(it.key)=="table" then
				text=it.text .." ( "..table.concat(it.key," ").." )"
			elseif it.key then
				text=it.text .." ("..it.key..")"
			else
				text=it.text 
			end
		else
			text=v.id
		end
	end
	return text
end

	gui.image_menu=function()
		local t={func_text=func_text,hooks=gui.hooks}
		for i,v in ipairs(images) do
			t[#t+1]={id="image_select",user=i,text=v.filename}
		end
--		t[#t+1]={id="image_delete",text="Close Current Image"}
--		t[#t+1]={id="image_delete_all",text="Close All Images"}
		return t
	end


	gui.top_menu_data={
		menu_px=0,menu_py=1,
		func_text=func_text,
		hooks=gui.hooks,
		{id="topmenu",text="File",menu_data={
			{text="Config...",menu_data={
				{id="window",user="window_prefs",  text="Prefs..."},
				{id="config",user="load",text="Load"},
				{id="config",user="save",text="Save"},
				{id="config",user="reset",text="Reset"},
				{id="config",user="reset_history",text="Reset history"},
				{id="config",user="reset_windows",text="Reset windows"},
			}},
			{text="Image...",menu_data={
				{id="window",user="window_new",    text="New..."},
				{id="window",user="window_load",   text="Load..."},
				{id="window",user="window_save",   text="Save..."},
				{id="window",user="window_export", text="Export..."},
			}},
			{id="anim_from_brushchop",text="Anim from SpriteSheet"},
			{id="swap_frames_layers",text="Swap Frames with Layers"},
			{id="image_from_anim",text="Image from Anim"},
			{id="image_from_brush",text="Image from Brush"},
			{id="image_to_brush",text="Brush from Image"},
			{id="image_delete",text="Close Current Image"},
			{id="image_delete_other",text="Close Other Images"},
			{id="image_delete_all",text="Close All Images"},
			{id="quit",text="Quit"},
		}},
		{id="topmenu",text="Window",menu_data={

			{id="window",user="window_tools",  text="Tools..."},
--			{id="window",user="window_new",    text="New"},
--			{id="window",user="window_load",   text="Load"},
--			{id="window",user="window_save",   text="Save"},
--			{id="window",user="window_export", text="Export"},
			{id="window",user="window_colors", text="Colors..."},
			{id="window",user="window_layers", text="Layers..."},
			{id="window",user="window_frames", text="Frames..."},
			{id="window",user="window_trace",  text="Trace..."},
			{id="window",user="window_uvmap",  text="UV Map..."},
--			{id="window",user="window_prefs",  text="Prefs"},
--[[

			{id="page",user="new",text="New"},

--			{id="page",user="load",text="Load"},
--			{id="page",user="save",text="Save"},
--			{id="page",user="export",text="Export"},

			{id="page",user="tools",text="Tools"},
			{id="page",user="prefs",text="Prefs"},
			{id="page",user="new",text="New"},
			{id="page",user="load",text="Load"},
			{id="page",user="save",text="Save"},
			{id="page",user="export",text="Export"},
			{id="page",user="edit_colors",text="Palette Editor"},
			{id="page",user="colors",text="Palette"},
			{id="page",user="paint",text="Paint"},
]]
		}},
		{id="topmenu",text="Images",menu_data=gui.image_menu},
		{id="topmenu",text="Layer",menu_data={
--			{id="layer_add"},
			{id="layer_chop"},
			{id="layer_join"},
			{text="Rechop...",menu_data={
				{id="layer_rechop",user="brush",text="Rechop by brushsize"},
				{id="layer_rechop",user="+1x",text="Rechop +1x"},
				{id="layer_rechop",user="-1x",text="Rechop -1x"},
				{id="layer_rechop",user="+2x",text="Rechop +2x"},
				{id="layer_rechop",user="+3x",text="Rechop +3x"},
				{id="layer_rechop",user="+4x",text="Rechop +4x"},
				{id="layer_rechop",user="+1y",text="Rechop +1y"},
				{id="layer_rechop",user="-1y",text="Rechop -1y"},
				{id="layer_rechop",user="+2y",text="Rechop +2y"},
				{id="layer_rechop",user="+3y",text="Rechop +3y"},
				{id="layer_rechop",user="+4y",text="Rechop +4y"},
			}},
			{id="layer_flatten"},
		}},
		{id="topmenu",text="Frame",menu_data={
			{id="frame_swap"},
			{id="frame_copy"},
			{id="frame_add"},
			{id="frame_del"},
		}},
		{id="topmenu",text="Brush",menu_data={
			{id="brushmode",user="paint",text="Paint Mode"},
			{id="brushmode",user="color",text="Color Mode"},
			{id="brushmode",user="replace",text="Replace Mode"},
			{text="Handle...",menu_data={
				{id="brush_handle",user="cc",text="Center Handle"},
				{id="brush_handle",user="tl",text="Top Left Handle"},
				{id="brush_handle",user="tr",text="Top Right Handle"},
				{id="brush_handle",user="bl",text="Bottom Left Handle"},
				{id="brush_handle",user="br",text="Bottom Right Handle"},
			}},
			{id="brush_outline"},
			{id="brush_inline"},
			{id="brush_flip_x"},
			{id="brush_flip_y"},
			{id="brush_half"},
			{id="brush_double"},
			{id="brush_double_x"},
			{id="brush_double_y"},
			{id="brush_rotate"},
			{id="brush_remap"},
			{id="brush_remap_from"},
			{id="brush_pal_from"},
			{text="Bitdown...",menu_data={
				{id="bitdown_brush_to_clipboard"},
				{id="bitdown_clipboard_to_brush"},
			}},
		}},
	}
	gui.setmenu=function(d,opts)
		opts=opts or {}
		d=d or gui.top_menu_data
		
		local top=gui.master.ids.menubar
		top:clean_all()

		top.menu_px=0
		top.menu_py=0
		
		widgets_menuitem.menu_add(top,{top=top,menu_data=d})

		top.px=opts.px or 0
		top.py=opts.py or 0

--		top.hidden=true
		
		gui.master:layout()
		gui.fixbuts()
		gui.master.focus=nil

--[[
		
--		top.px=opts.px or 0
--		top.py=opts.py or 0

		for i,v in ipairs(d) do
			top:add({
				class=v.class or "menuitem",
				user=v.user,
				id=v.id,
				text=func_text(v),
				
				hide_when_clicked=true,

				color=opts.color or 0xffcccccc,
				style=opts.style or "button",
				skin=opts.skin or 0,
				text_size=opts.text_size or text_size_base*1.5,
				hooks=opts.hooks or gui.hooks,
			})
		end

		top.hidden=true
		
		gui.master:layout()
		gui.fixbuts()
		gui.master.focus=nil
]]

	end
	
	gui.popmenu=function(w,opts)
		
	end
	
	gui.popmenu_old=function(w,opts)
		opts=opts or {}
		local top=gui.gui_menu
		top:clean_all()
		
		top.px=opts.px or 0
		top.py=opts.py or 0

		if w then
			local t=w.user if type(t)=="function" then t=t() end
			for i,v in ipairs(t or {}) do
				top:add({
					class="menuitem",
					user=v.user,
					id=v.id,
					text=func_text(v),
					text_align="left_center",

					hide_when_clicked=true,

					color=opts.color or 0xffcccccc,
					style=opts.style or "button",
					skin=opts.skin or 0,
					text_size=opts.text_size or text_size_base,
					hooks=opts.hooks or gui.hooks,
				})
			end
		end
		
		top.also_over={w} -- include these widgets in over test
		top.hidden=false
		top.hide_when_not="over"
		
		gui.master:layout()
		gui.fixbuts()
		gui.master.focus=nil

	end


	gui.plan_windows=function(master)
		master=master or gui.master

		local gsiz=master.grid_size or 24

		local def_window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
			} do it[n]=it[n] or v end
			
			return parent.windows:add(it)
		end

		local def_title=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				cursor="hand",
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_menudrop=function(parent,it)
			for n,v in pairs{
				class="menudrop",
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_xslide=function(parent,it)
			for n,v in pairs{
				class="slide",
				hooks=gui.hooks,
				datx=it.data,
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end
		
		local def_square_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*2,
				hy=gsiz*2,
				px=2,
				py=2,
				color=0,
				solid=true,
				cursor="hand",
				class="button",
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_tiny_square_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*1,
				hy=gsiz*1,
				px=0,
				py=0,
				color=0,
				solid=true,
				cursor="hand",
				class="button",
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add(it)
		end

		local def_half_square_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*2,
				hy=gsiz*1,
				px=2,
				py=2,
				color=0,
				solid=true,
				cursor="hand",
				class="button",
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_pal_buttons=function(parent,pw,ph,_c)
			local widget=parent:add({hx=pw,hy=ph,class="fill"})
			local c=gui.data.colors:value()
			if _c < c then c=_c end -- number of color buttons to display

			if c<=8 then
				for i=0,7 do
					local id=( (i%2)*4 + math.floor(i/2) )
					widget:add_border({hx=pw/2,hy=ph/4,px=1,py=1,color=0xffffffff,id="color",user=id,hooks=gui.hooks,highlight="none",class="button",style="button",skin=1})
				end
			elseif c<=16 then
				for i=0,15 do
					local id=( (i%2)*8 + math.floor(i/2) )
					widget:add_border({hx=pw/2,hy=ph/8,px=1,py=1,color=0xffffffff,id="color",user=id,hooks=gui.hooks,highlight="none",class="button",style="button",skin=1})
				end
			elseif c<=32 then
				for i=0,31 do
					local id=( (i%4)*8 + math.floor(i/4) )
					widget:add_border({hx=pw/4,hy=ph/8,px=1,py=1,color=0xffffffff,id="color",user=id,hooks=gui.hooks,highlight="none",class="button",style="button",skin=1})
				end
			end
			
		end
		
		local def_pal_selected=function(parent,sw,sh)
			sw=sw or 1
			sh=sh or 1
			parent:add({hx=gsiz*2*sw,hy=gsiz*2*sh}):
			add({hx=gsiz*2*sw-4,hy=gsiz*2*sh-4,px=2,py=2,color=gui.color_bg.argb,hooks=gui.hooks,highlight="none",class="button",style="button",skin=0,id="bg_color"}):
				add({hx=gsiz*1.25*sw,hy=gsiz*1.25*sh,px=(gsiz*0.75*sw-4)/2,py=(gsiz*0.75*sh-4)/2,color=gui.color_fg.argb,highlight="none",style="button",skin=1,id="fg_color"})
		end

		local screen=gui.master:add({size="full",class="screen",id="screen"})
		gui.screen=screen
		gui.windows=screen.windows

		local split=screen:add({class="split",size="full",split_axis="y"})
		local top=split:add({size="fullx fity",fbo=true,style="flat",highlight="none",color=0,solid=true})
		split:insert(screen.windows)

		local topbar=top:add({size="minmax",smode="topleft",hx_min=gsiz*60,hy_max=gsiz*1,class="fill"})
		local three=topbar:add({hx=gsiz*30,hy=gsiz*1,class="three"})
		local menu =three:add({hx=gsiz*4,hy=gsiz*1,class="menubar",id="menubar",always_draw=true})
		local title=three:add({hx=gsiz*1,hy=gsiz*1,text="Welcome to swanky paint ( "..gui.swversion.." )",id="infobar"})
		local buttons=topbar:add({px=0,py=0,hx=gsiz*30,hy=gsiz*1,class="fill",id="infobar_part2"})

		widgets_menuitem.menu_add(menu,{top=menu,menu_data=gui.top_menu_data})

		def_tiny_square_button(buttons,{text="Mask",hooks=gui.hooks,id="brushmode",user="paint"})
		def_tiny_square_button(buttons,{text="Color",hooks=gui.hooks,id="brushmode",user="color"})
		def_tiny_square_button(buttons,{text="Copy",hooks=gui.hooks,id="brushmode",user="replace"})

		buttons:add({hx=gsiz*2,hy=gsiz,color=0,class="button",text="Frame",id="frame_show",hooks=gui.hooks})
		buttons:add({hx=gsiz*4,hy=gsiz,color=0,id="frame_idx",hooks=gui.hooks,class="slide",data=gui.data.frame_idx,datx=gui.data.frame_idx})

		buttons:add({hx=gsiz*2,hy=gsiz,color=0,class="button",text="Layer",id="layer_show",hooks=gui.hooks,state="none"})
		buttons:add({hx=gsiz*4,hy=gsiz,color=0,id="layer_idx",hooks=gui.hooks,class="slide",data=gui.data.layer_idx,datx=gui.data.layer_idx})

		buttons:add({hx=gsiz*2,hy=gsiz,color=0,class="button",text="Image",id="image_show",hooks=gui.hooks,state="none"})
		buttons:add({hx=gsiz*4,hy=gsiz,color=0,id="image_idx",hooks=gui.hooks,class="slide",data=gui.data.image_idx,datx=gui.data.image_idx})

		buttons:add({hx=gsiz*2,hy=gsiz,color=0,class="button",text="Zoom",id="zoom_show",hooks=gui.hooks,state="none"})
		buttons:add({hx=gsiz*4,hy=gsiz,color=0,id="zoom_idx",hooks=gui.hooks,class="slide",data=gui.data.zoom_idx,datx=gui.data.zoom_idx})

		buttons:add({hx=gsiz*1,hy=gsiz,color=0,class="button",text="Pr",id="process_show",hooks=gui.hooks,state="selected"})

		buttons:add({hx=gsiz*2,hy=gsiz*1,color=0x3f00ff00,class="button",style="button",id="quicksave",text="Save",hooks=gui.hooks})

-- add super resize hook
		do
			local old=top.resize
			top.resize=function(widget) -- super custom layout
				if screen.hx < gsiz*45 then topbar.hx_min=gsiz*30	topbar.hy_max=gsiz*2
				else						topbar.hx_min=gsiz*60	topbar.hy_max=gsiz*1
				end
				return old(widget)
			end
		end

local canvas=def_window(screen,{px=gsiz*0,py=gsiz*0,hx=gsiz*4,size="fit",id="window_tools",title="Tools"}).win_canvas

		def_square_button(canvas,{text="Load",id="window",user="window_load",hooks=gui.hooks,})
		def_square_button(canvas,{text="New",id="window",user="window_new",hooks=gui.hooks})

		def_square_button(canvas,{text="Fill",id="fill",hooks=gui.hooks})
		def_square_button(canvas,{text="Scroll",id="scroll",hooks=gui.hooks})

		def_square_button(canvas,{text="Zoom",id="magnify",hooks=gui.hooks})
		def_square_button(canvas,{text="Pickup",id="pickup",hooks=gui.hooks})

		def_square_button(canvas,{text="Paint",id="paint",hooks=gui.hooks})
		def_square_button(canvas,{text="Dot",id="paint_dot",hooks=gui.hooks})

		def_square_button(canvas,{text="Circle",id="paint_circle",hooks=gui.hooks})
		def_square_button(canvas,{text="Swap",id="frame_swap",hooks=gui.hooks})

		def_square_button(canvas,{text="Clear",id="clear",hooks=gui.hooks})
		def_square_button(canvas,{text="Undo",id="undo",hooks=gui.hooks})

		def_pal_selected(canvas)

		def_square_button(canvas,{text="CMap",id="window",user="window_colors",hooks=gui.hooks})

		def_pal_buttons(canvas,gsiz*4,gsiz*8,32)

		def_half_square_button(canvas,{text="<",id="idx_sub",hooks=gui.hooks})
		def_half_square_button(canvas,{text=">",id="idx_add",hooks=gui.hooks})

--[[
local canvas=def_window(screen,{px=gsiz*4.5,py=gsiz*4.5,hx=gsiz*4,size="fit",id="window_menu",title="Menu"}).win_canvas

	def_square_button(canvas,{text="Tools"	,hooks=gui.hooks,id="page",user="tools"})
	def_square_button(canvas,{text="Prefs"	,hooks=gui.hooks,id="page",user="prefs"})
	def_square_button(canvas,{text="Load"	,hooks=gui.hooks,id="page",user="load"})
	def_square_button(canvas,{text="New"	,hooks=gui.hooks,id="page",user="new"})
	def_square_button(canvas,{text="Save"	,hooks=gui.hooks,id="page",user="save"})
	def_square_button(canvas,{text="Export" ,hooks=gui.hooks,id="page",user="export"})
	def_square_button(canvas,{text="CMap"   ,hooks=gui.hooks,id="page",user="edit_colors"})
	def_square_button(canvas,{text="Colors" ,hooks=gui.hooks,id="page",user="colors"})
	def_square_button(canvas,{text="Paint"  ,hooks=gui.hooks,id="page",user="paint"})
	def_square_button(canvas,{text="trace"  ,hooks=gui.hooks,id="page",user="trace"})
	def_square_button(canvas,{text="layers" ,hooks=gui.hooks,id="page",user="layers"})
	def_square_button(canvas,{text="frames" ,hooks=gui.hooks,id="page",user="frames"})
	def_square_button(canvas,{text="uvmap"  ,hooks=gui.hooks,id="page",user="uvmap"})
]]

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_trace",title="Trace",hidden=true}).win_canvas

--	canvas:add_border({hx=gsiz*4,hy=gsiz,px=2,py=2,color=0,class="button",text="Menu",id="page",user="menu",hooks=gui.hooks})

	canvas:add({hx=gsiz*6,hy=gsiz,text="Trace Alpha"})
	canvas:add_border({hx=gsiz*10,hy=gsiz,px=2,py=2,class="slide",color=0,datx=gui.data.trace_alpha,data=gui.data.trace_alpha,hooks=gui.hooks})


	canvas:add({hx=gsiz*16,hy=gsiz,text="Choose Image"})
	canvas:add_border({hx=gsiz*15,hy=gsiz*21,px=2,py=2,class="file",id="file_trace",hooks=gui.hooks,
		history=paint.file_history,
		})
	gui.master.ids.file_trace:path(paint.basepath)

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_uvmap",title="UV Map",hidden=true}).win_canvas

--	canvas:add_border({hx=gsiz*4,hy=gsiz*1,px=2,py=2,color=0,class="button",text="Menu",id="page",user="menu",hooks=gui.hooks})
--	canvas:add({hx=gsiz*11,hy=gsiz*1})
--	canvas:add_border({hx=gsiz*4,hy=gsiz*1,px=2,py=2,color=0,class="button",text="File",id="page",user="uvmap",hooks=gui.hooks})
--	canvas:add({hx=gsiz*1,hy=gsiz*1})
--	canvas:add_border({hx=gsiz*4,hy=gsiz*1,px=2,py=2,color=0,class="button",text="Opts",id="page",user="uvmap_opts",hooks=gui.hooks})

	canvas:add({hx=gsiz*6,hy=gsiz*1,text="Enable 3D"})
	canvas:add_border({hx=gsiz*10,hy=gsiz*1,px=2,py=2,class="slide",color=0,datx=gui.data.uvmap_active,data=gui.data.uvmap_active,hooks=gui.hooks})

	canvas:add({hx=gsiz*6,hy=gsiz*1,text="Lightness"})
	canvas:add_border({hx=gsiz*10,hy=gsiz*1,px=2,py=2,class="slide",color=0,datx=gui.data.uvmap_light,data=gui.data.uvmap_light,hooks=gui.hooks})

	canvas:add({hx=gsiz*6,hy=gsiz*1,text="Darkness"})
	canvas:add_border({hx=gsiz*10,hy=gsiz*1,px=4,py=4,class="slide",color=0,datx=gui.data.uvmap_dark,data=gui.data.uvmap_dark,hooks=gui.hooks})

	canvas:add({hx=gsiz*6,hy=gsiz*1,text="Bumpiness"})
	canvas:add_border({hx=gsiz*10,hy=gsiz*1,px=4,py=4,class="slide",color=0,datx=gui.data.uvmap_bump,data=gui.data.uvmap_bump,hooks=gui.hooks})



	canvas:add({hx=gsiz*16,hy=gsiz*1,text="Choose a 3D collada .dae file"})
	canvas:add_border({hx=gsiz*15,hy=gsiz*18,px=2,py=2,class="file",id="file_uvmap",hooks=gui.hooks,
		history=paint.file_history,
		})
	gui.master.ids.file_uvmap:path(paint.basepath)

--[[
local canvas=def_window(screen,{px=gsiz*6,py=gsiz*6,hx=gsiz*4,size="fit",id="window_paint",title="Paint"}).win_canvas

	def_square_button(canvas,{text="Scroll",hooks=gui.hooks,id="scroll"})
	def_square_button(canvas,{text="Pickup",hooks=gui.hooks,id="pickup"})
	def_square_button(canvas,{text="Paint",hooks=gui.hooks,id="paint"})

	def_square_button(canvas,{text="Dot",hooks=gui.hooks,id="paint_dot"})
	def_square_button(canvas,{text="Block",hooks=gui.hooks,id="paint_block"})
	def_square_button(canvas,{text="Circle",hooks=gui.hooks,id="paint_circle"})
	def_square_button(canvas,{text="Dash",hooks=gui.hooks,id="paint_dash"})
	def_square_button(canvas,{text="Line",hooks=gui.hooks,id="paint_line"})
	def_square_button(canvas,{text="Grow",hooks=gui.hooks,id="paint_grow"})
	def_square_button(canvas,{text="Shrink",hooks=gui.hooks,id="paint_shrink"})

	def_square_button(canvas,{text="Mask",hooks=gui.hooks,id="brushmode",user="paint"})
	def_square_button(canvas,{text="Color",hooks=gui.hooks,id="brushmode",user="color"})
	def_square_button(canvas,{text="Copy",hooks=gui.hooks,id="brushmode",user="replace"})

	def_square_button(canvas,{text="Zoom",hooks=gui.hooks,id="magnify"})
	def_square_button(canvas,{text="Mooz",hooks=gui.hooks,id="magnify_right"})

	def_square_button(canvas,{text="Swap",id="frame_swap",hooks=gui.hooks})
	def_square_button(canvas,{text="Clear",id="clear",hooks=gui.hooks})

	def_square_button(canvas,{text="Undo",id="undo",hooks=gui.hooks})
	def_square_button(canvas,{text="CMap"  ,hooks=gui.hooks,id="page",user="edit_colors"})

]]

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_colors",title="Colors",hidden=true}).win_canvas



--	canvas:add_border({hx=gsiz*2,hy=gsiz*2,px=2,py=2,color=0,class="button",text="Menu",id="page",user="menu",hooks=gui.hooks})
--	canvas:add_border({hx=gsiz*2,hy=gsiz*2,px=2,py=2,color=0,class="button",text="Colors",id="page",user="colors",hooks=gui.hooks})

	def_pal_selected(canvas,2,1)
	

	if oven.opts.bake.smell=="thin" then
	
		canvas:add({hx=canvas.hx,hy=gsiz})
		canvas:add_border({hx=canvas.hx,hy=gsiz*8,px=16,py=16,class="fill",text="Palette editor is disabled."})
	
	else
--##--FAT




























--##--ALL
	end


local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_prefs",title="Prefs",hidden=true}).win_canvas


	canvas:add_border({hx=gsiz*2,hy=gsiz*2,px=4,py=4,color=0,class="button",text="About",hooks=gui.hooks,id="about"})

	canvas:add({hx=gsiz*14,hy=gsiz*2,text="Swanky Paint ( "..gui.swversion.." )"})

	canvas:add({hx=gsiz*8,hy=gsiz,text="Window"})
	canvas:add_border({hx=gsiz*8,hy=gsiz,px=4,py=4,class="menudrop",color=0,data=gui.data.win,hooks=gui.hooks})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=0,class="slide",color=0,datx=gui.data.winx,data=gui.data.winx,hooks=gui.hooks})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=0,class="slide",color=0,datx=gui.data.winy,data=gui.data.winy,hooks=gui.hooks})

	canvas:add({hx=gsiz*16,hy=gsiz,text="Snap Size"})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=0,class="slide",color=0,datx=gui.data.snapx,data=gui.data.snapx,hooks=gui.hooks})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=0,class="slide",color=0,datx=gui.data.snapy,data=gui.data.snapy,hooks=gui.hooks})
	

	canvas:add({hx=gsiz*16,hy=gsiz,text="Black Line"})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=0,class="slide",color=0,datx=gui.data.grid,data=gui.data.grid,hooks=gui.hooks})


	if oven.opts.bake.smell=="thin" then
	
		canvas:add_border({hx=gsiz*16,hy=320-32,px=16,py=16,class="fill",text="Settings are disabled."})

	else
--##--FAT






















--##--ALL
	end


local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_new",title="New",hidden=true}).win_canvas

	if oven.opts.bake.smell=="thin" then
	
		canvas:add_border({hx=gsiz*16,hy=gsiz*8,px=16,py=16,class="fill",text="New images are disabled."})
	
	else
--##--FAT




















































--##--ALL
	end
	

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_layers",title="Layers",hidden=true}).win_canvas

	

	local t=canvas:add_border({hx=gsiz*16,hy=gsiz,px=0,py=0,class="fill"})
	t:add({hx=gsiz*7,hy=gsiz,text="Layers"})
	t:add_border({hx=gsiz*4,hy=gsiz,px=2,py=2,class="textedit",color=0,data=gui.data.layer_x,hooks=gui.hooks})
	t:add({hx=gsiz*1,hy=gsiz,text="x"})
	t:add_border({hx=gsiz*4,hy=gsiz,px=2,py=2,class="textedit",color=0,data=gui.data.layer_y,hooks=gui.hooks})
	
	canvas:add_border({hx=gsiz*8,hy=gsiz*1,px=16,py=4,color=0,class="button",text="Chop",hooks=gui.hooks,id="layer_rechop"})
	canvas:add_border({hx=gsiz*8,hy=gsiz*1,px=16,py=4,color=0,class="button",text="Join",hooks=gui.hooks,id="layer_join"})

	canvas:add({hx=gsiz*16,hy=gsiz*1})

	canvas:add_border({hx=gsiz*8,hy=gsiz*1,px=16,py=4,color=0,class="button",text="Flatten",hooks=gui.hooks,id="layer_flatten"})

	canvas:add({hx=gsiz*16,hy=gsiz*1})

	canvas:add({hx=gsiz*16,hy=gsiz*1,text="Layer key list."})
	canvas:add_border({hx=gsiz*16,hy=gsiz*1,px=16,py=2,class="textedit",color=0,data=gui.data.layer_key_list,hooks=gui.hooks})

	canvas:add({hx=gsiz*16,hy=gsiz*1})


local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_frames",title="Frames",hidden=true}).win_canvas

	

	canvas:add_border({hx=gsiz*8,hy=gsiz,px=16,py=4,color=0,class="button",text="Add Frame",hooks=gui.hooks,id="frame_add"})
	canvas:add_border({hx=gsiz*8,hy=gsiz,px=16,py=4,color=0,class="button",text="Del Frame",hooks=gui.hooks,id="frame_del"})

	canvas:add({hx=gsiz*16,hy=gsiz})

	canvas:add({hx=gsiz*16,hy=gsiz,text="Frame key list."})
	canvas:add_border({hx=gsiz*16,hy=gsiz,px=16,py=2,class="textedit",color=0,data=gui.data.frame_key_list,hooks=gui.hooks})

	canvas:add({hx=gsiz*16,hy=gsiz*1})

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_load",title="Load",hidden=true}).win_canvas

	if oven.opts.bake.smell=="thin" then
	
		canvas:add_border({hx=gsiz*16,hy=gsiz*16,px=16,py=16,class="fill",text="Loading is disabled."})
	
	else
--##--FAT







--##--ALL
	end


local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_save",title="Save",hidden=true}).win_canvas

	if oven.opts.bake.smell=="thin" then
	
		canvas:add_border({hx=gsiz*16,hy=gsiz*16,px=16,py=16,class="fill",text="Saving is disabled."})
	
	else
--##--FAT







--##--ALL
	end

local canvas=def_window(screen,{px=gsiz*4,py=gsiz*0,hx=gsiz*16,size="fit",id="window_export",title="Export",hidden=true}).win_canvas

	if oven.opts.bake.smell=="thin" then
	
		canvas:add_border({hx=gsiz*16,hy=gsiz*16,px=16,py=16,class="fill",text="Exporting is disabled."})
	
	else
--##--FAT







--##--ALL
	end

		gui.master:call_descendents(function(w) w:set_dirty() end)

		gui.master:resize_and_layout() -- need to layout at least once to get everything in the right place


--gui.show_request{lines={"test"},ok=function() print"OK" end}
--gui.show_file_request{lines={"test"},ok=function() print"OK" end}

	end


	gui.show_quit=nil
	gui.show_quit_request=function(opts)
		if gui.show_quit then
			gui.show_quit=gui.show_quit+1
			if gui.show_quit>=3 then -- alt+f4 three times to force quit
				oven.next=true
			end
		else
			gui.show_quit=1
			opts=opts or {}
			opts.lines={"","Are you sure you want to quit?",""}--,"Press close three time to force quit.",""}
			opts.yes=function() oven.next=true gui.show_quit=nil end
			opts.no=function() gui.show_quit=nil end
			gui.show_request(opts)
		end
	end

	gui.show_request=function(opts)

		local master=gui.master
		local gsiz=master.grid_size or 24
		local screen
		master:call_descendents(function(it)
			if it.class=="screen" then screen=it end
		end)

		local def_window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
				flags={nodrag=true,nobar=true},
			} do it[n]=it[n] or v end
			
			return parent:add{class="center",solid=true,transparent=0xcc000000}:add(it)
		end

		local def_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local window=def_window(screen,{px=screen.hx/2,py=screen.hy/2,hx=gsiz*10,size="fit",id="request",title=""})
		local canvas=window.win_canvas
		
		for i,v in ipairs(opts.lines or {} ) do

			local it={
			
				hx=gsiz*10,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
				text=v
			}
			canvas:add_border(it)
		end
		
		local hooks=function(act,w,dat)
		
			if act=="click" then

				window.parent:remove() -- hide/delete
			
				gui.master:layout()

				if opts[w.id] then (opts[w.id])() end

			end
		
		end
		
		if opts.sorry then
			def_button(canvas,{hooks=hooks,class="button",id="sorry",text="Sorry",hx=gsiz*10})
		end

		if opts.yes then
			def_button(canvas,{hooks=hooks,class="button",id="yes",text="Yes"})
		end
		if opts.ok then
			def_button(canvas,{hooks=hooks,class="button",id="ok",text="OK"})
		end
		if opts.no then
			def_button(canvas,{hooks=hooks,class="button",id="no",text="No"})
		end

		gui.master:layout() -- need to layout at least once to get everything in the right place
	
	end
	
	gui.show_file_request=function(opts)

		local master=gui.master
		local gsiz=master.grid_size or 24
		local screen
		master:call_descendents(function(it)
			if it.class=="screen" then screen=it end
		end)

--gui.data.file_name_fix("save")

		local def_window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
				flags={nodrag=true,nobar=true},
			} do it[n]=it[n] or v end
			
			return parent:add{class="center",solid=true,transparent=0xcc000000}:add(it)
		end

		local def_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local window=def_window(screen,{px=screen.hx/2,py=screen.hy/2,hx=gsiz*10,size="fit",id="request",title=""})
		local canvas=window.win_canvas
		
		for i,v in ipairs(opts.lines or {} ) do

			local it={
			
				hx=gsiz*10,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
				text=v
			}
			canvas:add_border(it)
		end
		
		local hooks=function(act,w,dat)
		
			if act=="click" then

				window.parent:remove() -- hide/delete
			
				gui.master:layout() -- need to layout at least once to get everything in the right place

				if opts[w.id] then (opts[w.id])() end

			end
		
		end
		
		canvas:add_border({hx=gsiz*10,hy=gsiz*15,px=0,py=0,class="file",id="file",hooks=gui.hooks,
			history=paint.file_history,
		})

		if opts.yes then
			def_button(canvas,{hooks=hooks,class="button",id="yes",text="Yes"})
		end
		if opts.ok then
			def_button(canvas,{hooks=hooks,class="button",id="ok",text="OK"})
		end
		if opts.no then
			def_button(canvas,{hooks=hooks,class="button",id="no",text="No"})
		end

		gui.master:layout() -- need to layout at least once to get everything in the right place
	
	end


	return gui
end
