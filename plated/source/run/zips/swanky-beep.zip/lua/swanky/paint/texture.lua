--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wzips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,texture)
	local texture=texture or {}
	texture.oven=oven
	
	texture.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")

	local paint=oven.rebake(oven.modname..".main_paint")

	local bloom=oven.rebake(oven.modname..".bloom")

texture.check_size=function(grd)
	
	if texture.width == grd.width and texture.height == grd.height then return end -- nothing to fix

	texture.width=grd.width
	texture.height=grd.height
	
	texture.texture_width=images.uptwopow(texture.width)
	texture.texture_height=images.uptwopow(texture.height)

	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.TexImage2D(
		gl.TEXTURE_2D,
		0,
		gl.RGBA,
		256,
		1,
		0,
		gl.RGBA,
		gl.UNSIGNED_BYTE,
		string.rep(string.char(0), 256 * 1 * 4) ) --blank the texture

	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
	gl.TexImage2D(
		gl.TEXTURE_2D,
		0,
		gl.LUMINANCE,
		texture.texture_width,
		texture.texture_height,
		0,
		gl.LUMINANCE,
		gl.UNSIGNED_BYTE,
		string.rep(string.char(0), texture.texture_width * texture.texture_height) ) --blank the texture

	gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
	gl.TexImage2D(
		gl.TEXTURE_2D,
		0,
		gl.RGB,
		texture.texture_width,
		texture.texture_height,
		0,
		gl.RGB,
		gl.UNSIGNED_BYTE,
		string.rep(string.char(128,128,255), texture.texture_width * texture.texture_height ) )


end


texture.loads=function()
--	print(wstr.dump(texture.grd))

	texture.width=0
	texture.height=0

	texture.cmap_id=assert(gl.GenTexture())
	texture.bmap_id=assert(gl.GenTexture())
	texture.norm_id=assert(gl.GenTexture())
	
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )	
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)
	
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)
	
	gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)

	gl.CheckError()

	local filename="lua/"..(oven.modname..".texture"):gsub("%.","/")..".glsl"
	gl.shader_sources( wzips.readfile(filename) , filename )

--	gl.CheckError()

end

texture.upload=function(grd,f)
--print("upload",grd.depth,f)

	texture.check_size(grd)
	
	texture.layers=grd.image and grd.image.layers
	
	local w=gui.master and gui.master.ids and gui.master.ids.process_show
	if w and w.state=="selected" and gui.data and gui.data.attr_redux and gui.data.attr_redux.num<256 then -- perform attr clash
		local image=grd.image
		grd=grd:duplicate()
		grd.image=image
		grd:attr_redux(gui.data.attr_width.num,gui.data.attr_height.num,gui.data.attr_redux.num,gui.data.attr_sub.num,gui.data.attr_back.num)
	end

	f=f or 0
	if f <  0 then f=0 end
	if f >= grd.depth then f=grd.depth-1 end

	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
	gl.TexSubImage2D(
		gl.TEXTURE_2D,
		0,
		0,0,
		grd.width,
		grd.height,
		gl.LUMINANCE,
		gl.UNSIGNED_BYTE,
		pack.tolightuserdata( grd.data , grd.width*grd.height*f ) )
		
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.TexSubImage2D(
		gl.TEXTURE_2D,
		0,
		0,0,
		256,
		1,
		gl.RGBA,
		gl.UNSIGNED_BYTE,
		pack.tolightuserdata( grd.cmap , 0 ) )

	if f==1 and gui.data.uvmap_active:value()>0 then -- convert and upload the normal bumpmap

		local g=grd:clip(0,0,1,grd.width,grd.height,1)
		g=assert(g:create_convert(wgrd.FMT_U8_LUMINANCE))
		g=assert(g:create_normal())
--		g:save("_norm.png")
--		print(g.data)

		gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			g.width,
			g.height,
			gl.RGB,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( g.data , 0 ) )
		
	end

	gl.Flush()
end

texture.setup=function()

	texture.width=0
	texture.height=0
	

--	texture.loads()
	
	return texture
end

texture.clean=function()

--print("del text")
	gl.DeleteTexture(texture.bmap_id) texture.bmap_id=nil
	gl.DeleteTexture(texture.cmap_id) texture.cmap_id=nil
	gl.DeleteTexture(texture.cmap_id) texture.norm_id=nil

end

texture.msg=function(m)

end


texture.update=function()
end

texture.p_layer=function(p,i)
	if texture.layers then
		if not i then i=1 end
		if i<1 then i=1 end
		if i>texture.layers.count then i=texture.layers.count end
		local lw=texture.layers.width
		local lh=texture.layers.height
		local lx=lw*math.floor((i-1)%texture.layers.x)
		local ly=lh*math.floor((i-1)/texture.layers.x)
		gl.Uniform4f( p:uniform("img_siz"), lw,lh,texture.texture_width,texture.texture_height )
		gl.Uniform4f( p:uniform("img_off"), lx,ly,0,0 )
	else
		gl.Uniform4f( p:uniform("img_siz"), texture.width,texture.height,texture.texture_width,texture.texture_height )
		gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	end
end

texture.draw=function(view)

	if not view then return end

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p=gl.program("swpaint_image8")	
	local e=gui.data and gui.data.escher and gui.data.escher:value() 
	if e then e=gui.data.escher.list[e] end
	if e then
		if     e.str=="pixel" then
			p=gl.program("swpaint_image8")
		elseif e.str=="scan" then
			p=gl.program("swpaint_image8_scan")
		elseif e.str=="bleed" then
			p=gl.program("swpaint_image8_bleed")
		elseif e.str=="escher" then
			p=gl.program("swpaint_image8_escher"..1)
		elseif e.str=="trixel" then
			p=gl.program("swpaint_image8_escher"..2)
		end
	end

	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )
	
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )
	gl.Uniform4f( p:uniform("img_flags"),view.grid,gui.data.snapx:value(),gui.data.snapy:value(),(main.drawframe%4096)/4096 )
	gl.Uniform4f( p:uniform("img_lines"), view.lines[1],view.lines[2],view.lines[3],view.lines[4] )
	
	local c=math.abs((main.drawframe%64)-32)/32
	c=((c*c)/2)+0.25
	gl.Uniform4f( p:uniform("img_line_color"), c,c,c,1 )
	
	if view.export then
		gl.Uniform4f( p:uniform("img_alpha_color"), 0.0,0.0,0.0,0.0 )	
	else
--		gl.Uniform4f( p:uniform("img_alpha_color"), 0.0,0.0,0.0,0.0 )	
--		gl.Uniform4f( p:uniform("img_alpha_color"), 1/16,1/16,1/16,1.0 )	
		gl.Uniform4f( p:uniform("img_alpha_color"), 1/8,1/8,1/8,1.0 )	
	end


	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	if gui.master.ids.layer_show and gui.master.ids.layer_show.state=="selected" then
		for i=texture.layers and texture.layers.count or 1,1,-1 do
			if i>1 then
				gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,0 )
			end
			texture.p_layer(p,i)
			gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
		end
	else
		texture.p_layer(p,texture.layers.idx)
		gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
	end
end


texture.build_bloom=function()


	bloom.set_size(texture.width,texture.height)
	local fbo=bloom.get_input_fbo()
	fbo:bind_frame()
	gl.Viewport( 0 , 0 , texture.width , texture.height )

	local data={
		-1,	-1,		0,		0,										0,
		 1,	-1,		0,		texture.width/texture.texture_width,	0,
		-1,	 1,		0,		0,										texture.height/texture.texture_height,
		 1,	 1,		0,		texture.width/texture.texture_width,	texture.height/texture.texture_height,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_image8_writebloom")
	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

--	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
--	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

--	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	
	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,1 )
	if gui.master.ids.layer_show and gui.master.ids.layer_show.state=="selected"  then
		for i=texture.layers and texture.layers.count or 1,1,-1 do
			texture.p_layer(p,i)
			gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
			gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,0 )
		end
	else
		texture.p_layer(p,texture.layers.idx)
		gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
	end

	fbo.bind_frame() -- restore old frame
	canvas.layout.restore()
	
	bloom.process()
	
end

texture.draw_bloom=function(view)


	if not view then return end

	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	local t=gui.data.bloom:value()	--/texture.layers.count
	gl.Uniform4f( p:uniform("color"), 0.5*t,0.5*t,0.5*t,0 )
	
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,1 )
	if gui.master.ids.layer_show and gui.master.ids.layer_show.state=="selected" then
		for i=texture.layers and texture.layers.count or 1,1,-1 do
			texture.p_layer(p,i)
			gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
			gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,0 )
		end
	else
		texture.p_layer(p,texture.layers.idx)
		gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
	end
end


texture.draw_qube=function(view)


	if not view then return end
	if not texture.layers then return end

	local	qubesize=                                               texture.layers.width
			qubesize=qubesize>texture.layers.height and qubesize or texture.layers.height
			qubesize=qubesize>texture.layers.count  and qubesize or texture.layers.count
	
	local fbosize=qubesize*8

	bloom.set_size(fbosize,fbosize)
	local fbo=bloom.get_input_fbo()
	fbo:bind_frame()
	gl.Viewport( 0 , 0 , fbosize , fbosize )

	local layout=oven.cake.layouts.create{parent={x=0,y=0,w=fbo.w,h=fbo.h}}
	layout.project23d(fbosize,fbosize,0.25,fbosize*4)

	gl.ClearColor(pack.argb4_pmf4(0xf000))
	gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

	gl.MatrixMode(gl.PROJECTION)
	gl.PushMatrix()
	gl.LoadMatrix( layout.pmtx )

	gl.MatrixMode(gl.MODELVIEW)
	gl.PushMatrix()
	gl.LoadIdentity()
	gl.Translate(0,0,-fbosize*2) -- top left corner is origin

--	gl.Translate(-qubesize/2,-qubesize/2,-qubesize*2) -- top left corner is origin
	gl.Scale(6,6,6)

	gl.Rotate(paint.x*2,0,1,0);
	gl.Rotate(paint.y*2,1,0,0);
	



	if not texture.vb then
	
		texture.vb=gl.GenBuffer()	-- hack please do this better
		
		local data={
		}
		local p=function(d)
			data[#data+1]=d
		end
		for x=0,texture.layers.width-1 do
			for y=0,texture.layers.height-1 do
				for z=0,texture.layers.count-1 do
					local xb=texture.layers.width *math.floor(z%texture.layers.x)
					local yb=texture.layers.height*math.floor(z/texture.layers.x)
					p(x-(qubesize/2))
					p(y-(qubesize/2))
					p(z-(qubesize/2))
					p((x+xb)/texture.texture_width)
					p((y+yb)/texture.texture_height)
				end
			end
		end

		local datalen=#data
		local datasize=datalen*4 -- we need this much vdat memory
		canvas.vdat_check(datasize) -- make sure we have space in the buffer
		pack.save_array(data,"f32",0,datalen,canvas.vdat)
		
		gl.BindBuffer(gl.ARRAY_BUFFER,texture.vb)
		gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.STATIC_DRAW)
		texture.vb_len=datalen

	end
	
	local p
	p=gl.program("swpaint_image8_writeqube")
	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,texture.vb)
--	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )
	
--	gl.Uniform4f( p:uniform("img_siz"), texture.width,texture.height,texture.texture_width,texture.texture_height )
	
	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))
	
	gl.Enable(gl.DEPTH_TEST)
	gl.DrawArrays(gl.POINTS,0,texture.vb_len)
	gl.Disable(gl.DEPTH_TEST)

	fbo.bind_frame() -- restore old frame
	canvas.layout.restore()
	
	gl.MatrixMode(gl.PROJECTION)
	gl.PopMatrix()
	gl.MatrixMode(gl.MODELVIEW)
	gl.PopMatrix()

--	bloom.process()


--	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		fbosize,	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,			fbosize,
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		fbosize,	fbosize,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	gl.Uniform4f( p:uniform("img_siz"), fbosize,fbosize,fbosize,fbosize )
	gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	
	gl.Uniform4f( p:uniform("img_pos"), 0,0,1,1 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)


	bloom.process()


	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		fbosize,	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,			fbosize,
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		fbosize,	fbosize,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	gl.Uniform4f( p:uniform("img_siz"), fbosize,fbosize,fbosize,fbosize )
	gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	
	gl.Uniform4f( p:uniform("img_pos"), 0,0,1,1 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
		
end


	return texture
end
