--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local bit=require("bit")
local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local wgrd=require("wetgenes.grd")
local zips=require("wetgenes.zips")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wsbox=require("wetgenes.sandbox")



local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,paint)
	local paint=paint or {}
	paint.oven=oven
	
	paint.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local main=oven.rebake(oven.modname..".main")
	local textures=oven.rebake(oven.modname..".textures")
	local bloom=oven.rebake(oven.modname..".bloom")
	local views=oven.rebake(oven.modname..".views")
	local images=oven.rebake(oven.modname..".images")
	local gui=oven.rebake(oven.modname..".gui")
	local grdpaint=oven.rebake(oven.modname..".grdpaint")
	local trace=oven.rebake(oven.modname..".trace")
	local uvmap=oven.rebake(oven.modname..".uvmap")



paint.loads=function()

	textures.loads()
	if bloom.loads then
		bloom.loads()
	end
end
		
paint.setup=function()

	if not paint.done_setup then

		paint.file_history={} -- a list of recently used dirs for fast switch in file requester

		local dd="./"
		
		if lfs and lfs.currentdir then
			local t=(lfs.currentdir()) -- add current dir to history
			if t then
				paint.file_history[t]=true
			end

			for i,v in ipairs(oven.opts.args) do -- add passed in values to file history if they end with a /
				if "--"~=v:sub(1,2) then
					if v:sub(-1)=="/" then
						paint.file_history[v:sub(1,-2)]=true -- skip trailing slash
					end
				end
			end

		end
		
		if wwin.flavour=="nacl" then -- nofilesystem
		
		elseif wwin.flavour=="android" then -- android locations are a bit poopy
		
			dd="/sdcard/Pictures/swankypaint"
			if lfs then lfs.mkdir(dd) end
			
			paint.file_history[dd]=true
			paint.file_history["/sdcard/Pictures"]=true
			paint.file_history["/sdcard"]=true

		else

			if oven.homedir then
				dd=oven.homedir.."Pictures/swankypaint" -- if we already have a Pictures then add a swankypaint
				if lfs then lfs.mkdir(dd) end
				
				paint.file_history[dd]=true
				paint.file_history[oven.homedir.."Pictures"]=true
				paint.file_history[oven.homedir.."Desktop"]=true
			end

		end
		
		paint.basepath=dd.."/"..string.format("px%08x.png",os.time())


-- single setup
		textures.setup()
		if bloom.setup then
		bloom.setup()
		end
		images.setup()
		views.setup()

		local loaded_png=false
		for i,v in ipairs(oven.opts.args) do -- load the requested png, if one is given
			if "--"~=v:sub(1,2) then
				if v:sub(-4)==".png" then
					images.get().load_grd(v)
					loaded_png=true
				end
			end
		end
		if not loaded_png then
			images.get().load_grd(oven.opts.splash)
			images.get().modified="repme"
			images.get().filename=paint.basepath
		end

		paint.act_add({cmd="begin"})
		paint.act_add({cmd="end"})
		
		paint.done_setup=true
	end
	
	local fname="data/imgs/pbrush.png"
	local g=assert(wgrd.create())
	local d=assert(zips.readfile(fname),"Failed to load "..fname)
	assert(g:load_data(d,"png")) -- skip extension period

	paint.pbrush=g
	paint.pbrush_area={0,0,8,8}

	paint.brush=wgrd.create() -- make sure we always have a brush
	paint.brushmode="paint"

	paint.grd_temp=paint.grd_temp or wgrd.create(wgrd.U8_INDEXED,1,1,1)
	paint.grd_undo=paint.grd_undo or wgrd.create(wgrd.U8_INDEXED,1,1,1)
	paint.grd_spare=paint.grd_spare or wgrd.create(wgrd.U8_INDEXED,1,1,1)

	paint.x=0
	paint.y=0
	paint.hx=0.5 -- handle
	paint.hy=0.5
	paint.set_pbrush("dot")
	
	paint.snap=false

	
	paint.area={x=0,y=0,w=256,h=256}
	
	gui.setup()
	
	textures.get().upload( images.get().grd , images.get().frame )

	trace.setup()
	uvmap.setup()
	if paint.setup_conf then
		paint.configure(paint.setup_conf)
		paint.setup_conf=nil
	end
end

paint.clean=function()

	textures.clean()
	views.clean()
	images.clean()
	trace.clean()
	uvmap.clean()
end



paint.configure=function(conf)

	if type(conf)=="string" then conf=wsbox.lson(conf) end
	
	if not paint.done_setup then -- save for recall after we are setup
		paint.setup_conf=conf
		return
	end

	if conf.pix then
		images.new_grd( conf.pix.width , conf.pix.height , conf.pix.depth )

		gui.data.fatpix:value(conf.fat.width)
		gui.data.fatpiy:value(conf.fat.height)
		gui.data.bloom:value(conf.fat.bloom)
		gui.data.escher:value(conf.fat.escher or "pixel" ) -- can choose strange pixels
		
		local g=images.get().grd
		
		local p=conf.pal
		local t={}
		for i=1,256 do
			local c=p[i] or 0
			t[#t+1]=bit.band(bit.rshift(c,16),0xff)
			t[#t+1]=bit.band(bit.rshift(c, 8),0xff)
			t[#t+1]=bit.band(c,0xff)
			t[#t+1]=bit.band(bit.rshift(c,24),0xff)
		end
		g:palette(0,256,t)
		
		gui.color_set(gui.color_bg,0)
		gui.color_set(gui.color_fg,1)
	end
	
	gui.fixbuts()
	gui.side_page_next="tools"
	
	if paint.setup_load_this_img then
		images.load_grd(paint.setup_load_this_img)
		paint.setup_load_this_img=nil
	else
		paint.act_add({cmd="begin"})
		paint.act_add({cmd="clear"})
		paint.act_add({cmd="end"})
	end

end



paint.msg=function(m)

	if m.class=="close" then
--		gui.side_page_next="quit"
		gui.show_quit_request()
	end

	if not views.grabmouse then
		if gui.msg(m) then return end
	end
	if not gui.master.menu then
		if views.msg(m) then return end
	end
end


local pclip=function(g,px,py,hx,hy,ps)

	pcall(function()
		g:pixels(px,py,hx,hy,ps)
	end)
end



paint.set_pbrush=function(n)

	local pba=paint.pbrush_area

	if n=="dot" then
		paint.mode="pbrush"
		pba[1]=0
		pba[2]=0
		pba[3]=8
		pba[4]=8
	elseif n=="block" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=0
		pba[3]=8
		pba[4]=8
	elseif n=="circle" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=8
		pba[3]=8
		pba[4]=8
	elseif n=="dash" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=16
		pba[3]=8
		pba[4]=8
	elseif n=="line" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=24
		pba[3]=8
		pba[4]=8
	elseif n=="shrink" then
		paint.mode="pbrush"
		if pba[1]>0 then pba[1]=pba[1]-8 end
		if pba[1]<0 then pba[1]=0 end
	elseif n=="grow" then
		paint.mode="pbrush"
		if pba[1]<56 then pba[1]=pba[1]+8 end
		if pba[1]>56 then pba[1]=56 end
	elseif n=="prev" then
		paint.mode="pbrush"
		if pba[2]>0 then pba[2]=pba[2]-8 end
		if pba[2]<0 then pba[2]=0 end
	elseif n=="next" then
		paint.mode="pbrush"
		if pba[2]<24 then pba[2]=pba[2]+8 end
		if pba[2]>24 then pba[2]=24 end
	end

	gui.fixbuts()
end

local mouse_down=false
paint.msg_mouse=function(m,info)

	local img=images.get()
--	local ga=img.layers_grd()
--	local gb=paint.grd
	local pba=paint.pbrush_area
	local dirty={grd=img.grd,frame=img.frame}
	
--	gb:resize(ga.width,ga.height,1)

	paint.x=info.x
	paint.y=info.y
	
	if paint.x>=0 and paint.y>=0 and paint.x<img.layers.width and paint.y<img.layers.height then
		paint.inside=true
	else
		paint.inside=false
	end

--print(m.keyname)

	if m.class=="mouse" then

--if m.action==-1 then dprint(m) end

		if m.keyname=="wheel_add" or m.keyname=="wheel_sub" then -- scroll buttons hack to create fake clicks
			if m.action==-1 then
				if m.keyname=="wheel_add" then
					gui.hooks("click",{id="magnify"})
				else
					gui.hooks("click",{id="magnify_right"})
				end
			end
			return -- and be ignored
		end

		gui.infomode="mouse" -- display mouse

		local function clearlines()
			for i=1,2 do local v=views[i]
				v.lines[1]=-1
				v.lines[2]=-1
				v.lines[3]=-1
				v.lines[4]=-1
			end
		end
		if paint.mode~="pickup" then
			clearlines()
		end

		if m.action==1 then
			mouse_down=m.keyname
			views.grabmouse=true -- paint has claimed all future mouse msgs
		end
		if m.action==-1 then
			views.grabmouse=false
		end

local function add_begin()
	if not paint.down then
		paint.down=true
		paint.act_add({cmd="begin"})
	end
end
local function add_end()
	if paint.down then
		paint.down=false
		paint.act_add({cmd="end"})
	end
end
		
		
		local pm={wgrd.PAINT_MODE_TRANS,gui.color_bg.i,gui.color_fg.i}

		if paint.brushmode=="paint" then
			pm[1]=wgrd.PAINT_MODE_TRANS
		elseif paint.brushmode=="color" then
			pm[1]=wgrd.PAINT_MODE_COLOR
		elseif paint.brushmode=="replace" then
			pm[1]=wgrd.PAINT_MODE_COPY
		end

		if mouse_down=="right" then -- right button
			pm[1]=wgrd.PAINT_MODE_COLOR
			pm[3]=pm[2]
		end

		if paint.snap then
			paint.x=math.floor(0.5+(paint.x/gui.data.snapx:value()))*gui.data.snapx:value()
			paint.y=math.floor(0.5+(paint.y/gui.data.snapy:value()))*gui.data.snapx:value()
		end
		
		if paint.mode=="scroll" or
			info.view==views[2] or -- miniview
			paint.autohand or -- spacebar
			(info.m.class=="mouse" and info.m.keyname=="middle") then -- middle mouse

			local v=paint.scroll and paint.scroll[3] or info.view
			local vx=((info.m.x-v.pos[1])/v.scalex)
			local vy=((info.m.y-v.pos[2])/v.scaley)
			
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if m.action==1 and not paint.scroll then
				paint.scroll={vx,vy,v,paint.mode}
				paint.mode="scroll"
			end
			if paint.scroll then
				local ps=paint.scroll
				local dx=vx-ps[1]
				local dy=vy-ps[2]
				ps[1]=vx
				ps[2]=vy
				gui.data.focus_x:value( gui.data.focus_x:value()-dx )
				gui.data.focus_y:value( gui.data.focus_y:value()-dy )
--				for i=1,2 do
--					views[i].focus[1]=views[i].focus[1]-dx
--					views[i].focus[2]=views[i].focus[2]-dy
--				end
			end
			if m.action==-1 and paint.scroll then
				paint.mode=paint.scroll[4] -- restore previous mode
				paint.scroll=nil
			end
			
--[[
			if paint.inside then
				if m.action==1 then
					views[1].focus[1]=paint.x-math.floor(images.get().layers.width/2)
					views[1].focus[2]=paint.y-math.floor(images.get().layers.height/2)
					views[2].focus[1]=paint.x-math.floor(images.get().layers.width/2)
					views[2].focus[2]=paint.y-math.floor(images.get().layers.height/2)
					main.remouse_fix=true
				end
			end
]]		
			
		elseif paint.mode=="pipette" and paint.inside then
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if mouse_down then
				local t,p=pcall(function() return img.layers_grd(nil,nil,img.frame):pixels(paint.x,paint.y,0,1,1,1) end)
				if t and p and #p==1 then -- index
					if m.keyname=="right" then
						gui.color_set(gui.color_bg,p[1])
					elseif m.keyname=="left" then
						gui.color_set(gui.color_fg,p[1])
					end
				end
			end
			if m.action==-1 then
				paint.set_pbrush("dot")
			end
		elseif paint.mode=="pickup" then
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if m.action==1 then
				paint.pickup={paint.x,paint.y,paint.x,paint.y}
				for i=1,2 do local v=views[i]
					v.lines[1]=paint.x
					v.lines[2]=paint.y
				end
			elseif m.action==-1 and paint.pickup then
				local pp=paint.pickup
				pp[3]=paint.x
				pp[4]=paint.y
				paint.mode="brush"
				
				paint.hx=1 -- brush handle
				paint.hy=1
				
				if pp[3]<pp[1] then
					pp[3],pp[1]=pp[1],pp[3]
					paint.hx=0
				end
				if pp[4]<pp[2] then
					pp[4],pp[2]=pp[2],pp[4]
					paint.hy=0
				end
				pp[3]=1+pp[3]-pp[1]
				pp[4]=1+pp[4]-pp[2]
				
				if paint.snap then
					pp[3]=pp[3]-1
					pp[4]=pp[4]-1
				end
				
				-- clip
				if pp[1] < 0 then
					pp[3]=pp[3]+pp[1]
					pp[1]=0
				end
				if pp[2] < 0 then
					pp[4]=pp[4]+pp[2]
					pp[2]=0
				end
				
				if pp[1]+pp[3] > img.layers.width then
					pp[3]=img.layers.width-pp[1]
				end
				if pp[2]+pp[4] > img.layers.height then
					pp[4]=img.layers.height-pp[2]
				end
				
				local bclear=(m.keyname=="right")
				if bclear then paint.act_add({cmd="begin"}) end
				paint.act_add({
					cmd="pickup",
					args={pp[1],pp[2],pp[3],pp[4],bclear},
					})
				if bclear then paint.act_add({cmd="end"}) end

--				paint.brush=wgrd.create(wgrd.U8_INDEXED,pp[3],pp[4],1)
--				paint.brush:paint(ga,0,0,pp[1],pp[2],pp[3],pp[4],wgrd.PAINT_MODE_COPY,0,0)
				clearlines()
				gui.fixbuts()
			else
				for i=1,2 do local v=views[i]
					v.lines[3]=paint.x
					v.lines[4]=paint.y
				end
			end
		elseif paint.mode=="brush" then
			if not paint.brush then paint.set_pbrush("dot") else
				local x=paint.x-math.floor((paint.brush.width-1)*paint.hx)
				local y=paint.y-math.floor((paint.brush.height-1)*paint.hy)
				if paint.snap then
					x=math.floor(x/gui.data.snapx:value())*gui.data.snapx:value()
					y=math.floor(y/gui.data.snapy:value())*gui.data.snapy:value()
				end
				if mouse_down then
					add_begin()
					paint.act_add({
						cmd="paint",
						args={paint.brush,x,y,0,0,paint.brush.width,paint.brush.height,pm[1],pm[2],pm[3]},
						})
				else
					paint.act_add({
						preview=true,
						cmd="paint",
						args={paint.brush,x,y,0,0,paint.brush.width,paint.brush.height,pm[1],pm[2],pm[3]},
						})
				end
			end
		elseif paint.mode=="pbrush" then
			local x=paint.x-math.floor((pba[3]-2)/2)
			local y=paint.y-math.floor((pba[4]-2)/2)
			if mouse_down then
				add_begin()
				paint.act_add({
					cmd="paint",
					args={paint.pbrush,x,y,pba[1],pba[2],pba[3],pba[4],wgrd.PAINT_MODE_COLOR,0,pm[3]},
					})
			else
				paint.act_add({
					preview=true,
					cmd="paint",
					args={paint.pbrush,x,y,pba[1],pba[2],pba[3],pba[4],wgrd.PAINT_MODE_COLOR,0,pm[3]},
					})
			end
		elseif paint.mode=="fill" then
			if m.action==1 then -- just first click
				add_begin()
				paint.act_add({
					cmd="fill",
					args={paint.x,paint.y,pm[3]},
					})
			end
		end

		
		
		if m.action==-1 then
			mouse_down=false
			add_end()
		end
						
	end
	
end


-- handle paint actions
paint.acts={}
paint.act=function(a)

	local img=images.get()
	local grd_layer=img.layers_grd()
	local grd_img=img.grd
	local grd_temp=paint.grd_temp
	local grd_undo=paint.grd_undo
	local grd_spare=paint.grd_spare

	local pba=paint.pbrush_area
	
--print(a.cmd,a.preview)

-- keep all grds the same size
	if grd_img.width~=grd_temp.width  or grd_img.height~=grd_temp.height  then grd_temp:resize(grd_img.width,grd_img.height,1)  end
	if grd_img.width~=grd_undo.width  or grd_img.height~=grd_undo.height  then grd_undo:resize(grd_img.width,grd_img.height,1)  end
	if grd_img.width~=grd_spare.width or grd_img.height~=grd_spare.height then grd_spare:resize(grd_img.width,grd_img.height,1) end

	if a.preview then
		if a.cmd=="paint" then
			paint.dirty={grd=grd_temp,frame=0}
			grd_temp:copy_data_layer(grd_img,0,img.frame)
			grd_temp.image=img
			img.layers_grd(nil,grd_temp):paint(unpack(a.args))
			paint.preview=true
		end
	else
		paint.preview=false
		paint.dirty={grd=img.grd,frame=img.frame}
		if a.cmd=="begin" then
			grd_undo:copy_data_layer(grd_img,0,img.frame)
		elseif a.cmd=="end" then
		
--[[
			if gui.data.attr_redux.num<256 then -- perform attr clash
				grd_img:attr_redux(gui.data.attr_width.num,gui.data.attr_height.num,gui.data.attr_redux.num,gui.data.attr_sub.num,gui.data.attr_back.num)
			end
]]
		
		elseif a.cmd=="redraw" then
		elseif a.cmd=="clear" then
			grd_temp:copy_data_layer(grd_img,0,img.frame)
			img.layers_grd(nil,grd_temp):clear(gui.color_bg.i)
			grd_temp:palette(0,256,grd_img:palette(0,256)) -- always force pal
			grd_img:copy_data_layer(grd_temp,img.frame,0)
			img.modified=true
		elseif a.cmd=="undo" then
			paint.dirty={grd=img.grd,frame=img.frame}
			grd_temp:copy_data_layer(grd_img,0,img.frame)
			grd_img:copy_data_layer(grd_undo,img.frame,0)
			grd_undo:copy_data_layer(grd_temp,0,0)
			img.modified=true
		elseif a.cmd=="pickup" then
			local pp=a.args
			paint.brush=wgrd.create(wgrd.U8_INDEXED,pp[3],pp[4],1)
			paint.brush.x=pp[1] -- remember where brush was picked up from 
			paint.brush.y=pp[2]
			paint.brush:palette(0,256,grd_img:palette(0,256)) -- always force pal
			grd_temp:copy_data_layer(grd_img,0,img.frame) -- hack to pickup from a frame
			paint.brush:paint(img.layers_grd(nil,grd_temp),0,0,pp[1],pp[2],pp[3],pp[4],wgrd.PAINT_MODE_COPY,0,0)
			if pp[5] then -- delete old brush area
				paint.dirty={grd=img.grd,frame=img.frame}
				img.layers_grd(nil,grd_temp):clip(pp[1],pp[2],0,pp[3],pp[4],1):clear(gui.color_bg.i)
				grd_img:copy_data_layer(grd_temp,img.frame,0)
				img.modified=true
			end
		elseif a.cmd=="paint" then
			grd_temp:copy_data_layer(grd_img,0,img.frame) -- hack to paint into a frame
			img.layers_grd(nil,grd_temp):paint(unpack(a.args))
			grd_img:copy_data_layer(grd_temp,img.frame,0)
			img.modified=true
		elseif a.cmd=="frame_swap" then
			paint.dirty={grd=img.grd,frame=img.frame}
			grd_spare:palette(0,256,grd_img:palette(0,256)) -- always force pal
			grd_temp:copy_data_layer(grd_img,0,img.frame)
			grd_img:copy_data_layer(grd_spare,img.frame,0)
			grd_spare:copy_data_layer(grd_temp,0,0)
			img.modified=true
		elseif a.cmd=="frame_copy" then
			paint.dirty={grd=img.grd,frame=img.frame}
			grd_spare:palette(0,256,grd_img:palette(0,256)) -- always force pal
			grd_spare:copy_data_layer(grd_img,0,img.frame)
			img.modified=true
		elseif a.cmd=="frame_add" then
			local g=wgrd.create(wgrd.U8_INDEXED,grd_img.width,grd_img.height,grd_img.depth+1)
			g:palette(0,256,grd_img:palette(0,256)) -- copy pal
			g.image=img
			local f=img.frame
			for i=0,grd_img.depth do
				local j=i
				if i>f then j=j-1 end
				g:copy_data_layer(grd_img,i,j)
			end
			img.grd=g
			grd_img=g
			paint.dirty={grd=img.grd,frame=f+1}
			gui.data.depth:value(grd_img.depth)
			img.modified=true
			gui.data_refresh()
			gui.data.frame_idx:value(f+2)
		elseif a.cmd=="frame_del" then
			if grd_img.depth > 1 then
				local g=wgrd.create(wgrd.U8_INDEXED,grd_img.width,grd_img.height,grd_img.depth-1)
				g:palette(0,256,grd_img:palette(0,256)) -- copy pal
				g.image=img
				for i=0,grd_img.depth-1 do
					local j=i
					if i>=img.frame then j=j+1 end
					g:copy_data_layer(grd_img,i,j)
				end
				if img.frame>=g.depth then img.frame=img.frame-1 end
				img.grd=g
				grd_img=g
			end
			paint.dirty={grd=img.grd,frame=img.frame}
			gui.data.depth:value(grd_img.depth)
			img.modified=true
			gui.data_refresh()
		elseif a.cmd=="fill" then
			local pp=a.args
			grd_temp:copy_data_layer(grd_img,0,img.frame) -- hack to paint into a frame
			local b=grdpaint.fill_mask(img.layers_grd(nil,grd_temp),pp[1],pp[2])
			if b then
				img.layers_grd(nil,grd_temp):paint(b,0,0,0,0,b.width,b.height,wgrd.PAINT_MODE_COLOR,0,pp[3])
				grd_img:copy_data_layer(grd_temp,img.frame,0)
				img.modified=true
			end
		end
	end


end
paint.act_loop=function()

	while #paint.acts > 0 do
		paint.act( table.remove(paint.acts,1) )
	end

	if paint.dirty then
		textures.get().upload(paint.dirty.grd,paint.dirty.frame)
		paint.dirty=nil
	end
	
end
paint.act_add=function(a)
	paint.acts[#paint.acts+1]=a
end



paint.update=function()


	paint.act_loop()

	local x1,y1=gui.draw_area:get_master_xy(0,0)
	local x2,y2=gui.draw_area:get_master_xy(gui.draw_area.hx,gui.draw_area.hy)

--		x1,y1=gui.master:get_master_xy(0,0)
--		x2,y2=gui.master:get_master_xy(gui.master.hx,gui.master.hy)

	paint.area.x=x1
	paint.area.y=y1
	paint.area.w=x2-x1
	paint.area.h=y2-y1

	textures.update()
	views.update()
	images.update()
	gui.update()
	

	

	
end

paint.draw=function()

--	layout.apply()

--	gl.LoadIdentity()
--	gl.Translate(-oven.win.width*oven.win.overscale*0.5,-oven.win.height*oven.win.overscale*0.5,(-oven.win.height*0.5)/0.25) -- top left corner is origin


	views.draw()
	gui.draw()

	
end

paint.quicksave=function()
	if paint.quicksave_hook then
		paint.quicksave_hook()
	else
		gui.save_grd() -- this will ask if you want to replace
	end
end

	return paint
end
